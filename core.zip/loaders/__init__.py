"""Input loaders. Kept outside tozan/ so the core has no file-IO or gpxpy dependency."""

from loaders.gpx import load_route_from_gpx, parse_gpx

__all__ = ["load_route_from_gpx", "parse_gpx"]
