"""GPX 読み込み。xml.etree.ElementTree のみに依存する（標準ライブラリ）。tozan/ の外に置く。"""

import xml.etree.ElementTree as ET
from datetime import datetime, timedelta

from tozan.geometry import haversine
from tozan.route import Route, RoutePoint
from tozan.terrain import assign_terrain_types

# 現状は GPX の timestamp が UTC である前提で固定 +9h。
# タイムゾーン付きの場合は二重補正になるが、この挙動は変えない（構想書 §7-4 g）。
_JST_OFFSET = timedelta(hours=9)


def _namespace(root_tag: str) -> str:
    """ルート要素のタグから `{名前空間URI}` を取り出す。無ければ空文字。

    GPX 1.1（`http://www.topografix.com/GPX/1/1`）と 1.0 の両方に対応するため、
    特定の URI にハードコードせず、読み込むファイル自身の名前空間をそのまま使う。
    """
    if root_tag.startswith("{"):
        return root_tag[:root_tag.index("}") + 1]
    return ""


def _iter_trkpts(root: ET.Element):
    ns = _namespace(root.tag)
    for trk in root.findall(f"{ns}trk"):
        for trkseg in trk.findall(f"{ns}trkseg"):
            for trkpt in trkseg.findall(f"{ns}trkpt"):
                yield ns, trkpt


def parse_gpx(text: str) -> Route:
    """GPX のテキストから Route を作る。ブラウザ（Pyodide）側から使う入口。"""
    root = ET.fromstring(text)

    points: list[RoutePoint] = []
    for ns, trkpt in _iter_trkpts(root):
        ele_elem = trkpt.find(f"{ns}ele")
        time_elem = trkpt.find(f"{ns}time")

        ts = None
        if time_elem is not None and time_elem.text:
            ts = datetime.fromisoformat(time_elem.text) + _JST_OFFSET

        points.append(RoutePoint(
            lat=float(trkpt.get("lat")),
            lon=float(trkpt.get("lon")),
            ele=float(ele_elem.text),
            timestamp=ts,
        ))

    for i, p in enumerate(points):
        if i == 0:
            p.dist_m = 0.0
            p.ele_diff = 0.0
        else:
            prev = points[i - 1]
            p.dist_m = float(haversine(prev.lat, prev.lon, p.lat, p.lon))
            p.ele_diff = float(p.ele - prev.ele)

    route = Route(points=points)
    assign_terrain_types(route)
    return route


def load_route_from_gpx(path_or_stream) -> Route:
    """既存の呼び出し方（ファイルパスまたはファイルオブジェクト）を維持する。"""
    if hasattr(path_or_stream, "read"):
        text = path_or_stream.read()
    else:
        with open(path_or_stream, "r", encoding="utf-8") as f:
            text = f.read()
    return parse_gpx(text)
