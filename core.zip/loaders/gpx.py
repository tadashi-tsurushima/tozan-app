"""GPX 読み込み。xml.etree.ElementTree のみに依存する（標準ライブラリ）。tozan/ の外に置く。"""

import xml.etree.ElementTree as ET
from datetime import datetime, timedelta

from tozan.geometry import haversine
from tozan.route import Route, RoutePoint

# 現状は GPX の timestamp が UTC である前提で固定 +9h。
# タイムゾーン付きの場合は二重補正になるが、この挙動は変えない（構想書 §7-4 g）。
_JST_OFFSET = timedelta(hours=9)


def _namespace(root_tag: str) -> str:
    """ルート要素のタグから `{名前空間URI}` を取り出す。無ければ空文字。

    GPX 1.1（`http://www.topografix.com/GPX/1/1`）と 1.0 の両方に対応するため、
    特定の URI にハードコードせず、読み込むファイル自身の名前空間をそのまま使う。
    """
    if root_tag.startswith("{"):
        return root_tag[:root_tag.index("}") + 1]
    return ""


def _iter_trkpts(root: ET.Element):
    """(名前空間, <trk> の名前, <trkpt>) を順に返す。

    <trk> の名前は Yamareco の計画 GPX で日の区切りに使う（"Day1".."DayN"）。
    他の GPX では None か "track" などで、その場合は日の区切りには使わない
    （Phase 6-13、2026-09-26）。
    """
    ns = _namespace(root.tag)
    for trk in root.findall(f"{ns}trk"):
        name_elem = trk.find(f"{ns}name")
        trk_name = name_elem.text.strip() if name_elem is not None and name_elem.text else None
        for trkseg in trk.findall(f"{ns}trkseg"):
            for trkpt in trkseg.findall(f"{ns}trkpt"):
                yield ns, trk_name, trkpt


def parse_gpx(text: str) -> Route:
    """GPX のテキストから Route を作る。ブラウザ（Pyodide）側から使う入口。"""
    root = ET.fromstring(text)

    points: list[RoutePoint] = []
    for ns, trk_name, trkpt in _iter_trkpts(root):
        ele_elem = trkpt.find(f"{ns}ele")
        time_elem = trkpt.find(f"{ns}time")

        ts = None
        if time_elem is not None and time_elem.text:
            ts = datetime.fromisoformat(time_elem.text) + _JST_OFFSET

        # Yamareco の計画 GPX は <trkpt> の中に <name> で地点名を持つ（小屋・山頂・
        # 分岐・登山口など）。<wpt> ではなくルート上の点そのものに付いているので、
        # 位置が正確に紐づく。他の GPX には無い（Phase 6-13、2026-09-26）。
        name_elem = trkpt.find(f"{ns}name")
        pt_name = name_elem.text.strip() if name_elem is not None and name_elem.text else None

        points.append(RoutePoint(
            lat=float(trkpt.get("lat")),
            lon=float(trkpt.get("lon")),
            ele=float(ele_elem.text),
            timestamp=ts,
            name=pt_name,
            track_name=trk_name,
        ))

    for i, p in enumerate(points):
        if i == 0:
            p.dist_m = 0.0
            p.ele_diff = 0.0
        else:
            prev = points[i - 1]
            p.dist_m = float(haversine(prev.lat, prev.lon, p.lat, p.lon))
            p.ele_diff = float(p.ele - prev.ele)

    _mark_hands_segments(points)
    route = Route(points=points)
    return route


def load_route_from_gpx(path_or_stream) -> Route:
    """既存の呼び出し方（ファイルパスまたはファイルオブジェクト）を維持する。"""
    if hasattr(path_or_stream, "read"):
        text = path_or_stream.read()
    else:
        with open(path_or_stream, "r", encoding="utf-8") as f:
            text = f.read()
    return parse_gpx(text)


# 手を使う区間の判定（Phase 6-15、2026-09-27）
_HANDS_GAP_MIN_S = 30.0      # 欠落とみなす最小の秒数
_HANDS_GAP_FACTOR = 3.0      # 記録間隔の何倍から欠落とみなすか
_HANDS_MAX_V_H = 0.15        # 欠落中の水平速度の上限 [m/s]
_HANDS_MIN_V_Z = 0.010       # 欠落中の鉛直速度の下限 [m/s]


def _mark_hands_segments(points) -> None:
    """記録の欠落から「手を使わないと登れない／下れない区間」に印を付ける。

    山行アプリは水平速度でしか「動いている」を判定しないので、鎖場・はしご・
    岩稜や、草木をつかまないと登れない土の激登りでは、登っている最中に
    自動一時停止が掛かって記録が切れる。実測1091件の欠落のうち、普通に歩いて
    いる速度（0.6 m/s 以上）のものは3件しか無く、GPS の受信不良ではない。

    条件は3つ。記録間隔の3倍かつ30秒より長く空いていること、その間に水平には
    ほとんど進んでいないこと（< 0.15 m/s）、しかし標高は動いていること
    （>= 0.010 m/s）。3つめが休憩と手を使う登りを分ける ―― GPS の標高ノイズ
    なら標高差の正負は半々になるはずだが、実測では登り区間で +、下り区間で −
    に偏る（「正しい向き」の割合は 0.005-0.010 m/s の帯で 64%、0.010-0.015 で
    80%、0.020-0.030 で 80%）。0.010 を境に偏りが落ちるのでここで切る。

    **時刻は区間を見つけるためだけに使い、所要時間には使わない。** 欠落した
    実時間をそのまま採ると、記録した人がかかった時間を写すことになり、誰が
    計算しても同じ値が出てしまう（CLAUDE.md §5）。かかる時間はモデルが
    v_hands_m_s と体格・体力から出す。

    計画 GPX は時刻が合成値で欠落が無いため、印は付かず何も変わらない。
    """
    dts = []
    for i in range(1, len(points)):
        a, b = points[i - 1], points[i]
        if a.timestamp is None or b.timestamp is None:
            continue
        dt = (b.timestamp - a.timestamp).total_seconds()
        if dt > 0:
            dts.append(dt)
    if len(dts) < 10:
        return
    dts.sort()
    interval = dts[len(dts) // 2]
    limit = max(interval * _HANDS_GAP_FACTOR, _HANDS_GAP_MIN_S)
    for i in range(1, len(points)):
        a, b = points[i - 1], points[i]
        if a.timestamp is None or b.timestamp is None:
            continue
        dt = (b.timestamp - a.timestamp).total_seconds()
        if dt <= limit:
            continue
        if b.dist_m / dt >= _HANDS_MAX_V_H:
            continue
        if abs(b.ele_diff) / dt < _HANDS_MIN_V_Z:
            continue
        b.hands = True
