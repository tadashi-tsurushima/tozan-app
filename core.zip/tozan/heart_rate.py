"""Heart-rate recovery helpers."""

def calculate_heart_rate_recovery_exponential(current_hr, hr_rest, rest_time_seconds, recovery_time_constant=60.0, hr_target_offset=35.0):
    """指数関数的な心拍数回復を計算

    Args:
        current_hr: 現在の心拍数
        hr_rest: 安静時心拍数
        rest_time_seconds: 休憩時間 [秒]
        recovery_time_constant: 回復時定数 [秒]
        hr_target_offset: 目標心拍数のオフセット（hr_rest + hr_target_offset）[bpm]
    """
    import math
    hr_target = hr_rest + hr_target_offset
    # 指数関数的回復：時定数が小さいほど速く回復
    # exp(-rest_time_seconds / recovery_time_constant) が小さいほど、hr_targetに近づく
    exp_factor = math.exp(-rest_time_seconds / recovery_time_constant)
    hr_after_rest = hr_target + (current_hr - hr_target) * exp_factor
    # 下限を目標値に設定（回復後は目標値以下にならない）
    hr_after_rest = max(hr_rest + hr_target_offset, hr_after_rest)
    return hr_after_rest
