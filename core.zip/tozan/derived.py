"""結果から UI 向けの派生値を計算する純関数（Step 5-3）。

tozan/ 本体の計算式には一切手を加えない。標準ライブラリのみに依存する。
"""

from tozan.result import SimResult


def plan_summary(result: SimResult, params: dict) -> dict:
    """計画モードのサマリ。日ごとと全体を返す。

    必要な水・行動食の定義は依頼者（モデル作成者）が未確定のため仮の式を置く
    （作業指示書 docs/05_ §判断を要する点）。式を確定したらこの関数だけを直す。
    """
    days = []
    total_duration_h = 0.0
    total_distance_km = 0.0
    total_up_m = 0.0
    total_down_m = 0.0
    total_sweat_kg = 0.0
    total_kcal = 0.0

    for day in result.days:
        kcal = sum(day.metabolic_energy_data) / 4184.0 if day.metabolic_energy_data else 0.0
        days.append({
            "date": str(day.date) if day.date is not None else None,
            "duration_h": day.duration_h,
            "distance_km": day.distance_km,
            "up_m": day.up_m,
            "down_m": day.down_m,
            "sweat_kg": day.sweat_kg,
            "kcal": kcal,
        })
        total_duration_h += day.duration_h
        total_distance_km += day.distance_km
        total_up_m += day.up_m
        total_down_m += day.down_m
        total_sweat_kg += day.sweat_kg
        total_kcal += kcal

    # 仮案: 必要な水 [L] = 発汗量の合計 [kg]（1 kg ≒ 1 L）。
    water_L = total_sweat_kg

    # 仮案: 必要な行動食 [kcal] = 消費kcal - 初期グリコーゲン量。
    # 脂肪由来の分を引くべきかは未確定（依頼者判断待ち）。
    from tozan.state import glycogen_capacity_kcal, glycogen_initial_kcal
    glycogen_kcal_init = glycogen_initial_kcal(params)
    action_food_kcal = max(0.0, total_kcal - glycogen_kcal_init)

    return {
        "days": days,
        "total": {
            "duration_h": total_duration_h,
            "distance_km": total_distance_km,
            "up_m": total_up_m,
            "down_m": total_down_m,
            "sweat_kg": total_sweat_kg,
            "kcal": total_kcal,
            "water_L": water_L,
            "action_food_kcal": action_food_kcal,
        },
        # グリコーゲングラフの縦軸に使う（体重・体脂肪率から決まる。Phase 4b-0）。
        # 以前は UI 側に 1800kcal 固定容量を前提にした縦軸上限があった。
        "glycogen_capacity_kcal": glycogen_capacity_kcal(params),
    }


def _cumsum_scaled(values, divisor):
    """累積和を divisor で割りながら返す（例: J の列を kcal の累積に変換）。"""
    total = 0.0
    out = []
    for v in values:
        total += v / divisor
        out.append(total)
    return out


def _pace_min_per_km(time_data, dx_data):
    """区間ごとのペース [分/km] を返す。

    time_data[i] はこの区間を歩き始める前の累積経過秒、dx_data[i] は
    この区間の水平距離 [m]（tozan/day.py の実装に対応）。区間の所要時間は
    次の点の time_data とこの点の time_data の差になるため、最後の点は
    次が無く計算できない。休憩点（dx_data[i] <= 0）と合わせて None にし、
    グラフの線を切る（作業指示書 docs/05_ §判断を要する点。仮案）。
    """
    n = len(dx_data)
    pace = []
    for i in range(n):
        if i + 1 >= len(time_data) or dx_data[i] <= 0:
            pace.append(None)
            continue
        dt_sec = time_data[i + 1] - time_data[i]
        if dt_sec <= 0:
            pace.append(None)
            continue
        dx_km = dx_data[i] / 1000.0
        pace.append((dt_sec / 60.0) / dx_km)
    return pace


# 「スピード」グラフの縦軸を分/kmのまま表示すると、値が小さいほど速いという
# 直感に反する向きになる（作業指示書 docs/05_ §判断を要する点）。
# 依頼者指定（2026-09-19）: 30分/kmを100%とする相対速度[%]に変換して表示する
# （15分/kmなら200%、60分/kmなら50%）。
REFERENCE_PACE_MIN_PER_KM = 30.0


def _speed_pct(pace_min_per_km):
    """ペース[分/km]を、30分/kmを100%とした相対速度[%]に変換する。"""
    out = []
    for p in pace_min_per_km:
        if p is None or p <= 0:
            out.append(None)
        else:
            out.append(REFERENCE_PACE_MIN_PER_KM / p * 100.0)
    return out


def _smooth_by_time(values, time_data, window_minutes):
    """時刻[秒]ベースの移動平均。各点の前後 window_minutes/2 分以内の点を対象にする
    （GPXの記録間隔が不均一でも、サンプル数ベースより実際の時間窓に近くなる）。
    None は平均から除外する。window_minutes<=0 なら何もしない（依頼者指定・2026-09-20）。

    time_data が単調非減少（経過時間なので常にそう）であることを前提に、
    左右の走査位置を使い切りにする2ポインタでO(n)にする。
    """
    if window_minutes <= 0:
        return list(values)
    half_sec = (window_minutes * 60.0) / 2.0
    n = len(values)
    left = 0
    right = 0
    running_sum = 0.0
    running_count = 0
    out = [None] * n
    for i in range(n):
        t0 = time_data[i]
        while right < n and time_data[right] <= t0 + half_sec:
            if values[right] is not None:
                running_sum += values[right]
                running_count += 1
            right += 1
        while left < right and time_data[left] < t0 - half_sec:
            if values[left] is not None:
                running_sum -= values[left]
                running_count -= 1
            left += 1
        out[i] = running_sum / running_count if running_count else None
    return out


def ui_series(result: SimResult, pace_smooth_minutes: float = 0.0) -> dict:
    """結果グラフ用に整形した系列を日ごとに返す（横軸は elapsed_h）。

    縦軸反転・休憩点の扱いは依頼者未確定（作業指示書 docs/05_ §判断を要する点）。
    ペースは前後 pace_smooth_minutes/2 分の移動平均で平滑化する
    （0以下で平滑化なし。依頼者指定・2026-09-20、15分）。休憩点と最終点は None にする。
    """
    days = []
    for day in result.days:
        time_data = day.time_data
        pace = _pace_min_per_km(time_data, day.dx_data)
        if pace_smooth_minutes > 0:
            pace = _smooth_by_time(pace, time_data, pace_smooth_minutes)

        days.append({
            "date": str(day.date) if day.date is not None else None,
            "elapsed_h": [t / 3600.0 for t in time_data],
            "elevation_m": list(day.elevation_data),
            "hr_bpm": list(day.hr_data),
            "pace_min_per_km": pace,
            "speed_pct": _speed_pct(pace),
            "energy_kcal_cum": _cumsum_scaled(day.metabolic_energy_data, 4184.0),
            "sweat_L_cum": _cumsum_scaled(day.sweat_incremental_data, 1.0),
            "glycogen_kcal": list(day.glycogen_data),
            "glycogen_A_kcal": list(day.local_gly_A_absolute_data),
            "glycogen_B_kcal": list(day.local_gly_B_absolute_data),
            "glycogen_C_kcal": list(day.local_gly_C_absolute_data),
            "muscle_eff": list(day.final_muscle_efficiency_data),
        })
    return {"days": days}


def _point_at(day, i):
    """day.distance_cumulative_data / elevation_data の i番目を安全に取り出す。"""
    dist = day.distance_cumulative_data
    ele = day.elevation_data
    return (
        dist[i] / 1000.0 if i < len(dist) else None,
        ele[i] if i < len(ele) else None,
    )


def _which_part(day, i):
    """local_gly_min_ratio_data[i] が A/B/C のどれと一致するかを返す（仮案）。"""
    parts = {
        "A": day.local_gly_A_ratio_data[i],
        "B": day.local_gly_B_ratio_data[i],
        "C": day.local_gly_C_ratio_data[i],
    }
    return min(parts, key=parts.get)


def _rest_start_indices(day):
    """休憩（dx = 0 の連続）の先頭インデックスを返す。day.py はまとまった補給の
    休憩を dx = 0 の点として時間軸に入れる（Phase 4b-2）。先頭の点は除く。"""
    dx = day.dx_data
    out = []
    for i in range(1, len(dx)):
        if dx[i] <= 0.0 and dx[i - 1] > 0.0:
            out.append(i)
    return out


def _hypoglycemic_start_indices(day):
    """しゃりばて（肝が空かつ吸収中の糖もない。day.hypoglycemic_data、Phase 4b-2）が
    False → True に転じる先頭インデックスを返す。連続した発火は1件にまとめる。"""
    hg = day.hypoglycemic_data
    out = []
    for i in range(1, len(hg)):
        if hg[i] and not hg[i - 1]:
            out.append(i)
    return out


def supply_plan(result: SimResult, params: dict) -> dict:
    """補給のタイミングと、グリコーゲンが閾値を割る地点。

    "daily" は個々の補給タイミングではなく1日ごとの合計だけを見たい場合の集計
    （依頼者指定・2026-09-19）。"supplies" 自体はUI表示に使わなくなったが、
    集計の元データとして残す。"hypoglycemic" はしゃりばての発火地点
    （Phase 4b-2、2026-09-22 追加。"warnings" の局所グリコーゲン枯渇とは別の現象）。

    補給は2種類をモデル内部の実装（tozan/day.py）にあわせて出す。

    - 定期補給（"periodic"）: params["action_food_interval_minutes"] ごとに
      action_food_fruits_kcal + action_food_nuts_kcal（day.py:728-734 と同じ間隔）
    - まとまった補給（"meal"）: 歩行時間 meal_interval_minutes ごとに meal_kcal。
      day.py が休憩（dx = 0 の連続）として時間軸に入れた点を拾う（Phase 4b-2）。
      以前は山頂検出時の1回だけだった（"peak"）

    地点は time_data から該当時刻の点を探し、distance_cumulative_data と
    elevation_data を引く。実際の吸収は補給から時間差を置いて緩やかに進む
    （day.py の carb_queue。遅れ 20 分・上限 60 g/h）が、ここでは
    「何時間後に食べるべきか」のリマインダーとして単純化している。

    警告の閾値は依頼者未確定のため、仮案として local_sigmoid_x0
    （局所グリコーゲン枯渇シグモイドの効果が始まる残存率）を
    local_gly_min_ratio_data に適用する（作業指示書 docs/05_ §判断を要する点）。
    この警告は、①②の暫定補給スケジュールでは足りない区間
    （＝未知の休憩適地でも構わないので追加でまとまった補給が必要な場所）を示す。
    """
    interval_min = params.get("action_food_interval_minutes", 60.0)
    kcal_per_supply = (params.get("action_food_fruits_kcal", 30.0)
                       + params.get("action_food_nuts_kcal", 30.0))
    meal_kcal = params.get("meal_kcal", 250.0)
    threshold = params.get("local_sigmoid_x0", 0.2)
    interval_sec = interval_min * 60.0

    supplies = []
    warnings = []
    hypoglycemic = []
    daily = []

    for day_index, day in enumerate(result.days):
        time_data = day.time_data
        if not time_data:
            continue

        day_supplies = []

        next_trigger = interval_sec
        for i, t in enumerate(time_data):
            if t < next_trigger:
                continue
            distance_km, elevation_m = _point_at(day, i)
            day_supplies.append({
                "day": day_index,
                "elapsed_h": t / 3600.0,
                "distance_km": distance_km,
                "elevation_m": elevation_m,
                "kcal": kcal_per_supply,
                "kind": "periodic",
            })
            next_trigger += interval_sec

        for rest_i in _rest_start_indices(day):
            distance_km, elevation_m = _point_at(day, rest_i)
            day_supplies.append({
                "day": day_index,
                "elapsed_h": time_data[rest_i] / 3600.0,
                "distance_km": distance_km,
                "elevation_m": elevation_m,
                "kcal": meal_kcal,
                "kind": "meal",
            })

        day_supplies.sort(key=lambda s: s["elapsed_h"])
        supplies.extend(day_supplies)

        # 個々の補給タイミングではなく、1日の合計だけを一覧表示したい
        # （依頼者指定・2026-09-19）ための集計。グリコーゲン・脂肪は
        # 「その日の開始時点の残量 − 終了時点の残量」＝消費量。
        daily.append({
            "day": day_index,
            "date": str(day.date) if day.date is not None else None,
            "glycogen_consumed_kcal": day.glycogen_data[0] - day.glycogen_data[-1],
            "fat_burned_kcal": day.fat_data[0] - day.fat_data[-1],
            "periodic_food_kcal": sum(s["kcal"] for s in day_supplies if s["kind"] == "periodic"),
            "meal_food_kcal": sum(s["kcal"] for s in day_supplies if s["kind"] == "meal"),
        })

        for i, ratio in enumerate(day.local_gly_min_ratio_data):
            if ratio < threshold:
                distance_km, elevation_m = _point_at(day, i)
                warnings.append({
                    "day": day_index,
                    "elapsed_h": time_data[i] / 3600.0,
                    "distance_km": distance_km,
                    "elevation_m": elevation_m,
                    "which": _which_part(day, i),
                    "ratio": ratio,
                })
                break

        # しゃりばて（肝が空かつ吸収なし。Phase 4b-2）の発火地点。局所グリコーゲンの
        # 警告（筋、上の warnings）とは別の現象 ―― 血糖の枯渇で、天井が
        # 脂肪の酸化速度の上限まで落ちる（docs/06_ Phase 4b-2）。
        for hg_i in _hypoglycemic_start_indices(day):
            distance_km, elevation_m = _point_at(day, hg_i)
            hypoglycemic.append({
                "day": day_index,
                "elapsed_h": time_data[hg_i] / 3600.0,
                "distance_km": distance_km,
                "elevation_m": elevation_m,
            })

    return {"supplies": supplies, "warnings": warnings, "hypoglycemic": hypoglycemic, "daily": daily}
