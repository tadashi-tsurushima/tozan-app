"""結果から UI 向けの派生値を計算する純関数（Step 5-3）。

tozan/ 本体の計算式には一切手を加えない。標準ライブラリのみに依存する。
"""

from tozan.result import SimResult


def plan_summary(result: SimResult, params: dict) -> dict:
    """計画モードのサマリ。日ごとと全体を返す。

    必要な水・行動食の定義は依頼者（モデル作成者）が未確定のため仮の式を置く
    （作業指示書 docs/05_ §判断を要する点）。式を確定したらこの関数だけを直す。
    """
    days = []
    total_duration_h = 0.0
    total_distance_km = 0.0
    total_up_m = 0.0
    total_down_m = 0.0
    total_sweat_kg = 0.0
    total_kcal = 0.0

    for day in result.days:
        kcal = sum(day.metabolic_energy_data) / 4184.0 if day.metabolic_energy_data else 0.0
        days.append({
            "date": str(day.date) if day.date is not None else None,
            "duration_h": day.duration_h,
            "rest_h": _rest_time_h(day),
            "distance_km": day.distance_km,
            "up_m": day.up_m,
            "down_m": day.down_m,
            "sweat_kg": day.sweat_kg,
            "kcal": kcal,
        })
        total_duration_h += day.duration_h
        total_distance_km += day.distance_km
        total_up_m += day.up_m
        total_down_m += day.down_m
        total_sweat_kg += day.sweat_kg
        total_kcal += kcal

    # 仮案: 必要な水 [L] = 発汗量の合計 [kg]（1 kg ≒ 1 L）。
    water_L = total_sweat_kg

    # 仮案: 必要な行動食 [kcal] = 消費kcal - 初期グリコーゲン量。
    # 脂肪由来の分を引くべきかは未確定（依頼者判断待ち）。
    from tozan.state import glycogen_capacity_kcal, glycogen_initial_kcal, liver_capacity_g
    glycogen_kcal_init = glycogen_initial_kcal(params)
    action_food_kcal = max(0.0, total_kcal - glycogen_kcal_init)

    return {
        "days": days,
        "total": {
            "duration_h": total_duration_h,
            "distance_km": total_distance_km,
            "up_m": total_up_m,
            "down_m": total_down_m,
            "sweat_kg": total_sweat_kg,
            "kcal": total_kcal,
            "water_L": water_L,
            "action_food_kcal": action_food_kcal,
        },
        # グリコーゲングラフの縦軸に使う（体重・体脂肪率から決まる。Phase 4b-0）。
        # 以前は UI 側に 1800kcal 固定容量を前提にした縦軸上限があった。
        "glycogen_capacity_kcal": glycogen_capacity_kcal(params),
        # 肝グリコーゲンの容量 [kcal]。しゃりばて（Phase 4b-2）は肝が空になったときに
        # 起きるので、UI では全身とは別の軸で残量を見せる。
        "liver_capacity_kcal": liver_capacity_g(params) * 4.0,
        # 大腿（部位A）の容量。グラフを肝と同じ「満タン比 %」で描くのに使う
        # （Phase 6-11b、2026-09-25）。筋の容量 = 全体 − 肝を、部位の容量比で割る。
        "glycogen_A_capacity_kcal": ((glycogen_capacity_kcal(params)
                                      - liver_capacity_g(params) * 4.0)
                                     * params["local_muscle_shares"][0]),
    }


def _rest_time_h(day):
    """1日の休憩時間の合計 [h]。dx_data[i] <= 0 の区間（day.py が休憩を
    10秒刻みの時間軸として入れている。Phase 4b-2）の time_data の差を合算する。"""
    dx = day.dx_data
    t = day.time_data
    total_sec = 0.0
    for i in range(1, len(dx)):
        if dx[i] <= 0.0:
            total_sec += t[i] - t[i - 1]
    return total_sec / 3600.0


def _cumsum_scaled(values, divisor):
    """累積和を divisor で割りながら返す（例: J の列を kcal の累積に変換）。"""
    total = 0.0
    out = []
    for v in values:
        total += v / divisor
        out.append(total)
    return out


def _pace_min_per_km(time_data, dx_data):
    """区間ごとのペース [分/km] を返す。

    time_data[i] はこの区間を歩き始める前の累積経過秒、dx_data[i] は
    この区間の水平距離 [m]（tozan/day.py の実装に対応）。区間の所要時間は
    次の点の time_data とこの点の time_data の差になるため、最後の点は
    次が無く計算できない。休憩点（dx_data[i] <= 0）と合わせて None にし、
    グラフの線を切る（作業指示書 docs/05_ §判断を要する点。仮案）。
    """
    n = len(dx_data)
    pace = []
    for i in range(n):
        if i + 1 >= len(time_data) or dx_data[i] <= 0:
            pace.append(None)
            continue
        dt_sec = time_data[i + 1] - time_data[i]
        if dt_sec <= 0:
            pace.append(None)
            continue
        dx_km = dx_data[i] / 1000.0
        pace.append((dt_sec / 60.0) / dx_km)
    return pace


# 「スピード」グラフの縦軸を分/kmのまま表示すると、値が小さいほど速いという
# 直感に反する向きになる（作業指示書 docs/05_ §判断を要する点）。
# 依頼者指定（2026-09-19）: 30分/kmを100%とする相対速度[%]に変換して表示する
# （15分/kmなら200%、60分/kmなら50%）。
REFERENCE_PACE_MIN_PER_KM = 30.0


def _speed_pct(pace_min_per_km):
    """ペース[分/km]を、30分/kmを100%とした相対速度[%]に変換する。"""
    out = []
    for p in pace_min_per_km:
        if p is None or p <= 0:
            out.append(None)
        else:
            out.append(REFERENCE_PACE_MIN_PER_KM / p * 100.0)
    return out


def _smooth_by_time(values, time_data, window_minutes):
    """時刻[秒]ベースの移動平均。各点の前後 window_minutes/2 分以内の点を対象にする
    （GPXの記録間隔が不均一でも、サンプル数ベースより実際の時間窓に近くなる）。
    None は平均から除外する。window_minutes<=0 なら何もしない（依頼者指定・2026-09-20）。

    time_data が単調非減少（経過時間なので常にそう）であることを前提に、
    左右の走査位置を使い切りにする2ポインタでO(n)にする。
    """
    if window_minutes <= 0:
        return list(values)
    half_sec = (window_minutes * 60.0) / 2.0
    n = len(values)
    left = 0
    right = 0
    running_sum = 0.0
    running_count = 0
    out = [None] * n
    for i in range(n):
        t0 = time_data[i]
        while right < n and time_data[right] <= t0 + half_sec:
            if values[right] is not None:
                running_sum += values[right]
                running_count += 1
            right += 1
        while left < right and time_data[left] < t0 - half_sec:
            if values[left] is not None:
                running_sum -= values[left]
                running_count -= 1
            left += 1
        out[i] = running_sum / running_count if running_count else None
    return out


def ui_series(result: SimResult, pace_smooth_minutes: float = 0.0) -> dict:
    """結果グラフ用に整形した系列を日ごとに返す（横軸は elapsed_h）。

    縦軸反転・休憩点の扱いは依頼者未確定（作業指示書 docs/05_ §判断を要する点）。
    ペースは前後 pace_smooth_minutes/2 分の移動平均で平滑化する
    （0以下で平滑化なし。依頼者指定・2026-09-20、15分）。休憩点と最終点は None にする。
    """
    days = []
    for day in result.days:
        time_data = day.time_data
        pace = _pace_min_per_km(time_data, day.dx_data)
        if pace_smooth_minutes > 0:
            pace = _smooth_by_time(pace, time_data, pace_smooth_minutes)

        days.append({
            "date": str(day.date) if day.date is not None else None,
            "elapsed_h": [t / 3600.0 for t in time_data],
            "elevation_m": list(day.elevation_data),
            "hr_bpm": list(day.hr_data),
            "pace_min_per_km": pace,
            "speed_pct": _speed_pct(pace),
            "energy_kcal_cum": _cumsum_scaled(day.metabolic_energy_data, 4184.0),
            "sweat_L_cum": _cumsum_scaled(day.sweat_incremental_data, 1.0),
            "glycogen_kcal": list(day.glycogen_data),
            "glycogen_A_kcal": list(day.local_gly_A_absolute_data),
            "glycogen_B_kcal": list(day.local_gly_B_absolute_data),
            "glycogen_C_kcal": list(day.local_gly_C_absolute_data),
            "glycogen_liver_kcal": list(day.local_gly_liver_absolute_data),
            "muscle_eff": list(day.final_muscle_efficiency_data),
        })
    return {"days": days}


def _point_at(day, i):
    """day.distance_cumulative_data / elevation_data の i番目を安全に取り出す。"""
    dist = day.distance_cumulative_data
    ele = day.elevation_data
    return (
        dist[i] / 1000.0 if i < len(dist) else None,
        ele[i] if i < len(ele) else None,
    )


def _which_part(day, i):
    """local_gly_min_ratio_data[i] が A/B/C のどれと一致するかを返す（仮案）。"""
    parts = {
        "A": day.local_gly_A_ratio_data[i],
        "B": day.local_gly_B_ratio_data[i],
        "C": day.local_gly_C_ratio_data[i],
    }
    return min(parts, key=parts.get)


def _rest_start_indices(day):
    """休憩（dx = 0 の連続）の先頭インデックスを返す。day.py はまとまった補給の
    休憩を dx = 0 の点として時間軸に入れる（Phase 4b-2）。先頭の点は除く。"""
    dx = day.dx_data
    out = []
    for i in range(1, len(dx)):
        if dx[i] <= 0.0 and dx[i - 1] > 0.0:
            out.append(i)
    return out


def _hypoglycemic_start_indices(day):
    """しゃりばて（肝が空かつ吸収中の糖もない。day.hypoglycemic_data、Phase 4b-2）が
    False → True に転じる先頭インデックスを返す。連続した発火は1件にまとめる。"""
    hg = day.hypoglycemic_data
    out = []
    for i in range(1, len(hg)):
        if hg[i] and not hg[i - 1]:
            out.append(i)
    return out


def supply_plan(result: SimResult, params: dict) -> dict:
    """補給のタイミングと、グリコーゲンが閾値を割る地点。

    "daily" は個々の補給タイミングではなく1日ごとの合計だけを見たい場合の集計
    （依頼者指定・2026-09-19）。"supplies" 自体はUI表示に使わなくなったが、
    集計の元データとして残す。"hypoglycemic" はしゃりばての発火地点
    （Phase 4b-2、2026-09-22 追加。"warnings" の局所グリコーゲン枯渇とは別の現象）。

    補給は2種類をモデル内部の実装（tozan/day.py）にあわせて出す。

    - 定期補給（"periodic"）: params["action_food_interval_minutes"] ごとに
      action_food_fruits_kcal + action_food_nuts_kcal（day.py:728-734 と同じ間隔）
    - まとまった補給（"meal"）: 歩行時間 meal_interval_minutes ごとに meal_kcal。
      day.py が休憩（dx = 0 の連続）として時間軸に入れた点を拾う（Phase 4b-2）。
      以前は山頂検出時の1回だけだった（"peak"）

    地点は time_data から該当時刻の点を探し、distance_cumulative_data と
    elevation_data を引く。実際の吸収は補給から時間差を置いて緩やかに進む
    （day.py の carb_queue。遅れ 20 分・上限 60 g/h）が、ここでは
    「何時間後に食べるべきか」のリマインダーとして単純化している。

    警告の閾値は依頼者未確定のため、仮案として local_sigmoid_x0
    （局所グリコーゲン枯渇シグモイドの効果が始まる残存率）を
    local_gly_min_ratio_data に適用する（作業指示書 docs/05_ §判断を要する点）。
    この警告は、①②の暫定補給スケジュールでは足りない区間
    （＝未知の休憩適地でも構わないので追加でまとまった補給が必要な場所）を示す。
    """
    interval_min = params.get("action_food_interval_minutes", 60.0)
    kcal_per_supply = (params.get("action_food_fruits_kcal", 30.0)
                       + params.get("action_food_nuts_kcal", 30.0))
    meal_kcal = params.get("meal_kcal", 250.0)
    threshold = params.get("local_sigmoid_x0", 0.2)
    interval_sec = interval_min * 60.0

    supplies = []
    warnings = []
    hypoglycemic = []
    daily = []

    for day_index, day in enumerate(result.days):
        time_data = day.time_data
        if not time_data:
            continue

        day_supplies = []

        next_trigger = interval_sec
        for i, t in enumerate(time_data):
            if t < next_trigger:
                continue
            distance_km, elevation_m = _point_at(day, i)
            day_supplies.append({
                "day": day_index,
                "elapsed_h": t / 3600.0,
                "distance_km": distance_km,
                "elevation_m": elevation_m,
                "kcal": kcal_per_supply,
                "kind": "periodic",
            })
            next_trigger += interval_sec

        for rest_i in _rest_start_indices(day):
            distance_km, elevation_m = _point_at(day, rest_i)
            day_supplies.append({
                "day": day_index,
                "elapsed_h": time_data[rest_i] / 3600.0,
                "distance_km": distance_km,
                "elevation_m": elevation_m,
                "kcal": meal_kcal,
                "kind": "meal",
            })

        day_supplies.sort(key=lambda s: s["elapsed_h"])
        supplies.extend(day_supplies)

        # 個々の補給タイミングではなく、1日の合計だけを一覧表示したい
        # （依頼者指定・2026-09-19）ための集計。グリコーゲン・脂肪は
        # 「その日の開始時点の残量 − 終了時点の残量」＝消費量。
        daily.append({
            "day": day_index,
            "date": str(day.date) if day.date is not None else None,
            "glycogen_consumed_kcal": day.glycogen_data[0] - day.glycogen_data[-1],
            "fat_burned_kcal": day.fat_data[0] - day.fat_data[-1],
            "periodic_food_kcal": sum(s["kcal"] for s in day_supplies if s["kind"] == "periodic"),
            "meal_food_kcal": sum(s["kcal"] for s in day_supplies if s["kind"] == "meal"),
        })

        for i, ratio in enumerate(day.local_gly_min_ratio_data):
            if ratio < threshold:
                distance_km, elevation_m = _point_at(day, i)
                warnings.append({
                    "day": day_index,
                    "elapsed_h": time_data[i] / 3600.0,
                    "distance_km": distance_km,
                    "elevation_m": elevation_m,
                    "which": _which_part(day, i),
                    "ratio": ratio,
                })
                break

        # しゃりばて（肝が空かつ吸収なし。Phase 4b-2）の発火地点。局所グリコーゲンの
        # 警告（筋、上の warnings）とは別の現象 ―― 血糖の枯渇で、天井が
        # 脂肪の酸化速度の上限まで落ちる（docs/06_ Phase 4b-2）。
        for hg_i in _hypoglycemic_start_indices(day):
            distance_km, elevation_m = _point_at(day, hg_i)
            hypoglycemic.append({
                "day": day_index,
                "elapsed_h": time_data[hg_i] / 3600.0,
                "distance_km": distance_km,
                "elevation_m": elevation_m,
            })

    return {"supplies": supplies, "warnings": warnings, "hypoglycemic": hypoglycemic, "daily": daily}


def _strip_reading(name):
    """Yamareco の地点名の読み「 [せんまいこや]」を落とす。"""
    if name is None:
        return None
    k = name.find(" [")
    return name[:k] if k > 0 and name.endswith("]") else name


def _day_start_hours(route_day, day_index, params):
    """その日の出発時刻 [h]（0〜24）。multi_day.py と同じ規則: 距離で日を切る計画は
    出発時刻の設定（初日 start_time_hm、2日目以降 start_time_hm_rest）、それ以外は
    最初の点の時刻。時刻が無ければ None。"""
    from tozan.multi_day import _hm_to_hours
    if params.get("day_distance_km"):
        return _hm_to_hours(params["start_time_hm"] if day_index == 0 else params["start_time_hm_rest"])
    ts = route_day.points[0].timestamp if route_day.points else None
    if ts is None:
        return None
    return ts.hour + ts.minute / 60.0 + ts.second / 3600.0


def _clock(hours):
    """時刻 [h] を "HH:MM" に（24 時を超えたら翌日として 24 で割った余り）。"""
    if hours is None:
        return None
    total_min = int(round(hours * 60.0))
    return f"{(total_min // 60) % 24:02d}:{total_min % 60:02d}"


def waypoint_table(result: SimResult, route, params: dict) -> dict:
    """地点ごとの表（計画モード、2026-10-02）。

    日ごとに、地点名のある点（Yamareco の計画 GPX の <trkpt> の <name>）と、その日の
    出発点・到着点について、到着時刻・前の地点からの時間・距離（水平）・登り・下り・
    消費エネルギー・汗（leg_*）と、その日の出発からの累積（cum_*、時間は arrival_h、汗は sweat_kg_cum）を返す。
    画面は「区間」と「出発から」をボタンで切り替える（作者の要望 2026-10-02）。

    - 到着時刻は「その日の出発時刻 ＋ モデルの時間」。GPX に書いてある計画の通過時刻は使わない
    - 時間は前の地点の到着から（途中のまとまった補給の休憩を含む）
    - 距離は水平距離（YAMAP・Yamareco の表示と同じ測り方。1日の要約の distance_km は
      斜面に沿った長さなので、急な道では数 % 違う）
    - 消費エネルギーは plan_summary の kcal と同じ定義（metabolic_energy_data の合計）
    - 点の区間が長さ 0 で飛ばされた点は、その手前で最後に歩いた区間の終わりの値を使う
    - 2日目以降の出発点に名前が無ければ、前日の最後の地点名を使う（Yamareco は前日の
      最後の点にだけ小屋の名前を付けている）
    """
    from tozan.multi_day import split_route_into_days
    routes = split_route_into_days(route, params)
    out = []
    prev_last_name = None
    for d_i, (day, rday) in enumerate(zip(result.days, routes)):
        pts = rday.points
        start_h = _day_start_hours(rday, d_i, params)
        pidx = day.point_index_data
        t_end = day.time_end_data
        sweat = day.sweat_data
        energy = day.metabolic_energy_data

        # 歩いた区間の記録ごとに（終点の点の番号, 到着時刻, 累積の汗, 累積の消費エネルギー）
        walk = []
        e_cum = 0.0
        for k in range(len(pidx)):
            e_cum += energy[k]
            if pidx[k] >= 0:
                walk.append((pidx[k], t_end[k], sweat[k], e_cum))
        # 点 p に着いたときの値: 終点の番号が p 以下で最後の歩いた区間（番号は単調に増える）
        n_pts = len(pts)
        arrive_s, arrive_sweat, arrive_E = [], [], []
        j = -1
        last = (0.0, 0.0, 0.0)
        for p in range(n_pts):
            while j + 1 < len(walk) and walk[j + 1][0] <= p:
                j += 1
                last = walk[j][1:]
            arrive_s.append(last[0])
            arrive_sweat.append(last[1])
            arrive_E.append(last[2])

        marks = [p for p in range(n_pts) if p == 0 or p == n_pts - 1 or pts[p].name]
        rows = []
        prev = None
        cum_km = cum_up = cum_down = 0.0
        for p in marks:
            row = {
                "point_index": p,
                "name": _strip_reading(pts[p].name),
                "kind": "start" if p == 0 else ("end" if p == n_pts - 1 else "point"),
                "arrival_h": arrive_s[p] / 3600.0,
                "arrival_clock": _clock(None if start_h is None else start_h + arrive_s[p] / 3600.0),
                "sweat_kg_cum": arrive_sweat[p],
            }
            if prev is None:
                row.update(leg_h=0.0, leg_km=0.0, leg_up_m=0.0, leg_down_m=0.0, leg_kcal=0.0, leg_sweat_kg=0.0)
            else:
                seg = pts[prev + 1:p + 1]
                row.update(
                    leg_h=(arrive_s[p] - arrive_s[prev]) / 3600.0,
                    leg_km=sum(q.dist_m for q in seg) / 1000.0,
                    leg_up_m=sum(q.ele_diff for q in seg if q.ele_diff > 0),
                    leg_down_m=-sum(q.ele_diff for q in seg if q.ele_diff < 0),
                    leg_kcal=(arrive_E[p] - arrive_E[prev]) / 4184.0,
                    leg_sweat_kg=arrive_sweat[p] - arrive_sweat[prev],
                )
            cum_km += row["leg_km"]
            cum_up += row["leg_up_m"]
            cum_down += row["leg_down_m"]
            row.update(cum_km=cum_km, cum_up_m=cum_up, cum_down_m=cum_down,
                       cum_kcal=arrive_E[p] / 4184.0)
            if row["kind"] == "start" and row["name"] is None:
                row["name"] = prev_last_name
            rows.append(row)
            prev = p
        prev_last_name = rows[-1]["name"] if rows else None
        out.append({
            "date": str(day.date) if day.date is not None else None,
            "start_clock": _clock(start_h),
            "rows": rows,
        })
    return {"days": out}


# ---------------------------------------------------------------- 計画モードの天気
# 作者の判断（2026-10-03）: 日付を指定したら、今日から5日以内の日は天気予報、それより先の日は
# 過去10年の同じ時期（前後7日）・同じ時間帯の平均から、その日の出発地点の気温と湿度を出す。
# 縦走は日ごとの値を使う（day_T_air / day_RH / day_T_air_elevation）。過去の値は平均で、
# 「もっと暑いはず」と感じたら利用者が直す。日射は詳細設定の「天気」のまま（平均にすると
# 晴れた日の汗を少なく見積もるため）。
# 通信は画面（web/app.js）が行い、ここでは問い合わせの組み立てと平均だけを行う。

FORECAST_DAYS = 5
CLIMATE_YEARS = 10
CLIMATE_HALF_WINDOW_DAYS = 7
_OPEN_METEO = {
    "forecast": "https://api.open-meteo.com/v1/forecast",
    "past": "https://historical-forecast-api.open-meteo.com/v1/forecast",
    "climate": "https://archive-api.open-meteo.com/v1/archive",
}


def _iso(d):
    return d.isoformat()


def weather_request_plan(result: SimResult, route, params: dict, start_date_iso: str, today_iso: str) -> dict:
    """日ごとの出発地点・日付・歩く時間帯と、Open-Meteo への問い合わせ URL を返す。

    start_date_iso は1日目の日付（"YYYY-MM-DD"）。2日目以降は1日ずつ足す。
    歩く時間帯は、いったん計算した result の出発時刻と所要時間（時刻が無ければ 6:00 から）。
    座標は 0.01 度（約 1 km）に丸めて送る。
    """
    import datetime
    from tozan.multi_day import split_route_into_days
    routes = split_route_into_days(route, params)
    start = datetime.date.fromisoformat(start_date_iso)
    today = datetime.date.fromisoformat(today_iso)
    days = []
    for i, (day, rday) in enumerate(zip(result.days, routes)):
        p0 = rday.points[0]
        start_h = _day_start_hours(rday, i, params)
        if start_h is None:
            start_h = 6.0
        date = start + datetime.timedelta(days=i)
        offset = (date - today).days
        kind = "past" if offset < 0 else ("forecast" if offset <= FORECAST_DAYS else "climate")
        days.append({
            "day": i, "date": _iso(date), "kind": kind,
            "lat": round(p0.lat, 2), "lon": round(p0.lon, 2), "elevation_m": round(p0.ele),
            "start_h": start_h, "end_h": start_h + day.duration_h,
        })

    def url(base, ds, d0, d1):
        lat = ",".join(str(d["lat"]) for d in ds)
        lon = ",".join(str(d["lon"]) for d in ds)
        ele = ",".join(str(d["elevation_m"]) for d in ds)
        return (f"{base}?latitude={lat}&longitude={lon}&elevation={ele}"
                f"&hourly=temperature_2m,relative_humidity_2m&timezone=auto"
                f"&start_date={_iso(d0)}&end_date={_iso(d1)}")

    requests = []
    for kind in ("forecast", "past"):
        ds = [d for d in days if d["kind"] == kind]
        if ds:
            d0 = datetime.date.fromisoformat(ds[0]["date"])
            d1 = datetime.date.fromisoformat(ds[-1]["date"])
            requests.append({"kind": kind, "days": [d["day"] for d in ds], "url": url(_OPEN_METEO[kind], ds, d0, d1)})
    ds = [d for d in days if d["kind"] == "climate"]
    if ds:
        d0 = datetime.date.fromisoformat(ds[0]["date"])
        d1 = datetime.date.fromisoformat(ds[-1]["date"])
        for back in range(1, CLIMATE_YEARS + 1):
            y = today.year - back
            try:
                a = d0.replace(year=d0.year - (d0.year - y))
                b = d1.replace(year=d1.year - (d0.year - y))
            except ValueError:   # 2月29日
                a = d0.replace(year=y, day=28)
                b = d1.replace(year=d1.year - (d0.year - y), day=28)
            a -= datetime.timedelta(days=CLIMATE_HALF_WINDOW_DAYS)
            b += datetime.timedelta(days=CLIMATE_HALF_WINDOW_DAYS)
            requests.append({"kind": "climate", "year": y, "days": [d["day"] for d in ds],
                             "url": url(_OPEN_METEO["climate"], ds, a, b)})
    return {"days": days, "requests": requests}


def _hour_of(t):
    """"YYYY-MM-DDTHH:MM" から (日付, 時)。"""
    return t[:10], int(t[11:13]) + int(t[14:16]) / 60.0


def weather_from_responses(plan: dict, responses: list) -> dict:
    """Open-Meteo の応答（plan["requests"] と同じ順、各要素は地点ごとの JSON のリストまたは
    1地点なら dict）から、日ごとの気温 [℃] と湿度 [0〜1] を出す。

    予報と過去の日はその日、過去の平均は各年の同じ月日の前後7日について、歩く時間帯
    （出発〜到着、毎時の値）に入る時刻の値を平均する。時間帯に1時間も入らないときは
    いちばん近い時刻を使う。
    """
    import datetime
    by_day = {d["day"]: {"T": [], "RH": []} for d in plan["days"]}
    info = {d["day"]: d for d in plan["days"]}
    for req, resp in zip(plan["requests"], responses):
        locs = resp if isinstance(resp, list) else [resp]
        for day_idx, loc in zip(req["days"], locs):
            d = info[day_idx]
            target = datetime.date.fromisoformat(d["date"])
            if req["kind"] == "climate":
                center = target.replace(year=req["year"]) if not (target.month == 2 and target.day == 29) \
                    else target.replace(year=req["year"], day=28)
                ok_dates = {_iso(center + datetime.timedelta(days=k))
                            for k in range(-CLIMATE_HALF_WINDOW_DAYS, CLIMATE_HALF_WINDOW_DAYS + 1)}
            else:
                ok_dates = {d["date"]}
            h = loc["hourly"]
            best = None
            for t, temp, rh in zip(h["time"], h["temperature_2m"], h["relative_humidity_2m"]):
                if temp is None or rh is None:
                    continue
                date_s, hour = _hour_of(t)
                if date_s not in ok_dates:
                    continue
                if d["start_h"] <= hour <= d["end_h"]:
                    by_day[day_idx]["T"].append(temp)
                    by_day[day_idx]["RH"].append(rh)
                gap = min(abs(hour - d["start_h"]), abs(hour - d["end_h"]))
                if best is None or gap < best[0]:
                    best = (gap, temp, rh)
            if not by_day[day_idx]["T"] and best is not None:
                by_day[day_idx]["T"].append(best[1])
                by_day[day_idx]["RH"].append(best[2])
    out = []
    for d in plan["days"]:
        v = by_day[d["day"]]
        if not v["T"]:
            out.append({"day": d["day"], "date": d["date"], "kind": d["kind"], "T_air": None, "RH": None,
                        "elevation_m": d["elevation_m"], "n_hours": 0})
            continue
        out.append({"day": d["day"], "date": d["date"], "kind": d["kind"],
                    "T_air": round(sum(v["T"]) / len(v["T"]), 1),
                    "RH": round(sum(v["RH"]) / len(v["RH"]) / 100.0, 2),
                    "elevation_m": d["elevation_m"], "n_hours": len(v["T"])})
    return {"days": out}
