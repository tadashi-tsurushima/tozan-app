"""Pure-Python route data structures."""

from dataclasses import dataclass, field
import datetime


@dataclass
class RoutePoint:
    lat: float
    lon: float
    ele: float
    timestamp: datetime.datetime | None = None   # 表示用。予測には使わない
    # 前処理で算出する派生値
    dist_m: float = 0.0        # 直前の点からの水平距離
    ele_diff: float = 0.0      # 直前の点からの標高差


@dataclass
class Route:
    points: list[RoutePoint] = field(default_factory=list)
    date: datetime.date | None = None


def split_by_date(route: Route) -> list[Route]:
    """日付で分割する。pandas groupby('date') と同様にキーでソートする。"""
    groups: dict[datetime.date | None, list[RoutePoint]] = {}
    for p in route.points:
        d = p.timestamp.date() if p.timestamp is not None else None
        groups.setdefault(d, []).append(p)
    # pandas groupby の default sort=True に合わせる
    keys = sorted(groups.keys(), key=lambda x: (x is None, x))
    return [Route(points=groups[k], date=k) for k in keys]
