"""Pure-Python route data structures."""

from dataclasses import dataclass, field
import datetime


@dataclass
class RoutePoint:
    lat: float
    lon: float
    ele: float
    timestamp: datetime.datetime | None = None   # 表示用。予測には使わない
    # 前処理で算出する派生値
    dist_m: float = 0.0        # 直前の点からの水平距離
    ele_diff: float = 0.0      # 直前の点からの標高差
    # Yamareco の計画 GPX から読む（Phase 6-13、2026-09-26）。他の GPX では None。
    name: str | None = None        # <trkpt> の中の <name>（小屋・山頂・分岐などの地点名）
    track_name: str | None = None  # その点が属する <trk> の <name>（計画は "Day1".."DayN"）
    # 直前の点からの区間が「手を使わないと登れない／下れない」か（Phase 6-15、2026-09-27）。
    # 記録の欠落から見つける（loaders/gpx.py）。計画 GPX では常に False。
    hands: bool = False


@dataclass
class Route:
    points: list[RoutePoint] = field(default_factory=list)
    date: datetime.date | None = None


DAY_TRACK_PREFIX = "Day"


def has_day_tracks(route: Route) -> bool:
    """GPX の <trk> が "Day1".."DayN" で日ごとに分かれているか（Phase 6-13）。"""
    names = []
    for p in route.points:
        if p.track_name and (not names or names[-1] != p.track_name):
            names.append(p.track_name)
    if len(names) < 2:
        return False
    return all(n.startswith(DAY_TRACK_PREFIX) and n[len(DAY_TRACK_PREFIX):].isdigit()
               for n in names)


def split_by_track(route: Route) -> list[Route]:
    """<trk> の名前（"Day1".."DayN"）で分割する（Phase 6-13、2026-09-26）。

    Yamareco の計画 GPX は日ごとに <trk> を分けて出し、各日の時刻も計画どおりに
    振ってある（初日 08:00、2日目以降 05:00 など）。YAMAP の計画 GPX が宿泊地も
    日の区切りも持たず全体を1本の線で出すのとは対照的で、こちらは何も入力せずに
    多日の計画として計算できる。
    """
    days = []
    cur_name = None
    cur = []
    for p in route.points:
        if p.track_name != cur_name:
            if cur:
                days.append(cur)
            cur_name = p.track_name
            cur = []
        cur.append(p)
    if cur:
        days.append(cur)
    out = []
    for pts in days:
        d = pts[0].timestamp.date() if pts[0].timestamp else None
        out.append(Route(points=pts, date=d))
    return out


def split_by_distance(route: Route, day_km) -> list[Route]:
    """1日ごとの距離[km]で分割する（Phase 6-12、2026-09-25）。

    計画用の GPX は宿泊地の情報を持たず、時刻も推定ペースで均等に振られた合成値
    なので、日付では切れない。利用者が入れた1日ごとの距離を累積して、その距離に
    いちばん近い点で切る。距離は水平距離（YAMAP の表示と一致する）。

    最後の日の指定は使わない ―― 残り全部が最終日になる。
    """
    pts = route.points
    if not day_km or len(pts) < 2:
        return [Route(points=pts, date=route.date)]

    cum = [0.0]
    for p in pts[1:]:
        cum.append(cum[-1] + p.dist_m)
    total_m = cum[-1]

    targets = []
    acc = 0.0
    for km in list(day_km)[:-1]:
        acc += float(km) * 1000.0
        if 0.0 < acc < total_m:
            targets.append(acc)

    days = []
    start = 0
    for t in targets:
        i = min(range(start + 1, len(pts)), key=lambda k: abs(cum[k] - t))
        if i <= start:
            continue
        days.append(Route(points=pts[start:i + 1], date=None))
        start = i
    days.append(Route(points=pts[start:], date=None))
    return days


def split_by_date(route: Route) -> list[Route]:
    """日付で分割する。pandas groupby('date') と同様にキーでソートする。"""
    groups: dict[datetime.date | None, list[RoutePoint]] = {}
    for p in route.points:
        d = p.timestamp.date() if p.timestamp is not None else None
        groups.setdefault(d, []).append(p)
    # pandas groupby の default sort=True に合わせる
    keys = sorted(groups.keys(), key=lambda x: (x is None, x))
    return [Route(points=groups[k], date=k) for k in keys]
