"""心拍のモデル（M-6-7、2026-10-02 に simulate_day から分離）。

心拍と酸素摂取量の直線（安静点と最大点を結ぶ。M-7b、高度の補正は Phase 5-1）、
目標強度から出す有酸素の天井（しゃりばての上限を含む。Phase 4b-2）、
実際に使った代謝からの心拍の目標と時定数での更新（Phase 3-1）。
休憩中の心拍の回復は tozan/heart_rate.py。
式は simulate_day にあったものを文字単位でそのまま移した（出力不変）。
使われていなかった P_met_fixed_ratio（docs/06_ §5 ⓝ）はこのとき削除した
（作者承認 2026-10-02）。
"""

import math

from tozan.constants import E_O2_J_per_L
from tozan.environment import P_O2


def o2_line(elevation_m, T_air_seg, VO2_L_per_min, P_O2_std, PWR_rest_W, HR_rest, params):
    """その区間の心拍と酸素摂取量の直線。(O2_pulse_ml_per_beat, VO2_offset_ml_per_min) を返す。"""
    elevation_diff = elevation_m - params["T_air_elevation"]
    absolute_humidity_ratio = math.exp(-elevation_diff / 2000.0)
    RH_seg = params["RH"] * absolute_humidity_ratio
    P_O2_seg = P_O2(T_air_seg, RH_seg, elevation_m)

    # 心拍と酸素摂取量の関係。安静点 (HR_rest, 安静時代謝) と最大点 (HR_max, VO2max)
    # を結ぶ直線で、O2_pulse_ml_per_beat はその傾き、VO2_offset_ml_per_min は切片。
    #   順方向 VO2 = O2_pulse * HR + VO2_offset
    #   逆方向 HR  = (VO2 - VO2_offset) / O2_pulse
    # 旧実装は原点を通る直線（VO2_offset = 0、傾きは最大時の1拍あたり）で、
    # 低心拍側で酸素摂取量を過大に出していた。心拍105での強度を、依頼者の平地
    # ウォーキングの実測 + ACSM 歩行式は31%、Fick の式から引いた曲線は34%と
    # 出すのに対し、旧実装は55%と出す（docs/06_ M-7b）。
    # 安静時代謝は高度で下がらないので P_O2_seg で補正しない。
    #
    # 高所での VO2max の低下（Phase 5-1、2026-09-22）。吸気酸素分圧 P_O2 の
    # 計算（標準大気・Tetens・体積分率 0.2095）はそのままで、そこから VO2max への
    # 伝達だけを po2_to_vo2max_ratio（0.60）で縮める。ヘモグロビンの解離曲線が
    # 上端で平らなので、動脈血酸素飽和度は吸気酸素分圧ほど下がらないため。
    # 以前は比例させており（伝達率 1.0 相当）、高所の VO2max を文献
    # （Wehrlin & Hallén 2006、-6.3%/1000m）の約2倍下げて心拍を押し上げていた。
    VO2_max_ml_per_min = VO2_L_per_min * max(
        0.0, 1.0 - params["po2_to_vo2max_ratio"] * (1.0 - P_O2_seg / P_O2_std)) * 1000
    VO2_rest_ml_per_min = PWR_rest_W * 60.0 / E_O2_J_per_L * 1000
    O2_pulse_ml_per_beat = (VO2_max_ml_per_min - VO2_rest_ml_per_min) / max(1e-6, params["HR_max"] - HR_rest)
    VO2_offset_ml_per_min = VO2_rest_ml_per_min - O2_pulse_ml_per_beat * HR_rest
    return O2_pulse_ml_per_beat, VO2_offset_ml_per_min


def aerobic_ceiling(current_HR, ratio_eff, O2_pulse_ml_per_beat, VO2_offset_ml_per_min,
                    max_fat_power_W, state, params):
    """目標強度で出せる代謝パワーの天井 P_met_limit_W_env [W] を返す。"""
    oxygen_demand_ml_per_min = params["vo2max_ml_kg_min"] * params["weight_kg"] * ratio_eff
    HR_demand = min(params["HR_max"], (oxygen_demand_ml_per_min - VO2_offset_ml_per_min) / O2_pulse_ml_per_beat)

    # 循環依存を解消：available_VO2の計算で、current_HRではなく目標心拍数（HR_demand）を使う
    # これにより、初期の低い心拍数による制限を回避し、実際の代謝需要に基づいたパワーを発揮できる
    HR_for_available_VO2 = max(current_HR, HR_demand)  # 現在の心拍数と目標心拍数の大きい方を使用
    available_VO2 = (HR_for_available_VO2 * O2_pulse_ml_per_beat + VO2_offset_ml_per_min) / 1000.0
    P_met_limit_W_env = available_VO2 * E_O2_J_per_L / 60.0

    # しゃりばて（Phase 4b-2、2026-09-22）。前ステップで肝が空かつ吸収中の糖もなければ、
    # 血糖の供給源が無い。出せる代謝パワーは脂肪の酸化速度の上限（0.5 g/分 ＝ 約 308 W）
    # ＋ 吸収中の糖 まで。食べて吸収が始まれば戻る（作者: 燃やすものを入れれば戻る）。
    if state.hypoglycemic:
        P_met_limit_W_env = min(P_met_limit_W_env, max_fat_power_W + state.absorbed_W_last)
    return P_met_limit_W_env


def update_heart_rate(current_HR, P_met_used, ratio_eff, dz, dt_seg, O2_pulse_ml_per_beat,
                      VO2_offset_ml_per_min, PWR_rest_W, HR_rest, params):
    """心拍を1区間ぶん更新する。(current_HR, P_met_actual, P_met_limit_W_env_eff) を返す。

    P_met_actual は実際に使った代謝（安静時代謝込み）、P_met_limit_W_env_eff は
    更新後の心拍で取り込める酸素の量。どちらも熱収支に渡す。
    """
    # 目標強度（ratio_eff）での心拍。心拍目標の上限に使う
    oxygen_demand_ml_per_min_eff = params["vo2max_ml_kg_min"] * params["weight_kg"] * ratio_eff
    HR_demand_eff = min(params["HR_max"], (oxygen_demand_ml_per_min_eff - VO2_offset_ml_per_min) / O2_pulse_ml_per_beat)

    # 心拍目標は、実際に使う代謝パワーから出す。登り・下り・平地で同じ式
    # （Phase 3-1、2026-09-21）。以前は下りと平地だけ旧式のエネルギー項
    # （E_horizontal / E_vertical を dt_seg で割ったもの）から出し、下りには
    # 床 HR_min_downhill_bpm を当てていた。床は外す。実測（塔ノ岳の下り）では
    # 急な登りの直後に心拍が落ちきらないのは時定数（下り 90 秒）で表現できる
    # 量であり、床で持ち上げると緩い下りの速度まで床が決めてしまう。
    P_met_actual = P_met_used + PWR_rest_W
    O2_target_ml_per_min_eff = P_met_actual / E_O2_J_per_L * 1000 * 60
    HR_target_bpm_eff = min(params["HR_max"], (O2_target_ml_per_min_eff - VO2_offset_ml_per_min) / O2_pulse_ml_per_beat)
    HR_target_bpm_eff = min(HR_demand_eff, HR_target_bpm_eff)

    # 心拍の上昇速度の上限で dt_seg とパワーを出し直す再計算ブロックは外した
    # （Phase 3-1、2026-09-21）。速度は上の C(i) と歩行上限だけで決まる。
    # 心拍の上昇速度の上限は、下の心拍の更新にだけ残る。
    # 以前はここで下りの心拍目標（旧式のエネルギー項から）を HR_achievable で
    # 切った値からパワーを出し直し、急な下りで天井を超えるパワー（810 W）で
    # 速度を決めていた（docs/06_ Phase 3）。

    # 心拍数の更新（時定数を考慮）
    tau = 90.0 if dz < 0 else 20.0  # 下り90秒、登り20秒
    beta = min(dt_seg / tau, 1.0)
    # 登り時はbetaの最小値を設定して、心拍数の上昇を速くする
    if dz > 0:
        beta = max(beta, 0.4)  # 最小値0.4を保証
    hr_change = beta * (HR_target_bpm_eff - current_HR)
    # 心拍数の上昇速度の上限を適用
    max_hr_increase_per_sec = params.get("max_hr_increase_per_sec", 5.0)
    max_hr_change = max_hr_increase_per_sec * dt_seg  # [bpm]
    if hr_change > 0:  # 上昇時のみ上限を適用
        hr_change = min(hr_change, max_hr_change)
    current_HR += hr_change
    current_HR = max(current_HR, HR_rest)

    #available_VO2_eff = current_HR * O2_pulse_ml_per_beat / 1000.0
    available_VO2_eff = (max(current_HR, HR_target_bpm_eff) * O2_pulse_ml_per_beat + VO2_offset_ml_per_min) / 1000.0
    P_met_limit_W_env_eff = available_VO2_eff * E_O2_J_per_L / 60.0
    return current_HR, P_met_actual, P_met_limit_W_env_eff
