"""熱収支と発汗（M-6-2、2026-10-02 に simulate_day から分離）。

部品（皮膚温・放射・対流・日射・衣服を通した蒸発・深部体温の更新）は
tozan/environment.py にあり、ここはそれを1区間ぶん組み立てる。
式は simulate_day にあったものを文字単位でそのまま移した（出力不変）。
"""

import math

from tozan.constants import L_v_J_per_kg
from tozan.environment import (h_c_of_v_elevation, p_sat_kPa, radiative_h, skin_temperature_C,
                               solar_gain_W, sweat_for_cooling, update_core_temperature,
                               wind_at_body_ms)


def _sweat_through_clothing(Q_cool_J, dt_s, T_core, T_air_C, elevation_m, h_c, A_body, C_body, params):
    """体を Q_cool_J 冷やすのに出る汗 [kg] と、冷やしきれなかった熱で上がった深部体温を返す
    （Phase 7-2、2026-09-29）。use_clothing_evaporation が False なら従来どおり
    汗 = Q_cool_J / 蒸発潜熱 で、体温は変えない。

    外気の水蒸気圧は、登山口（T_air_elevation）の湿度 RH と気温 T_air から出した値を、
    標高差 2000 m で e 分の1 に減らす（前任者の論文の exp(−Δh/2000) を湿度ではなく
    水蒸気圧に当てはめる。気温の低下による飽和水蒸気圧の低下を二重に数えないため）。
    """
    if Q_cool_J <= 0.0:
        return 0.0, T_core
    if not params["use_clothing_evaporation"]:
        return Q_cool_J / L_v_J_per_kg, T_core
    E_req_W = Q_cool_J / max(1e-9, dt_s)
    P_a_kPa = (params["RH"] * p_sat_kPa(params["T_air"])
               * math.exp(-(elevation_m - params["T_air_elevation"]) / 2000.0))
    S_W, cooled_W = sweat_for_cooling(
        E_req_W, P_a_kPa, T_air_C, h_c, params["R_cloth"], A_body,
        skin_temperature_C(T_air_C, params), params["lewis_ratio_K_per_kPa"], params["sweat_efficiency_a"])
    # 冷やしきれない熱は体に溜まり、体温が目標値を超えて上がる（代償できない暑さ）
    T_core += (E_req_W - cooled_W) * dt_s / C_body
    return S_W * dt_s / L_v_J_per_kg, T_core


def rest_heat_step(T_core, elevation_m, PWR_rest_W, dt_rest_step, A_body, C_body, params):
    """休憩中の1ステップの熱収支。(T_core, sweat_rest_kg) を返す。"""
    # 休憩中の熱収支（Phase 7-1、2026-09-29）。以前は休憩中に体温も汗も
    # 計算していなかった。代謝は安静時代謝、機械仕事はゼロ、対流は自然対流。
    T_air_rest = params["T_air"] - params["lapse_rate"] * (elevation_m - params["T_air_elevation"])
    h_c_rest = h_c_of_v_elevation(wind_at_body_ms(elevation_m, params), elevation_m, T_air_rest)
    h_r_rest = radiative_h(skin_temperature_C(T_air_rest, params), T_air_rest, params)
    U_rest = 1.0 / (params["R_cloth"] + 1.0 / (h_c_rest + h_r_rest))
    Q_conv_rest = U_rest * A_body * (skin_temperature_C(T_air_rest, params) - T_air_rest)   # 皮膚温で（Phase 7-3）
    T_core, Q_evap_rest_J = update_core_temperature(
        T_core, PWR_rest_W - Q_conv_rest + solar_gain_W(elevation_m, h_c_rest, h_r_rest, A_body, params),
        PWR_rest_W, PWR_rest_W, dt_rest_step,
        C_body, params["weight_kg"], params["T_core_init"], params["core_temp_rise_per_W_kg"],
        params["use_thermal_storage"])
    sweat_rest_kg, T_core = _sweat_through_clothing(
        Q_evap_rest_J, dt_rest_step, T_core, T_air_rest, elevation_m, h_c_rest, A_body, C_body, params)
    return T_core, sweat_rest_kg


def walk_heat_step(T_core, dist3d, dt_seg, elevation_m, T_air_seg, P_met_actual, P_met_limit_W_env_eff,
                   P_mech_used, PWR_rest_W, A_body, C_body, params):
    """歩行中の1区間の熱収支。(T_core, sweat_kg) を返す。"""
    v = dist3d / max(1e-6, dt_seg)

    # 外気の風を歩く速さと合成する（向きはばらばらとみなす。Phase 7-5）
    v_air = math.sqrt(v * v + wind_at_body_ms(elevation_m, params) ** 2)
    h_c = h_c_of_v_elevation(v_air, elevation_m, T_air_seg)
    # 放射（Phase 7-3、2026-09-29）。対流と並列に外気へ逃げる。蒸発（ルイスの関係）には
    # 対流の h_c だけを使う。
    h_r = radiative_h(skin_temperature_C(T_air_seg, params), T_air_seg, params)
    R_conv = 1.0 / (h_c + h_r) if (h_c + h_r) > 0 else 1e9
    R_total = params["R_cloth"] + R_conv
    U = 1.0 / R_total if R_total > 0 else 0.0
    # 乾いた放熱は皮膚から外気へ（Phase 7-3、2026-09-29）。以前は深部体温 − 気温で、
    # 皮膚温より 3〜4℃ 高い温度差で放熱を過大に見積もっていた。気温が皮膚温より高ければ
    # 外気から熱が入る（切り捨てない）。
    Q_conv = U * A_body * (skin_temperature_C(T_air_seg, params) - T_air_seg)

    # 熱収支（Phase 7-1、2026-09-29）。以前は余った熱を max(0, …) で切り捨て、
    # 固定の上限 T_core_limit（38.0℃）まで溜めてから汗にしていたため、体温が
    # 上限に張り付き、下がる経路が無かった。
    # 熱源は実際に使った代謝 P_met_actual（P_met_used + 安静時代謝。心拍と同じ値）
    # （⑪、Phase 7-4、2026-09-29）。以前は供給可能量 P_met_limit_W_env_eff で、
    # 歩行の上限で歩く区間（平地・緩い下り）の熱を大きく見積もっていた。
    # ただし酸素の供給可能量を上限にする。疲労で筋効率が下がると P_met_used は
    # 供給可能量を超える計算になるが、熱は取り込んだ酸素の分しか出せない。
    P_heat_W = min(P_met_actual, P_met_limit_W_env_eff)
    Q_sun_W = solar_gain_W(elevation_m, h_c, h_r, A_body, params)   # 日射（Phase 7-5）
    Q_net_W = P_heat_W - P_mech_used - Q_conv + Q_sun_W
    T_core, Q_evap_J = update_core_temperature(
        T_core, Q_net_W, P_heat_W - P_mech_used, PWR_rest_W, dt_seg,
        C_body, params["weight_kg"], params["T_core_init"], params["core_temp_rise_per_W_kg"],
        params["use_thermal_storage"])
    sweat_kg, T_core = _sweat_through_clothing(
        Q_evap_J, dt_seg, T_core, T_air_seg, elevation_m, h_c, A_body, C_body, params)
    sweat_kg = max(0.0, sweat_kg)
    return T_core, sweat_kg
