"""Physical constants used by the simulation core."""

g = 9.80665
E_O2_J_per_L = 20900
L_v_J_per_kg = 2430000

# Walking efficiency factor
WALK_EFF = 0.10

J_PER_KCAL = 4184.0
