"""Default input parameters (former juso_060.params)。

既定値は contract/params.json を単一の真実として読む（Step 4-4）。
tozan/day.py の setdefault と tozan/local_glycogen.py の params.get の
既定値は、この dict に同じキーが載るため実質 no-op になる（そちらは削除しない）。
"""

import json
from pathlib import Path

_CONTRACT_PATH = Path(__file__).resolve().parent.parent / "contract" / "params.json"

with open(_CONTRACT_PATH, encoding="utf-8") as _f:
    PARAMS_CONTRACT = json.load(_f)

DEFAULT_PARAMS = {key: entry["default"] for key, entry in PARAMS_CONTRACT.items()}
