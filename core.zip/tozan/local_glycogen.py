"""Local muscle-group glycogen and fatigue."""

import logging
import math

logger = logging.getLogger(__name__)


# ===== NEW (047): Local muscle-group glycogen utilities =====

def _localglyco_init_if_needed(params, state, total_glycogen_J):
    """Initialize local muscle glycogen/liver pools and eccentric fatigue state if not present."""
    from tozan.state import glycogen_capacity_kcal, liver_capacity_g
    J_per_kcal = 4184.0
    if state.local_gly is not None:
        return
    shares = params.get("local_muscle_shares", [0.55, 0.30, 0.15])
    assert abs(sum(shares) - 1.0) < 1e-6

    # 初期プール: 肝は容量 × 充填率（Phase 4b-2）、残りを筋へ
    liver_kcal = liver_capacity_g(params) * 4.0  # 1g=4kcal
    liver_J = min(total_glycogen_J, liver_kcal * J_per_kcal * params["liver_fill_ratio_init"])
    muscle_total_J = max(0.0, total_glycogen_J - liver_J)

    A_J = muscle_total_J * shares[0]
    B_J = muscle_total_J * shares[1]
    C_J = muscle_total_J * shares[2]

    # 部位の残存率の分母（*_init）は出発時の量ではなく容量（Phase 4b-0、2026-09-22）。
    # 枯渇の閾値（20%）が容量に対する絶対濃度の目安になる。
    muscle_cap_J = max(0.0, glycogen_capacity_kcal(params) * J_per_kcal - liver_kcal * J_per_kcal)

    state.local_gly = {
        "A_J": A_J, "B_J": B_J, "C_J": C_J, "Liver_J": liver_J,
        "A_init": muscle_cap_J * shares[0], "B_init": muscle_cap_J * shares[1],
        "C_init": muscle_cap_J * shares[2], "Liver_init": liver_kcal * J_per_kcal,
        "ecc_A": 0.0, "ecc_B": 0.0,
        "fatigue_A": 0.0, "fatigue_B": 0.0, "fatigue_C": 0.0  # 各部位の疲労時間（秒）
    }


def _localglyco_add_supplement(params, state, supplement_amount_J):
    """Add supplement energy to local glycogen pools with proper distribution."""
    from tozan.state import liver_capacity_g
    _localglyco_init_if_needed(params, state, 0.0)  # 初期化を保証
    st = state.local_gly

    # 需要を超えた分（余り）は筋へ入れ、筋が満タンのときだけ肝へ
    # （Phase 6-11、2026-09-25）。
    #
    # Phase 4b-2 では「まず肝（血糖）に入り、容量を超えた分だけ筋へ」としていた。
    # ところが、まとまった補給の15分の休憩中は需要がほぼゼロなのに吸収は続くので、
    # 摂った糖のほとんどが余りになり、その全部が肝に入る。食べるたびに肝が満タンへ
    # 押し上げられ、**筋が空になっているのに肝だけ貯まる**（雲ノ平5日では筋が2日
    # 連続でゼロなのに肝が 72% まで貯まっていた）。しゃりばての判定は「肝が空かつ
    # 吸収なし」なので、肝が毎回補充されると一日発火しない（作者が実機で気づいた:
    # 「一回おにぎり食べたらあとは一日しゃりばてしないというのもちょっと違和感」）。
    #
    # 実測は逆を言っている。運動中に摂った糖は筋へ行き、肝は貯め直されない。
    #   ・60 g/h で筋グリコーゲンは約40%節約されるが、肝はプラセボと同じだけ減る
    #     （doi:10.1152/ajpendo.00139.2026）
    #   ・102 g/h でようやく肝が横ばい（増えない）
    #     （Gonzalez ら 2015、doi:10.1152/ajpendo.00376.2015）
    #
    # 筋の空き（容量 − 残量）に比例して配る。部位ごとの容量は *_init（Phase 4b-0 で
    # 出発時の量ではなく容量になっている）。
    keys = ("A_J", "B_J", "C_J")
    caps = ("A_init", "B_init", "C_init")
    room = [max(0.0, st[c] - st[k]) for k, c in zip(keys, caps)]
    total_room = sum(room)
    muscle_supplement = min(supplement_amount_J, total_room)
    if total_room > 0.0:
        for k, r in zip(keys, room):
            st[k] += muscle_supplement * r / total_room

    # 筋が満タンなら残りは肝へ（容量まで）
    liver_supplement = supplement_amount_J - muscle_supplement
    if liver_supplement > 0.0:
        liver_cap_J = liver_capacity_g(params) * 4.0 * 4184.0
        st["Liver_J"] = min(liver_cap_J, st["Liver_J"] + liver_supplement)


def _localglyco_update_from_total(params, state, total_glycogen_J):
    """Update local glycogen pools to match total_glycogen_J, preserving relative distribution if pools exist."""
    J_per_kcal = 4184.0
    shares = params.get("local_muscle_shares", [0.55, 0.30, 0.15])
    assert abs(sum(shares) - 1.0) < 1e-6

    if state.local_gly is None:
        # 初期化されていない場合は初期化
        _localglyco_init_if_needed(params, state, total_glycogen_J)
        return

    st = state.local_gly
    current_total = st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]

    if current_total <= 0:
        # 現在の合計が0以下の場合は初期化
        _localglyco_init_if_needed(params, state, total_glycogen_J)
        return

    # 現在の合計と目標合計の差分を計算
    supplement_amount = total_glycogen_J - current_total

    if supplement_amount > 0:
        # 補給分を比例配分
        _localglyco_add_supplement(params, state, supplement_amount)
    elif supplement_amount < 0:
        # 減少分を比例配分（各部位から均等に減らす）
        reduction_ratio = total_glycogen_J / current_total
        st["A_J"] *= reduction_ratio
        st["B_J"] *= reduction_ratio
        st["C_J"] *= reduction_ratio
        st["Liver_J"] *= reduction_ratio


def _recruit_fractions_from_grade(grade):
    """Return (A,B,C) recruitment fractions depending on grade (dz/dx).

    文献に基づく分配率の根拠：
    - 登り：大腿四頭筋（A）が主にコンセントリック収縮で活動
    - 下り：大腿四頭筋（A）が主にエキセントリック収縮でブレーキ動作、体幹・腕（C）はバランス保持程度
    - 水平：全身がバランスよく使用

    参考文献の知見：
    - 下り坂では大腿四頭筋が主に活動（エキセントリック収縮）
    - 体幹・腕の筋活動は比較的少ない
    - 下腿（B）は補助的な役割
    """
    if grade >= 0.25:      # 急登
        A, B, C = 0.70, 0.25, 0.05  # 大腿・殿部がより強調（コンセントリック収縮）
    elif grade >= 0.10:    # 登り
        A, B, C = 0.62, 0.28, 0.10  # 大腿・殿部が主（コンセントリック収縮）
    elif grade > -0.10:    # ほぼ水平
        A, B, C = 0.45, 0.25, 0.30
    elif grade > -0.25:    # 緩い下り
        A, B, C = 0.60, 0.25, 0.15  # 腿が主（ブレーキ動作）、体幹・腕は少ない
    else:                  # 急な下り
        A, B, C = 0.65, 0.25, 0.10  # 腿がさらに主（ブレーキ動作）、体幹・腕はさらに少ない
    s = A + B + C
    return A/s, B/s, C/s


def _localglyco_update_and_fatigue(params, state, E_total_J, E_from_glyc_J, dt, dz, intensity, intensity_threshold=0.65, fatigue_recovery_rate=0.05):
    """Consume glycogen from local pools according to recruitment and compute local fatigue factor.
    Returns: (local_factor, updated_total_glycogen_J, local_fatigue_factor, local_damage_factor)
    """
    J_per_kcal = 4184.0
    st = state.local_gly

    # 勾配（grade）は simulate_day 側で毎ステップ設定する
    grade = float(state.last_grade)
    A_frac, B_frac, C_frac = _recruit_fractions_from_grade(grade)

    # 肝由来の糖（血糖）を一部割り当て
    from_liver_frac = params.get("from_liver_frac", 0.25)
    gly_from_liver = E_from_glyc_J * from_liver_frac
    gly_from_muscle = E_from_glyc_J - gly_from_liver

    # 肝プールから引く
    used_liver = min(st["Liver_J"], gly_from_liver)
    st["Liver_J"] -= used_liver
    lack_liver = gly_from_liver - used_liver

    # 筋群プールから引く
    dA = gly_from_muscle * A_frac
    dB = gly_from_muscle * B_frac
    dC = gly_from_muscle * C_frac

    use_A = min(st["A_J"], dA); st["A_J"] -= use_A; lack_A = dA - use_A
    use_B = min(st["B_J"], dB); st["B_J"] -= use_B; lack_B = dB - use_B
    use_C = min(st["C_J"], dC); st["C_J"] -= use_C; lack_C = dC - use_C

    # 不足分（lack_*）は脂で代替→効率低下は local_factor で表現（性能低下を強めに反映）
    total_lack = max(0.0, lack_liver) + max(0.0, lack_A) + max(0.0, lack_B) + max(0.0, lack_C)

    # 遠心性疲労（下り）
    #
    # 損傷は吸収した負の仕事に比例するので、下った高さ（-dz）だけに比例させる。
    # 区間ごとの高度差の合計は総下降量になるので、GPXの点の密度に依存しない。
    #
    # 以前は (-dz) * (区間のエネルギー[kcal]) という、区間ごとの量を2つ掛けた形
    # だった。点を半分に間引くと各項が4倍・個数が半分で合計が2倍になる。実際に
    # 塔ノ岳のGPXを間引くと、同じ山行なのに筋効率の最終値が 0.853 -> 0.588 と
    # 変わった。サンプル間隔の粗い多日ルート（黒戸48秒・白峰59秒。日帰りは
    # 18〜24秒）が余計に疲労していた（M-10-1、2026-09-21）。
    # 回復（Phase 4b-1、2026-09-22）: 損傷は時定数 ecc_recovery_time_constant_h で
    # 指数関数的に戻る。行動中も睡眠中も同じ速さ（修復は運動していなくても進む）。
    # 以前は日内も翌朝も回復がなく、縦走では溜まる一方だった。
    tau_ecc_s = params["ecc_recovery_time_constant_h"] * 3600.0
    decay = math.exp(-dt / tau_ecc_s)
    st["ecc_A"] *= decay
    st["ecc_B"] *= decay
    if dz < -0.05:
        ecc_k = params.get("ecc_fatigue_k", 0.0002)
        ecc_load = -dz  # 下った高さ [m]
        st["ecc_A"] += ecc_k * A_frac * ecc_load
        st["ecc_B"] += ecc_k * B_frac * ecc_load

    # 部位別疲労蓄積・回復の計算
    fitness_level = params.get("fitness_level", 1.0)
    fatigue_base_rate = params.get("fatigue_base_rate", 0.02)
    min_eff = params.get("min_muscle_efficiency_multiplier", 0.65) - 0.1 * (1.0 - fitness_level)

    # 部位の強度（Phase 4b-3、2026-09-22）: 全身の VO2max 比 × その部位の募集率 ÷ 容量比。
    # 急登では大腿・殿部（A、募集率 0.62〜0.70、容量比 0.55）だけが全身より高くなる
    # （作者: 丹沢主脈の蛭ヶ岳の登りは大腿に来る）。閾値は cp_ratio（持続できる強度）。
    # 部位ごとに、閾値を超えて働いた時間を溜め、下回れば時定数で戻す（以前は「閾値未満
    # かつ下り」のときだけ回復し、因子は閾値を割った瞬間に 1.0 へ跳ね戻っていた）。
    shares_i = params.get("local_muscle_shares", [0.55, 0.30, 0.15])
    I_A = intensity * A_frac / max(1e-6, shares_i[0])
    I_B = intensity * B_frac / max(1e-6, shares_i[1])
    I_C = intensity * C_frac / max(1e-6, shares_i[2])
    tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
    for key, I_g in (("fatigue_A", I_A), ("fatigue_B", I_B), ("fatigue_C", I_C)):
        if I_g >= intensity_threshold:
            st[key] += dt
        else:
            st[key] = max(0.0, st[key] * math.exp(-dt / tau_recovery_seconds))

    # 各部位の疲労因子を計算
    fatigue_hours_A = st["fatigue_A"] / 3600.0
    fatigue_hours_B = st["fatigue_B"] / 3600.0
    fatigue_hours_C = st["fatigue_C"] / 3600.0

    # 疲労率は強度の2乗に比例（各部位の募集率を考慮）
    # 疲労率は部位の強度の2乗に比例（募集率は部位の強度に含まれている）
    fatigue_rate_A = fatigue_base_rate * (I_A ** 2) / fitness_level
    fatigue_rate_B = fatigue_base_rate * (I_B ** 2) / fitness_level
    fatigue_rate_C = fatigue_base_rate * (I_C ** 2) / fitness_level

    # 疲労因子を計算（指数関数的低下）
    fatigue_factor_A = math.exp(-fatigue_rate_A * fatigue_hours_A) if fatigue_rate_A > 0 else 1.0
    fatigue_factor_B = math.exp(-fatigue_rate_B * fatigue_hours_B) if fatigue_rate_B > 0 else 1.0
    fatigue_factor_C = math.exp(-fatigue_rate_C * fatigue_hours_C) if fatigue_rate_C > 0 else 1.0

    # 下限を適用
    fatigue_factor_A = max(min_eff, fatigue_factor_A)
    fatigue_factor_B = max(min_eff, fatigue_factor_B)
    fatigue_factor_C = max(min_eff, fatigue_factor_C)

    # 最も疲労が激しい部位の疲労因子を採用（最小値を取る）
    local_fatigue_factor = min(fatigue_factor_A, fatigue_factor_B, fatigue_factor_C)

    # 残量比
    def rem(cur, init):
        return max(0.0, cur / max(1e-6, init))
    rA = rem(st["A_J"], st["A_init"])
    rB = rem(st["B_J"], st["B_init"])
    rC = rem(st["C_J"], st["C_init"])

    # 遠心性ペナルティ
    ecc_pen_A = 1.0 / (1.0 + st["ecc_A"])
    ecc_pen_B = 1.0 / (1.0 + st["ecc_B"])

    # 局所グリコーゲン枯渇による筋効率低下：シグモイド関数で閾値効果を適用
    # 全身平均と同じく、低残存率でのみ影響を大きくする（20%以下で効果開始）
    local_k = params.get("local_sigmoid_k", 8.0)
    local_x0 = params.get("local_sigmoid_x0", 0.2)  # 20%残量で効果開始

    def local_glycogen_penalty(ratio):
        """局所グリコーゲン残存率に対するペナルティ（枯渇時のみ影響）"""
        if ratio >= 1.0:
            return 1.0
        # シグモイド関数：20%以下で急激にペナルティが増加
        sigmoid_factor = 1.0 / (1.0 + math.exp(-local_k * (local_x0 - ratio)))
        # ペナルティは最大で30%まで（全身平均と同様）
        c_local = params.get("local_glycogen_eff_c", 0.3)
        return max(0.75, 1.0 - c_local * sigmoid_factor)

    # 各筋群のグリコーゲンペナルティを計算
    pen_A = local_glycogen_penalty(rA) * ecc_pen_A
    pen_B = local_glycogen_penalty(rB) * ecc_pen_B
    pen_C = local_glycogen_penalty(rC)

    # 加重調和平均（弱い鎖を強調）
    weights = [A_frac, B_frac, C_frac]
    comps = [pen_A, pen_B, pen_C]
    denom = sum(w / max(1e-6, c) for w, c in zip(weights, comps))
    local_factor = min(1.0, max(params.get("local_factor_floor", 0.60), sum(weights) / denom))

    # 遠心性損傷だけの加重調和平均（M-11-1、2026-09-21）
    #
    # local_factor は「局所グリコーゲンの残量（燃料）」と「遠心性の筋損傷（疲労）」の
    # 積を平均したものなので、これを所要時間に繋ぐと、実際には起きていない
    # ハンガーノックまで歩く速さに効いてしまう。疲労の側だけを取り出した因子を
    # ここで別に作る。上限・下限は local_factor と同じ扱いにする。
    # C 群（体幹・上肢）には遠心性のペナルティが無いので 1.0。
    damage_comps = [ecc_pen_A, ecc_pen_B, 1.0]
    damage_denom = sum(w / max(1e-6, c) for w, c in zip(weights, damage_comps))
    local_damage_factor = min(1.0, max(params.get("local_factor_floor", 0.60), sum(weights) / damage_denom))

    if params.get("localglyco_debug", False):
        logger.debug(f"LocalGly: grade={grade:.2f}, rA={rA:.2f}, rB={rB:.2f}, rC={rC:.2f}, eccA={st['ecc_A']:.3f}, eccB={st['ecc_B']:.3f}, lack={total_lack/J_per_kcal:.1f}kcal, factor={local_factor:.3f}")

    total_gly_J = st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]
    return local_factor, total_gly_J, local_fatigue_factor, local_damage_factor


def _localglyco_update_and_fatigue_exponential(params, state, E_total_J, E_from_glyc_J, dt, dz, intensity, intensity_threshold=0.65, fatigue_recovery_rate=0.05):
    """Consume glycogen from local pools according to recruitment and compute local fatigue factor.
    Exponential recovery model: 疲労回復を指数関数的に変更したバージョン
    Returns: (local_factor, updated_total_glycogen_J, local_fatigue_factor, local_damage_factor)
    """
    J_per_kcal = 4184.0
    st = state.local_gly

    # 勾配（grade）は simulate_day 側で毎ステップ設定する
    grade = float(state.last_grade)
    A_frac, B_frac, C_frac = _recruit_fractions_from_grade(grade)

    # 肝由来の糖（血糖）を一部割り当て
    from_liver_frac = params.get("from_liver_frac", 0.25)
    gly_from_liver = E_from_glyc_J * from_liver_frac
    gly_from_muscle = E_from_glyc_J - gly_from_liver

    # 肝プールから引く
    used_liver = min(st["Liver_J"], gly_from_liver)
    st["Liver_J"] -= used_liver
    lack_liver = gly_from_liver - used_liver

    # 筋群プールから引く
    dA = gly_from_muscle * A_frac
    dB = gly_from_muscle * B_frac
    dC = gly_from_muscle * C_frac

    use_A = min(st["A_J"], dA); st["A_J"] -= use_A; lack_A = dA - use_A
    use_B = min(st["B_J"], dB); st["B_J"] -= use_B; lack_B = dB - use_B
    use_C = min(st["C_J"], dC); st["C_J"] -= use_C; lack_C = dC - use_C

    # 不足分（lack_*）は脂で代替→効率低下は local_factor で表現（性能低下を強めに反映）
    total_lack = max(0.0, lack_liver) + max(0.0, lack_A) + max(0.0, lack_B) + max(0.0, lack_C)

    # 遠心性疲労（下り）
    #
    # 損傷は吸収した負の仕事に比例するので、下った高さ（-dz）だけに比例させる。
    # 区間ごとの高度差の合計は総下降量になるので、GPXの点の密度に依存しない。
    #
    # 以前は (-dz) * (区間のエネルギー[kcal]) という、区間ごとの量を2つ掛けた形
    # だった。点を半分に間引くと各項が4倍・個数が半分で合計が2倍になる。実際に
    # 塔ノ岳のGPXを間引くと、同じ山行なのに筋効率の最終値が 0.853 -> 0.588 と
    # 変わった。サンプル間隔の粗い多日ルート（黒戸48秒・白峰59秒。日帰りは
    # 18〜24秒）が余計に疲労していた（M-10-1、2026-09-21）。
    # 回復（Phase 4b-1、2026-09-22）: 損傷は時定数 ecc_recovery_time_constant_h で
    # 指数関数的に戻る。行動中も睡眠中も同じ速さ（修復は運動していなくても進む）。
    # 以前は日内も翌朝も回復がなく、縦走では溜まる一方だった。
    tau_ecc_s = params["ecc_recovery_time_constant_h"] * 3600.0
    decay = math.exp(-dt / tau_ecc_s)
    st["ecc_A"] *= decay
    st["ecc_B"] *= decay
    if dz < -0.05:
        ecc_k = params.get("ecc_fatigue_k", 0.0002)
        ecc_load = -dz  # 下った高さ [m]
        st["ecc_A"] += ecc_k * A_frac * ecc_load
        st["ecc_B"] += ecc_k * B_frac * ecc_load

    # 部位別疲労蓄積・回復の計算
    fitness_level = params.get("fitness_level", 1.0)
    fatigue_base_rate = params.get("fatigue_base_rate", 0.02)
    min_eff = params.get("min_muscle_efficiency_multiplier", 0.65) - 0.1 * (1.0 - fitness_level)

    # 部位の強度（Phase 4b-3、2026-09-22）: 全身の VO2max 比 × その部位の募集率 ÷ 容量比。
    # 急登では大腿・殿部（A、募集率 0.62〜0.70、容量比 0.55）だけが全身より高くなる
    # （作者: 丹沢主脈の蛭ヶ岳の登りは大腿に来る）。閾値は cp_ratio（持続できる強度）。
    # 部位ごとに、閾値を超えて働いた時間を溜め、下回れば時定数で戻す（以前は「閾値未満
    # かつ下り」のときだけ回復し、因子は閾値を割った瞬間に 1.0 へ跳ね戻っていた）。
    shares_i = params.get("local_muscle_shares", [0.55, 0.30, 0.15])
    I_A = intensity * A_frac / max(1e-6, shares_i[0])
    I_B = intensity * B_frac / max(1e-6, shares_i[1])
    I_C = intensity * C_frac / max(1e-6, shares_i[2])
    tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
    for key, I_g in (("fatigue_A", I_A), ("fatigue_B", I_B), ("fatigue_C", I_C)):
        if I_g >= intensity_threshold:
            st[key] += dt
        else:
            st[key] = max(0.0, st[key] * math.exp(-dt / tau_recovery_seconds))

    # 各部位の疲労因子を計算
    fatigue_hours_A = st["fatigue_A"] / 3600.0
    fatigue_hours_B = st["fatigue_B"] / 3600.0
    fatigue_hours_C = st["fatigue_C"] / 3600.0

    # 疲労率は強度の2乗に比例（各部位の募集率を考慮）
    # 疲労率は部位の強度の2乗に比例（募集率は部位の強度に含まれている）
    fatigue_rate_A = fatigue_base_rate * (I_A ** 2) / fitness_level
    fatigue_rate_B = fatigue_base_rate * (I_B ** 2) / fitness_level
    fatigue_rate_C = fatigue_base_rate * (I_C ** 2) / fitness_level

    # 疲労因子を計算（指数関数的低下）
    fatigue_factor_A = math.exp(-fatigue_rate_A * fatigue_hours_A) if fatigue_rate_A > 0 else 1.0
    fatigue_factor_B = math.exp(-fatigue_rate_B * fatigue_hours_B) if fatigue_rate_B > 0 else 1.0
    fatigue_factor_C = math.exp(-fatigue_rate_C * fatigue_hours_C) if fatigue_rate_C > 0 else 1.0

    # 下限を適用
    fatigue_factor_A = max(min_eff, fatigue_factor_A)
    fatigue_factor_B = max(min_eff, fatigue_factor_B)
    fatigue_factor_C = max(min_eff, fatigue_factor_C)

    # 最も疲労が激しい部位の疲労因子を採用（最小値を取る）
    local_fatigue_factor = min(fatigue_factor_A, fatigue_factor_B, fatigue_factor_C)

    # 残量比
    def rem(cur, init):
        return max(0.0, cur / max(1e-6, init))
    rA = rem(st["A_J"], st["A_init"])
    rB = rem(st["B_J"], st["B_init"])
    rC = rem(st["C_J"], st["C_init"])

    # 遠心性ペナルティ
    ecc_pen_A = 1.0 / (1.0 + st["ecc_A"])
    ecc_pen_B = 1.0 / (1.0 + st["ecc_B"])

    # 局所グリコーゲン枯渇による筋効率低下：シグモイド関数で閾値効果を適用
    # 全身平均と同じく、低残存率でのみ影響を大きくする（20%以下で効果開始）
    local_k = params.get("local_sigmoid_k", 8.0)
    local_x0 = params.get("local_sigmoid_x0", 0.2)  # 20%残量で効果開始

    def local_glycogen_penalty(ratio):
        """局所グリコーゲン残存率に対するペナルティ（枯渇時のみ影響）"""
        if ratio >= 1.0:
            return 1.0
        # シグモイド関数：20%以下で急激にペナルティが増加
        sigmoid_factor = 1.0 / (1.0 + math.exp(-local_k * (local_x0 - ratio)))
        # ペナルティは最大で30%まで（全身平均と同様）
        c_local = params.get("local_glycogen_eff_c", 0.3)
        return max(0.75, 1.0 - c_local * sigmoid_factor)

    # 各筋群のグリコーゲンペナルティを計算
    pen_A = local_glycogen_penalty(rA) * ecc_pen_A
    pen_B = local_glycogen_penalty(rB) * ecc_pen_B
    pen_C = local_glycogen_penalty(rC)

    # 加重調和平均（弱い鎖を強調）
    weights = [A_frac, B_frac, C_frac]
    comps = [pen_A, pen_B, pen_C]
    denom = sum(w / max(1e-6, c) for w, c in zip(weights, comps))
    local_factor = min(1.0, max(params.get("local_factor_floor", 0.60), sum(weights) / denom))

    # 遠心性損傷だけの加重調和平均（M-11-1、2026-09-21）
    #
    # local_factor は「局所グリコーゲンの残量（燃料）」と「遠心性の筋損傷（疲労）」の
    # 積を平均したものなので、これを所要時間に繋ぐと、実際には起きていない
    # ハンガーノックまで歩く速さに効いてしまう。疲労の側だけを取り出した因子を
    # ここで別に作る。上限・下限は local_factor と同じ扱いにする。
    # C 群（体幹・上肢）には遠心性のペナルティが無いので 1.0。
    damage_comps = [ecc_pen_A, ecc_pen_B, 1.0]
    damage_denom = sum(w / max(1e-6, c) for w, c in zip(weights, damage_comps))
    local_damage_factor = min(1.0, max(params.get("local_factor_floor", 0.60), sum(weights) / damage_denom))

    if params.get("localglyco_debug", False):
        logger.debug(f"LocalGly: grade={grade:.2f}, rA={rA:.2f}, rB={rB:.2f}, rC={rC:.2f}, eccA={st['ecc_A']:.3f}, eccB={st['ecc_B']:.3f}, lack={total_lack/J_per_kcal:.1f}kcal, factor={local_factor:.3f}")

    total_gly_J = st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]
    return local_factor, total_gly_J, local_fatigue_factor, local_damage_factor

