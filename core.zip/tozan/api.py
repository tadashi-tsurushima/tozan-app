"""UI が触る唯一の入口（構想書 §4-1）。

UI は Route と params を渡して SimResult を受け取るだけにする。この関数の
シグネチャを変えない限り、コアの計算式をいくら書き換えても UI は影響を受けない。
"""

import copy

from tozan.multi_day import simulate_multi_day
from tozan.params import DEFAULT_PARAMS, PARAMS_CONTRACT
from tozan.result import SimResult
from tozan.route import Route


def validate_params(params: dict) -> list[str]:
    """params を contract/params.json と照合し、問題点を文字列のリストで返す。

    未知のキー・型違い・min/max 範囲外・enum 外を検出する。空リストなら問題なし。
    未知のキーをエラー扱いにするのは、タイプミスが黙って既定値にフォールバックし、
    較正（Step 7）で「値を変えたのに効かない」問題を生むのを防ぐため。
    """
    errors = []
    for key, value in params.items():
        spec = PARAMS_CONTRACT.get(key)
        if spec is None:
            errors.append(f"未知のパラメータ: {key}")
            continue

        expected_type = spec["type"]
        if expected_type in ("number", "integer"):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                errors.append(f"{key}: 数値ではない（{value!r}）")
                continue
            if "min" in spec and value < spec["min"]:
                errors.append(f"{key}: {value} は最小値 {spec['min']} を下回る")
            if "max" in spec and value > spec["max"]:
                errors.append(f"{key}: {value} は最大値 {spec['max']} を超える")
        elif expected_type == "boolean":
            if not isinstance(value, bool):
                errors.append(f"{key}: 真偽値ではない（{value!r}）")
        elif expected_type == "string":
            if not isinstance(value, str):
                errors.append(f"{key}: 文字列ではない（{value!r}）")
            elif "enum" in spec and value not in spec["enum"]:
                errors.append(f"{key}: {value!r} は許容値 {spec['enum']} に含まれない")
        elif expected_type == "array":
            if not isinstance(value, list):
                errors.append(f"{key}: 配列ではない（{value!r}）")
    return errors


def simulate(route: Route, params: dict) -> SimResult:
    """route と params から SimResult を計算する。

    params は deepcopy してから使う。simulate_day 冒頭の setdefault が
    params にキーを追加するため、deepcopy しないと呼び出し側の dict が
    汚れる（tozan/day.py:40-51）。
    """
    errors = validate_params(params)
    if errors:
        raise ValueError("params が不正: " + "; ".join(errors))
    return simulate_multi_day(route, copy.deepcopy(params))


def default_params() -> dict:
    """DEFAULT_PARAMS の deepcopy を返す。"""
    return copy.deepcopy(DEFAULT_PARAMS)
