"""Simulation result data structures."""

from dataclasses import dataclass
import datetime


def _json_ready(v):
    """json.dumps できる形へ。date/datetime は ISO 8601。numpy スカラーは Python 値にする。"""
    if v is None:
        return None
    if isinstance(v, datetime.datetime):
        return v.isoformat()
    if isinstance(v, datetime.date):
        return v.isoformat()
    if isinstance(v, list):
        return [_json_ready(x) for x in v]
    if isinstance(v, (str, bool, int)):
        return v
    if isinstance(v, float):
        return float(v)
    if hasattr(v, "item"):
        return v.item()
    return v


# simulate_day が返していた dict のキー順。golden summary の仕様でもある。
DAY_RESULT_KEYS = (
    "date",
    "distance_km",
    "up_m",
    "down_m",
    "duration_h",
    "sweat_kg",
    "up_time_h",
    "down_time_h",
    "up_sweat_kg",
    "down_sweat_kg",
    "T_core_final",
    "hr_data",
    "elevation_data",
    "time_data",
    "mechanical_power_data",
    "sweat_data",
    "dx_data",
    "glycogen_data",
    "fat_data",
    "muscle_efficiency_data",
    "final_muscle_efficiency_data",
    "vo2_usage_ratio_data",
    "intensity_data",
    "high_intensity_time_data",
    "frac_glyc_actual_data",
    "sigmoid_factor_data",
    "local_gly_A_ratio_data",
    "local_gly_B_ratio_data",
    "local_gly_C_ratio_data",
    "local_gly_min_ratio_data",
    "mechanical_energy_data",
    "hypoglycemic_data",
    "metabolic_energy_data",
    "sweat_incremental_data",
    "local_gly_A_absolute_data",
    "local_gly_B_absolute_data",
    "local_gly_C_absolute_data",
    "local_gly_liver_absolute_data",
    "distance_cumulative_data",
    "timestamp_data",
)


@dataclass
class DayResult:
    date: datetime.date | None
    distance_km: float
    up_m: float
    down_m: float
    duration_h: float
    sweat_kg: float
    up_time_h: float
    down_time_h: float
    up_sweat_kg: float
    down_sweat_kg: float
    T_core_final: float
    hr_data: list
    elevation_data: list
    time_data: list
    mechanical_power_data: list
    sweat_data: list
    dx_data: list
    glycogen_data: list
    fat_data: list
    muscle_efficiency_data: list
    final_muscle_efficiency_data: list
    vo2_usage_ratio_data: list
    intensity_data: list
    high_intensity_time_data: list
    frac_glyc_actual_data: list
    sigmoid_factor_data: list
    local_gly_A_ratio_data: list
    local_gly_B_ratio_data: list
    local_gly_C_ratio_data: list
    local_gly_min_ratio_data: list
    mechanical_energy_data: list
    hypoglycemic_data: list
    metabolic_energy_data: list
    sweat_incremental_data: list
    local_gly_A_absolute_data: list
    local_gly_B_absolute_data: list
    local_gly_C_absolute_data: list
    local_gly_liver_absolute_data: list
    distance_cumulative_data: list
    timestamp_data: list

    def to_dict(self) -> dict:
        return {name: _json_ready(getattr(self, name)) for name in DAY_RESULT_KEYS}


@dataclass
class SimResult:
    days: list[DayResult]

    def to_dict(self) -> dict:
        return {"days": [d.to_dict() for d in self.days]}
