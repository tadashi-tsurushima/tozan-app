"""Single-day simulation. Internals are kept as one function."""

import logging
import math

from tozan.constants import E_O2_J_per_L, L_v_J_per_kg, WALK_EFF, g
from tozan.environment import P_O2, calculate_body_surface_area, h_c_of_v_elevation
from tozan.heart_rate import calculate_heart_rate_recovery_exponential
from tozan.local_glycogen import _localglyco_add_supplement, _localglyco_init_if_needed
from tozan.metabolism import calculate_energy_metabolism_physical
from tozan.result import DayResult
from tozan.state import _glycogen_kcal_for_day
from tozan.terrain import estimate_terrain_factor

logger = logging.getLogger(__name__)


def simulate_day(route_day, params, state, terrain_factor_dict=None):
    points = route_day.points
    mass = params["weight_kg"] + params["pack_kg"]
    current_HR = params["HR_rest"]
    PWR_rest_W = params["rest_power_W"]

    # Calculate muscle ratio from body fat percentage
    r_muscle = (1 - params["f_fat"]) / (1 - 0.22)
    VO2_L_per_min = (params["vo2max_ml_kg_min"] * params["weight_kg"]) * r_muscle / 1000.0

    P_O2_std = P_O2(20.0, 0.5, 0.0)
    C_body = 3494.0 * params["weight_kg"]
    A_body = calculate_body_surface_area(params["weight_kg"], params["height_cm"])

    HR_max = params["HR_max"]
    HR_rest = params["HR_rest"]

    total_up = total_down = total_dist = total_time = total_sweat = 0.0
    up_time = down_time = up_sweat = down_sweat = 0.0
    T_core = params["T_core_init"]

    # エネルギーストアの初期化
    params.setdefault("glycogen_kcal_init", 1800.0)
    params.setdefault("fat_kcal_init", 80000.0)
    params.setdefault("glycogen_depletion_effect_c", 0.35)
    params.setdefault("glycogen_depletion_muscle_eff_c", 0.3)
    params.setdefault("sigmoid_k", 8.0)
    params.setdefault("sigmoid_x0", 0.3)
    params.setdefault("I_low", 0.30)
    params.setdefault("I_high", 0.90)
    params.setdefault("fat_supply_limit_W", 400.0)
    params.setdefault("I_fatigue_threshold", 0.65)
    params.setdefault("fatigue_base_rate", 0.02)
    params.setdefault("min_muscle_efficiency_multiplier", 0.65)

    glycogen_J = _glycogen_kcal_for_day(params, state) * 4184.0
    fat_J = params.get("fat_kcal_init", 80000.0) * 4184.0

    # 山頂検出の準備
    max_elevation = max(p.ele for p in points)
    peak_reached = False
    peak_rest_completed = False
    peak_rest_start_time = None  # 休憩開始時刻
    hr_at_rest_start = None  # 休憩開始時の心拍数

    # 補給管理
    action_food_timer = 0.0
    action_food_pending = 0.0
    action_food_supplement_time = 0.0

    peak_rest_pending = 0.0
    peak_rest_supplement_time = 0.0

    # 疲労の初期化（前日からの持ち越しがある場合は使用）
    if state.initial_fatigue_hours is not None:
        high_intensity_time_seconds = state.initial_fatigue_hours * 3600.0
        state.initial_fatigue_hours = None
    else:
        high_intensity_time_seconds = 0.0

    # 局所疲労の初期化（前日からの持ち越しがある場合は使用）
    if state.initial_local_fatigue is not None:
        initial_local_fatigue = state.initial_local_fatigue
        # 局所グリコーゲン状態を初期化（グリコーゲンは後で設定される）
        _localglyco_init_if_needed(params, state, 0.0)
        st = state.local_gly
        # 前日からの持ち越し疲労を設定
        st["fatigue_A"] = initial_local_fatigue.get("fatigue_A", 0.0)
        st["fatigue_B"] = initial_local_fatigue.get("fatigue_B", 0.0)
        st["fatigue_C"] = initial_local_fatigue.get("fatigue_C", 0.0)
        state.initial_local_fatigue = None
        logger.info(f"Day: Initial local fatigue set - A: {st['fatigue_A']/3600.0:.2f}h, B: {st['fatigue_B']/3600.0:.2f}h, C: {st['fatigue_C']/3600.0:.2f}h")

    muscle_efficiency = 1.0

    # Record lists
    hr_data = []
    elevation_data = []
    time_data = []
    mechanical_power_data = []
    sweat_data = []
    dx_data = []

    glycogen_data = []
    fat_data = []
    muscle_efficiency_data = []
    final_muscle_efficiency_data = []  # 実際の筋効率（eff_up/eff_down）
    vo2_usage_ratio_data = []
    intensity_data = []
    high_intensity_time_data = []
    frac_glyc_actual_data = []
    sigmoid_factor_data = []

    # 局所グリコーゲン残量データ（グラフ用）
    local_gly_A_ratio_data = []
    local_gly_B_ratio_data = []
    local_gly_C_ratio_data = []
    local_gly_min_ratio_data = []  # 最も消費が激しい部位の残存率

    # CSV出力用の時系列データ
    mechanical_energy_data = []  # 必要な機械的エネルギー [J]
    metabolic_energy_data = []  # 代謝エネルギー [J]
    sweat_incremental_data = []  # 各ステップでの発汗量 [kg]
    local_gly_A_absolute_data = []  # 部位Aのグリコーゲン残量 [kcal]
    local_gly_B_absolute_data = []  # 部位Bのグリコーゲン残量 [kcal]
    local_gly_C_absolute_data = []  # 部位Cのグリコーゲン残量 [kcal]
    distance_cumulative_data = []  # 累積距離 [m]
    timestamp_data = []  # GPXポイントのtimestamp

    # 最初のポイントのtimestampを記録
    if len(points) > 0:
        timestamp_data.append(points[0].timestamp)
    else:
        timestamp_data.append(None)

    # デバッグ用：勾配分布と部位別消費の統計
    grade_stats = {"steep_up": 0, "up": 0, "flat": 0, "gentle_down": 0, "steep_down": 0}
    muscle_consumption_actual = {"A_total": 0.0, "B_total": 0.0, "C_total": 0.0}  # 実際の消費量

    for i in range(1, len(points)):
        dx = points[i].dist_m
        dz = points[i].ele_diff
        dist3d = math.hypot(dx, dz)
        if dist3d <= 0:
            continue

        slope_deg = math.degrees(math.atan2(abs(dz), dx)) if dx > 0 else 0.0
        elevation_m = points[i].ele

        # 勾配（局所モデル用）
        grade = dz / max(dx, 1e-6)
        state.last_grade = grade

        # 山頂検出
        if not peak_reached and elevation_m >= max_elevation - 10.0:
            peak_reached = True
            logger.info(f"Peak reached at elevation {elevation_m:.1f}m (max: {max_elevation:.1f}m)")

        # 山頂休憩処理
        if peak_reached and not peak_rest_completed:
            rest_time_seconds = params["peak_rest_minutes"] * 60.0

            # 休憩開始時刻を記録（最初の1回だけ）
            if peak_rest_start_time is None:
                peak_rest_start_time = total_time
                hr_at_rest_start = current_HR
                onigiri_kcal = params.get("peak_rest_onigiri_kcal", 180.0)
                amino_vital_kcal = params.get("peak_rest_amino_vital_kcal", 100.0)
                peak_rest_pending += (onigiri_kcal + amino_vital_kcal) * 4184.0
                peak_rest_supplement_time = total_time + 0.5 * 3600
                logger.info(f"Peak rest started: HR={hr_at_rest_start:.1f} bpm at time={total_time/3600:.2f}h")

            # 休憩中は各ステップで時間を進める（dt_segを固定値に設定）
            # 休憩中の時間ステップ（10秒ごと）
            dt_rest_step = 10.0  # 休憩中の時間ステップ [秒]
            total_time += dt_rest_step
            rest_elapsed_seconds = total_time - peak_rest_start_time

            # 休憩中は各ステップで心拍数を回復させる
            if rest_elapsed_seconds < rest_time_seconds:
                # 休憩中：休憩開始時からの経過時間に基づいて心拍数を回復
                recovery_time_constant = params["peak_rest_hr_recovery_time_constant"]
                current_HR = calculate_heart_rate_recovery_exponential(
                    hr_at_rest_start, params["HR_rest"], rest_elapsed_seconds,
                    recovery_time_constant,
                    hr_target_offset=35.0
                )

                # 部位別疲労の回復（休憩中、累積的に）
                if state.local_gly is not None:
                    st = state.local_gly
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    if fatigue_model_type == "exponential":
                        # 指数関数的回復（累積的に）
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-rest_elapsed_seconds / tau_recovery_seconds)
                        st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-rest_elapsed_seconds / tau_recovery_seconds)
                        st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-rest_elapsed_seconds / tau_recovery_seconds)
                        st["fatigue_A"] = max(0.0, st["fatigue_A"])
                        st["fatigue_B"] = max(0.0, st["fatigue_B"])
                        st["fatigue_C"] = max(0.0, st["fatigue_C"])
                    else:
                        # 線形回復（累積的に）
                        fatigue_recovery_rate = params["peak_rest_fatigue_recovery_rate"]
                        fatigue_recovery_seconds = fatigue_recovery_rate * rest_elapsed_seconds / 3600.0
                        # 休憩開始時の疲労値を保持する必要があるため、初回のみ記録
                        if not hasattr(st, "_fatigue_at_rest_start"):
                            st["_fatigue_at_rest_start"] = {
                                "A": st.get("fatigue_A", 0.0),
                                "B": st.get("fatigue_B", 0.0),
                                "C": st.get("fatigue_C", 0.0)
                            }
                        st["fatigue_A"] = max(0.0, st["_fatigue_at_rest_start"]["A"] - fatigue_recovery_seconds)
                        st["fatigue_B"] = max(0.0, st["_fatigue_at_rest_start"]["B"] - fatigue_recovery_seconds)
                        st["fatigue_C"] = max(0.0, st["_fatigue_at_rest_start"]["C"] - fatigue_recovery_seconds)

                # 後方互換性のため、high_intensity_time_secondsも更新（最大値を使用）
                if state.local_gly is not None:
                    st = state.local_gly
                    max_fatigue = max(st.get("fatigue_A", 0.0), st.get("fatigue_B", 0.0), st.get("fatigue_C", 0.0))
                    high_intensity_time_seconds = max_fatigue
                else:
                    # 旧モデル用のフォールバック
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    if fatigue_model_type == "exponential":
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        if not hasattr(params, "_high_intensity_at_rest_start"):
                            params["_high_intensity_at_rest_start"] = high_intensity_time_seconds
                        high_intensity_time_seconds = params["_high_intensity_at_rest_start"] * math.exp(-rest_elapsed_seconds / tau_recovery_seconds)
                    else:
                        fatigue_recovery_rate = params["peak_rest_fatigue_recovery_rate"]
                        fatigue_recovery_seconds = fatigue_recovery_rate * rest_elapsed_seconds / 3600.0
                        if not hasattr(params, "_high_intensity_at_rest_start"):
                            params["_high_intensity_at_rest_start"] = high_intensity_time_seconds
                        high_intensity_time_seconds = max(0.0, params["_high_intensity_at_rest_start"] - fatigue_recovery_seconds)
            else:
                # 休憩終了
                recovery_time_constant = params["peak_rest_hr_recovery_time_constant"]
                current_HR = calculate_heart_rate_recovery_exponential(
                    hr_at_rest_start, params["HR_rest"], rest_time_seconds,
                    recovery_time_constant,
                    hr_target_offset=35.0
                )
                logger.info(f"Peak rest completed: HR={current_HR:.1f} bpm after {rest_time_seconds/60:.1f} min")

                # 疲労回復を最終的に適用
                if state.local_gly is not None:
                    st = state.local_gly
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    if fatigue_model_type == "exponential":
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-rest_time_seconds / tau_recovery_seconds)
                        st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-rest_time_seconds / tau_recovery_seconds)
                        st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-rest_time_seconds / tau_recovery_seconds)
                    else:
                        fatigue_recovery_rate = params["peak_rest_fatigue_recovery_rate"]
                        fatigue_recovery_seconds = fatigue_recovery_rate * rest_time_seconds / 3600.0
                        if hasattr(st, "_fatigue_at_rest_start"):
                            st["fatigue_A"] = max(0.0, st["_fatigue_at_rest_start"]["A"] - fatigue_recovery_seconds)
                            st["fatigue_B"] = max(0.0, st["_fatigue_at_rest_start"]["B"] - fatigue_recovery_seconds)
                            st["fatigue_C"] = max(0.0, st["_fatigue_at_rest_start"]["C"] - fatigue_recovery_seconds)
                        else:
                            st["fatigue_A"] = max(0.0, st.get("fatigue_A", 0.0) - fatigue_recovery_seconds)
                            st["fatigue_B"] = max(0.0, st.get("fatigue_B", 0.0) - fatigue_recovery_seconds)
                            st["fatigue_C"] = max(0.0, st.get("fatigue_C", 0.0) - fatigue_recovery_seconds)
                    # 一時変数を削除
                    if hasattr(st, "_fatigue_at_rest_start"):
                        del st["_fatigue_at_rest_start"]

                if state.local_gly is not None:
                    st = state.local_gly
                    max_fatigue = max(st.get("fatigue_A", 0.0), st.get("fatigue_B", 0.0), st.get("fatigue_C", 0.0))
                    high_intensity_time_seconds = max_fatigue
                else:
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    if fatigue_model_type == "exponential":
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        if hasattr(params, "_high_intensity_at_rest_start"):
                            high_intensity_time_seconds = params["_high_intensity_at_rest_start"] * math.exp(-rest_time_seconds / tau_recovery_seconds)
                            del params["_high_intensity_at_rest_start"]
                    else:
                        fatigue_recovery_rate = params["peak_rest_fatigue_recovery_rate"]
                        fatigue_recovery_seconds = fatigue_recovery_rate * rest_time_seconds / 3600.0
                        if hasattr(params, "_high_intensity_at_rest_start"):
                            high_intensity_time_seconds = max(0.0, params["_high_intensity_at_rest_start"] - fatigue_recovery_seconds)
                            del params["_high_intensity_at_rest_start"]

            # 休憩中の筋効率計算（部位別疲労因子を使用）
            if state.local_gly is not None:
                st = state.local_gly
                fitness_level = params.get("fitness_level", 1.0)
                fatigue_base_rate = params.get("fatigue_base_rate", 0.02)
                min_eff = params.get("min_muscle_efficiency_multiplier", 0.65) - 0.1 * (1.0 - fitness_level)

                # 各部位の疲労因子を計算（休憩中は強度0）
                fatigue_hours_A = st.get("fatigue_A", 0.0) / 3600.0
                fatigue_hours_B = st.get("fatigue_B", 0.0) / 3600.0
                fatigue_hours_C = st.get("fatigue_C", 0.0) / 3600.0

                # 休憩中は強度0なので疲労率は0
                fatigue_factor_A = 1.0
                fatigue_factor_B = 1.0
                fatigue_factor_C = 1.0

                # 下限を適用
                fatigue_factor_A = max(min_eff, fatigue_factor_A)
                fatigue_factor_B = max(min_eff, fatigue_factor_B)
                fatigue_factor_C = max(min_eff, fatigue_factor_C)

                # 最も疲労が激しい部位の疲労因子を採用
                muscle_efficiency_fatigue = min(fatigue_factor_A, fatigue_factor_B, fatigue_factor_C)
            else:
                # フォールバック（局所モデルがない場合）
                muscle_efficiency_fatigue = 1.0

            # 役割3の分母は役割2（その日の開始量）を参照している。
            # 本来は最大貯蔵量（将来の glycogen_kcal_max。現状は params['glycogen_kcal_init'] が兼ねる）を
            # 参照すべきだが、現状維持のため day_init を使う。モデル改良で対応予定。
            glyciprop = glycogen_J / (_glycogen_kcal_for_day(params, state) * 4184.0)
            glyciprop = max(0.0, min(1.0, glyciprop))
            k = params.get("sigmoid_k", 8.0)
            x0 = params.get("sigmoid_x0", 0.3)
            sigmoid_factor = 1.0 / (1.0 + math.exp(-k * (x0 - glyciprop)))
            c_glycogen_eff = params.get("glycogen_depletion_muscle_eff_c", 0.3)
            muscle_efficiency_glycogen = max(0.75, 1.0 - c_glycogen_eff * sigmoid_factor)

            muscle_efficiency = muscle_efficiency_fatigue * muscle_efficiency_glycogen

            # 休憩中は筋効率を前の値を保持（短時間の休憩では筋効率は変化しない）
            # 疲労回復やグリコーゲン補給の影響は、実際の運動再開後に段階的に反映される
            if len(final_muscle_efficiency_data) > 0:
                final_muscle_efficiency = final_muscle_efficiency_data[-1]  # 前の値を保持
            else:
                # 初回の場合のみ計算
                eff_up_orig = params.get("efficiency_up", 0.25)
                eff_down_orig = params.get("efficiency_down", 0.25)
                eff_up = max(1e-6, eff_up_orig * muscle_efficiency)
                eff_down = max(1e-6, eff_down_orig * muscle_efficiency)
                final_muscle_efficiency = (eff_up + eff_down) / 2.0

            # 休憩中のデータ記録（各ステップで記録）
            # 休憩中は通常の運動計算をスキップするため、ここでデータを記録してcontinue
            hr_data.append(current_HR)
            elevation_data.append(elevation_m)
            time_data.append(total_time)
            glycogen_data.append(glycogen_J / 4184.0)
            fat_data.append(fat_J / 4184.0)
            # 休憩中は前の値を保持
            if len(muscle_efficiency_data) > 0:
                muscle_efficiency_data.append(muscle_efficiency_data[-1])
            else:
                muscle_efficiency_data.append(muscle_efficiency)
            final_muscle_efficiency_data.append(final_muscle_efficiency)  # 前の値を保持
            vo2_usage_ratio_data.append(params["vo2_usage_ratio"])
            intensity_data.append(0.0)
            high_intensity_time_data.append(high_intensity_time_seconds / 3600.0)
            frac_glyc_actual_data.append(0.0)
            sigmoid_factor_data.append(1.0)
            mechanical_power_data.append(0.0)
            # 休憩中は発汗がないが、累積発汗量は保持する
            sweat_data.append(total_sweat)
            dx_data.append(0.0)

            # CSV出力用の時系列データ（休憩中）
            mechanical_energy_data.append(0.0)
            metabolic_energy_data.append(0.0)
            sweat_incremental_data.append(0.0)  # 休憩中は発汗なし
            distance_cumulative_data.append(total_dist)
            if len(timestamp_data) > 0:
                timestamp_data.append(timestamp_data[-1])
            else:
                timestamp_data.append(None)
            # 局所グリコーゲン残量（休憩中は変化なし）
            if state.local_gly is not None:
                st = state.local_gly
                if len(local_gly_A_absolute_data) > 0:
                    local_gly_A_absolute_data.append(local_gly_A_absolute_data[-1])
                    local_gly_B_absolute_data.append(local_gly_B_absolute_data[-1])
                    local_gly_C_absolute_data.append(local_gly_C_absolute_data[-1])
                else:
                    local_gly_A_absolute_data.append(st["A_J"] / 4184.0)
                    local_gly_B_absolute_data.append(st["B_J"] / 4184.0)
                    local_gly_C_absolute_data.append(st["C_J"] / 4184.0)
            else:
                local_gly_A_absolute_data.append(0.0)
                local_gly_B_absolute_data.append(0.0)
                local_gly_C_absolute_data.append(0.0)

            # 局所グリコーゲン残存率（休憩中は変化なし）
            if len(local_gly_A_ratio_data) > 0:
                local_gly_A_ratio_data.append(local_gly_A_ratio_data[-1])
                local_gly_B_ratio_data.append(local_gly_B_ratio_data[-1])
                local_gly_C_ratio_data.append(local_gly_C_ratio_data[-1])
                local_gly_min_ratio_data.append(local_gly_min_ratio_data[-1])
            else:
                local_gly_A_ratio_data.append(1.0)
                local_gly_B_ratio_data.append(1.0)
                local_gly_C_ratio_data.append(1.0)
                local_gly_min_ratio_data.append(1.0)

            # 休憩終了時のみメッセージを出力
            if rest_elapsed_seconds >= rest_time_seconds:
                logger.info(f"Peak rest completed: HR={current_HR:.1f} bpm after {rest_time_seconds/60:.1f} min")
                peak_rest_completed = True

            # 休憩中は通常の運動計算をスキップ
            continue

        terrain_type = points[i].terrain_type
        terrain_factor = estimate_terrain_factor(0.0, elevation_m, terrain_type)

        E_vertical_step = 0.2 * mass * g * abs(dz)  # 無効化（係数0）
        E_vertical = mass * g * dz + E_vertical_step
        E_horizontal = WALK_EFF * mass * g * params["friction_coefficient"] * dx

        E_vertical *= terrain_factor
        E_horizontal *= terrain_factor

        if dz < 0:
            E_pe_total = params["descent_fraction"] * mass * g * abs(dz)
            E_brake = params["brake_factor"] * E_pe_total
            transfer_J = (1.0 - params["brake_factor"]) * E_pe_total
            transfer_used = min(transfer_J, E_horizontal)
            E_vertical = abs(E_pe_total - transfer_J)  # 下りの吸収エネルギーは常に正
            E_horizontal = WALK_EFF * mass * g * params["friction_coefficient"] * dx
            E_horizontal = max(0.0, E_horizontal - transfer_used)
            E_vertical *= terrain_factor
            E_horizontal *= terrain_factor
        else:
            E_brake = 0.0

        elevation_diff = elevation_m - params["T_air_elevation"]
        absolute_humidity_ratio = math.exp(-elevation_diff / 2000.0)
        RH_seg = params["RH"] * absolute_humidity_ratio
        T_air_seg = params["T_air"] - params["lapse_rate"] * (elevation_m - params["T_air_elevation"])
        P_O2_seg = P_O2(T_air_seg, RH_seg, elevation_m)

        O2_pulse_ml_per_beat = (VO2_L_per_min * (P_O2_seg / P_O2_std) * 1000 / params["HR_max"])

        oxygen_demand_ml_per_min = params["vo2max_ml_kg_min"] * params["weight_kg"] * params["vo2_usage_ratio"]
        HR_demand = min(params["HR_max"], oxygen_demand_ml_per_min / O2_pulse_ml_per_beat)

        # 循環依存を解消：available_VO2の計算で、current_HRではなく目標心拍数（HR_demand）を使う
        # これにより、初期の低い心拍数による制限を回避し、実際の代謝需要に基づいたパワーを発揮できる
        HR_for_available_VO2 = max(current_HR, HR_demand)  # 現在の心拍数と目標心拍数の大きい方を使用
        available_VO2 = HR_for_available_VO2 * O2_pulse_ml_per_beat / 1000.0
        P_met_limit_W_env = available_VO2 * E_O2_J_per_L / 60.0

        if dz > 0:
            current_muscle_efficiency = params["efficiency_up"]
        elif dz < 0:
            current_muscle_efficiency = params["efficiency_down"]
        else:
            current_muscle_efficiency = (params["efficiency_up"] + params["efficiency_down"]) / 2.0

        P_mech_available_W = (P_met_limit_W_env - params["rest_power_W"]) * current_muscle_efficiency

        if P_mech_available_W > 0:
            if dz > 0:
                total_work_J = E_horizontal + E_vertical
                C_limit_slip = 1.0
            elif dz < 0:
                descent_brake_eff = params["descent_fraction"]
                total_work_J = E_horizontal + E_vertical * descent_brake_eff
                C_limit_slip = params["descent_eff_factor"]
            else:
                total_work_J = E_horizontal
                C_limit_slip = 1.0

            P_final_W = max(0, P_mech_available_W * C_limit_slip)
            dt_seg = total_work_J / max(1e-6, P_final_W)

            O2_target_ml_per_min = (P_final_W + PWR_rest_W) / E_O2_J_per_L * 1000 * 60 / max(1e-6, muscle_efficiency)
            HR_target_bpm = min(params["HR_max"], O2_target_ml_per_min / O2_pulse_ml_per_beat)
        else:
            dt_seg = dist3d / params["v_min"]

        # エネルギー代謝（局所モデル含む）
        P_met_used_current = P_final_W / max(1e-6, current_muscle_efficiency)

        # デバッグ：勾配分類
        if grade >= 0.25:
            grade_stats["steep_up"] += dt_seg
        elif grade >= 0.10:
            grade_stats["up"] += dt_seg
        elif grade > -0.10:
            grade_stats["flat"] += dt_seg
        elif grade > -0.25:
            grade_stats["gentle_down"] += dt_seg
        else:
            grade_stats["steep_down"] += dt_seg

        # デバッグ：局所グリコーゲンの消費前の値を記録
        st_before = None
        if state.local_gly is not None:
            st_before = state.local_gly.copy()

        energy_result = calculate_energy_metabolism_physical(
            P_met_used_current, dt_seg, P_met_limit_W_env, params, state,
            glycogen_J, fat_J, high_intensity_time_seconds, dz
        )

        # デバッグ：実際の局所グリコーゲン消費量を記録
        if st_before is not None and state.local_gly is not None:
            st_after = state.local_gly
            # 各部位の実際の消費量（J単位）
            consumed_A = (st_before["A_J"] - st_after["A_J"]) / 4184.0  # kcal換算
            consumed_B = (st_before["B_J"] - st_after["B_J"]) / 4184.0
            consumed_C = (st_before["C_J"] - st_after["C_J"]) / 4184.0
            muscle_consumption_actual["A_total"] += max(0.0, consumed_A)
            muscle_consumption_actual["B_total"] += max(0.0, consumed_B)
            muscle_consumption_actual["C_total"] += max(0.0, consumed_C)

        glycogen_J = energy_result["glycogen_J"]
        fat_J = energy_result["fat_J"]
        frac_glyc_actual = energy_result["frac_glyc_actual"]
        muscle_efficiency = energy_result["muscle_efficiency"]
        eff_up = energy_result["eff_up"]
        eff_down = energy_result["eff_down"]
        high_intensity_time_seconds = energy_result["high_intensity_time_seconds"]
        intensity = energy_result["intensity"]
        sigmoid_factor = energy_result["sigmoid_factor"]

        if dz > 0:
            final_muscle_efficiency = eff_up
        elif dz < 0:
            final_muscle_efficiency = eff_down
        else:
            final_muscle_efficiency = (eff_up + eff_down) / 2.0

        P_met_used = P_final_W / max(1e-6, final_muscle_efficiency)

        # 固定比率（vo2_usage_ratio）から計算した代謝パワー
        oxygen_demand_ml_per_min_eff = params["vo2max_ml_kg_min"] * params["weight_kg"] * params["vo2_usage_ratio"]
        P_met_fixed_ratio = oxygen_demand_ml_per_min_eff * E_O2_J_per_L / 1000.0 / 60.0  # 固定比率の代謝パワー [W]
        HR_demand_eff = min(params["HR_max"], oxygen_demand_ml_per_min_eff / O2_pulse_ml_per_beat)

        # 心拍数計算：登りと下りで分岐
        if dz > 0:
            # 登り：P_met_usedは既にE_horizontal + E_verticalを含んでいるので、そのまま使用
            P_met_actual = P_met_used + PWR_rest_W
            O2_target_ml_per_min_eff = P_met_actual / E_O2_J_per_L * 1000 * 60
            HR_target_bpm_eff = min(params["HR_max"], O2_target_ml_per_min_eff / O2_pulse_ml_per_beat)
            # 固定比率で上限を設定
            HR_target_bpm_eff = min(HR_demand_eff, HR_target_bpm_eff)
        elif dz < 0:
            # 下り：平常時の代謝パワー（水平移動 + 安静時）+ 位置エネルギー吸収分
            # 水平移動の代謝エネルギー
            P_met_horizontal = (E_horizontal / max(1e-6, dt_seg)) / max(1e-6, final_muscle_efficiency) if dt_seg > 0 else 0.0
            # 位置エネルギー吸収分の代謝パワー（筋効率を考慮する）
            P_met_vertical_absorption = (E_vertical / max(1e-6, dt_seg)) / max(1e-6, final_muscle_efficiency) if dt_seg > 0 else 0.0  # 位置エネルギー吸収分の代謝パワー
            # 総代謝パワー = 平常時（水平移動 + 安静時）+ 位置エネルギー吸収分
            P_met_total = P_met_horizontal + PWR_rest_W + P_met_vertical_absorption

            O2_target_ml_per_min_eff = P_met_total / E_O2_J_per_L * 1000 * 60
            HR_target_bpm_eff = min(params["HR_max"], O2_target_ml_per_min_eff / O2_pulse_ml_per_beat)
            # 下りの場合、最低限の運動による心拍数増加分を保証（安静時 + 平地相当の+35bpm程度）
            HR_min_downhill = HR_rest + 35.0  # 下りでも最低限の運動分（+35bpm）
            HR_target_bpm_eff = max(HR_min_downhill, HR_target_bpm_eff)
        else:
            # 平地：水平移動 + 安静時
            P_met_horizontal = (E_horizontal / max(1e-6, dt_seg)) / max(1e-6, final_muscle_efficiency) if dt_seg > 0 else 0.0
            P_met_actual = P_met_horizontal + PWR_rest_W
            O2_target_ml_per_min_eff = P_met_actual / E_O2_J_per_L * 1000 * 60
            HR_target_bpm_eff = min(params["HR_max"], O2_target_ml_per_min_eff / O2_pulse_ml_per_beat)
            HR_target_bpm_eff = min(HR_demand_eff, HR_target_bpm_eff)

        # 心拍数の上限を考慮した再計算（P_mech_available_W > 0の場合のみ）
        if P_mech_available_W > 0:
            # 1. 上限の心拍上昇速度 × dt_seg で上昇できる心拍数を計算
            max_hr_increase_per_sec = params.get("max_hr_increase_per_sec", 5.0)
            max_hr_change = max_hr_increase_per_sec * dt_seg  # [bpm]
            HR_achievable = current_HR + max_hr_change  # 上限を考慮した到達可能心拍数

            # 2. その心拍数でパワーを再計算
            if HR_target_bpm_eff > HR_achievable:
                # 上限により目標心拍数に到達できない場合、到達可能心拍数を使用
                HR_for_power = HR_achievable
            else:
                HR_for_power = HR_target_bpm_eff

            # 到達可能心拍数から利用可能パワーを再計算
            available_VO2_recalc = HR_for_power * O2_pulse_ml_per_beat / 1000.0
            P_met_limit_W_env_recalc = available_VO2_recalc * E_O2_J_per_L / 60.0
            P_mech_available_W_recalc = (P_met_limit_W_env_recalc - params["rest_power_W"]) * current_muscle_efficiency

            # 3. 必要仕事量を再計算したパワーで割ってループ時間を修正計算
            if P_mech_available_W_recalc > 0:
                P_final_W_recalc = max(0, P_mech_available_W_recalc * C_limit_slip)
                dt_seg = total_work_J / max(1e-6, P_final_W_recalc)
                P_final_W = P_final_W_recalc  # 再計算したパワーを使用

                # dt_segが変更されたので、HR_target_bpm_effを再計算
                if dz > 0:
                    # 登り：P_met_usedを再計算
                    P_met_used_recalc = P_final_W / max(1e-6, final_muscle_efficiency)
                    P_met_actual_recalc = P_met_used_recalc + PWR_rest_W
                    O2_target_ml_per_min_eff_recalc = P_met_actual_recalc / E_O2_J_per_L * 1000 * 60
                    HR_target_bpm_eff_recalc = min(params["HR_max"], O2_target_ml_per_min_eff_recalc / O2_pulse_ml_per_beat)
                    HR_target_bpm_eff_recalc = min(HR_demand_eff, HR_target_bpm_eff_recalc)
                    # 上限を考慮して最終的な目標心拍数を決定
                    if HR_target_bpm_eff_recalc > HR_achievable:
                        HR_target_bpm_eff = HR_achievable
                    else:
                        HR_target_bpm_eff = HR_target_bpm_eff_recalc
                elif dz < 0:
                    # 下り：P_met_horizontalとP_met_vertical_absorptionを再計算
                    P_met_horizontal_recalc = (E_horizontal / max(1e-6, dt_seg)) / max(1e-6, final_muscle_efficiency) if dt_seg > 0 else 0.0
                    P_met_vertical_absorption_recalc = (E_vertical / max(1e-6, dt_seg)) / max(1e-6, final_muscle_efficiency) if dt_seg > 0 else 0.0
                    P_met_total_recalc = P_met_horizontal_recalc + PWR_rest_W + P_met_vertical_absorption_recalc
                    O2_target_ml_per_min_eff_recalc = P_met_total_recalc / E_O2_J_per_L * 1000 * 60
                    HR_target_bpm_eff_recalc = min(params["HR_max"]*params["vo2_usage_ratio"]/(P_O2_seg / P_O2_std), O2_target_ml_per_min_eff_recalc / O2_pulse_ml_per_beat)
                    HR_target_bpm_eff_recalc = max(HR_min_downhill, HR_target_bpm_eff_recalc)
                    # 上限を考慮して最終的な目標心拍数を決定
                    if HR_target_bpm_eff_recalc > HR_achievable:
                        HR_target_bpm_eff = HR_achievable
                    else:
                        HR_target_bpm_eff = HR_target_bpm_eff_recalc
                else:
                    # 平地：P_met_horizontalを再計算
                    P_met_horizontal_recalc = (E_horizontal / max(1e-6, dt_seg)) / max(1e-6, final_muscle_efficiency) if dt_seg > 0 else 0.0
                    P_met_actual_recalc = P_met_horizontal_recalc + PWR_rest_W
                    O2_target_ml_per_min_eff_recalc = P_met_actual_recalc / E_O2_J_per_L * 1000 * 60
                    HR_target_bpm_eff_recalc = min(params["HR_max"], O2_target_ml_per_min_eff_recalc / O2_pulse_ml_per_beat)
                    HR_target_bpm_eff_recalc = min(HR_demand_eff, HR_target_bpm_eff_recalc)
                    # 上限を考慮して最終的な目標心拍数を決定
                    if HR_target_bpm_eff_recalc > HR_achievable:
                        HR_target_bpm_eff = HR_achievable
                    else:
                        HR_target_bpm_eff = HR_target_bpm_eff_recalc

        # 心拍数の更新（時定数を考慮）
        tau = 90.0 if dz < 0 else 20.0  # 下り90秒、登り20秒
        beta = min(dt_seg / tau, 1.0)
        # 登り時はbetaの最小値を設定して、心拍数の上昇を速くする
        if dz > 0:
            beta = max(beta, 0.4)  # 最小値0.4を保証
        hr_change = beta * (HR_target_bpm_eff - current_HR)
        # 心拍数の上昇速度の上限を適用
        max_hr_increase_per_sec = params.get("max_hr_increase_per_sec", 5.0)
        max_hr_change = max_hr_increase_per_sec * dt_seg  # [bpm]
        if hr_change > 0:  # 上昇時のみ上限を適用
            hr_change = min(hr_change, max_hr_change)
        current_HR += hr_change
        current_HR = max(current_HR, HR_rest)

        #available_VO2_eff = current_HR * O2_pulse_ml_per_beat / 1000.0
        available_VO2_eff = max(current_HR, HR_target_bpm_eff) * O2_pulse_ml_per_beat / 1000.0
        P_met_limit_W_env_eff = available_VO2_eff * E_O2_J_per_L / 60.0

        glycogen_data.append(glycogen_J / 4184.0)
        fat_data.append(fat_J / 4184.0)
        muscle_efficiency_data.append(muscle_efficiency)
        final_muscle_efficiency_data.append(final_muscle_efficiency)  # 実際の筋効率を記録
        vo2_usage_ratio_data.append(params["vo2_usage_ratio"])
        intensity_data.append(intensity)
        high_intensity_time_data.append(high_intensity_time_seconds / 3600.0)
        frac_glyc_actual_data.append(frac_glyc_actual)
        sigmoid_factor_data.append(sigmoid_factor)

        # 局所グリコーゲン残存率の記録
        if state.local_gly is not None:
            st = state.local_gly
            # 各部位の残存率
            rA = st["A_J"] / max(1e-6, st["A_init"]) if st["A_init"] > 0 else 1.0
            rB = st["B_J"] / max(1e-6, st["B_init"]) if st["B_init"] > 0 else 1.0
            rC = st["C_J"] / max(1e-6, st["C_init"]) if st["C_init"] > 0 else 1.0
            local_gly_A_ratio_data.append(max(0.0, min(1.0, rA)))
            local_gly_B_ratio_data.append(max(0.0, min(1.0, rB)))
            local_gly_C_ratio_data.append(max(0.0, min(1.0, rC)))
            # 最も消費が激しい部位（最小残存率）
            local_gly_min_ratio_data.append(min(rA, rB, rC))
        else:
            local_gly_A_ratio_data.append(1.0)
            local_gly_B_ratio_data.append(1.0)
            local_gly_C_ratio_data.append(1.0)
            local_gly_min_ratio_data.append(1.0)

        v = dist3d / max(1e-6, dt_seg)

        h_c = h_c_of_v_elevation(v, elevation_m, T_air_seg)
        R_conv = 1.0 / h_c if h_c > 0 else 1e9
        R_total = params["R_cloth"] + R_conv
        U = 1.0 / R_total if R_total > 0 else 0.0
        Q_conv = U * A_body * max(0.0, (T_core - T_air_seg))

        P_mech_used = (E_horizontal + (E_vertical * (params["descent_fraction"] if dz < 0 else 1.0))) / max(1e-6, dt_seg)
        Q_excess_W = P_met_limit_W_env_eff - P_mech_used - Q_conv
        Q_excess_W = max(0.0, Q_excess_W)
        Q_gen_J = Q_excess_W * dt_seg

        if params["use_thermal_storage"]:
            avail_storage_J = C_body * max(0.0, params["T_core_limit"] - T_core)
        else:
            avail_storage_J = 0.0
        Q_store_J = min(Q_gen_J, avail_storage_J)
        Q_evap_J = max(0.0, Q_gen_J - Q_store_J)

        if Q_store_J > 0 and params["use_thermal_storage"]:
            T_core += Q_store_J / C_body
            T_core = min(T_core, params["T_core_limit"])

        sweat_kg = Q_evap_J / L_v_J_per_kg
        sweat_kg = max(0.0, sweat_kg)

        mechanical_power_data.append(P_mech_used)
        sweat_data.append(total_sweat + sweat_kg)
        dx_data.append(dx)

        # CSV出力用の時系列データ（通常ステップ）
        total_work_J = E_horizontal + E_vertical
        mechanical_energy_data.append(total_work_J)
        metabolic_energy_data.append(P_met_used * dt_seg)
        sweat_incremental_data.append(sweat_kg)  # 各ステップでの発汗量
        distance_cumulative_data.append(total_dist)
        if i < len(points):
            timestamp_data.append(points[i].timestamp)
        else:
            timestamp_data.append(None)
        # 局所グリコーゲン残量（絶対値）
        if state.local_gly is not None:
            st = state.local_gly
            local_gly_A_absolute_data.append(st["A_J"] / 4184.0)
            local_gly_B_absolute_data.append(st["B_J"] / 4184.0)
            local_gly_C_absolute_data.append(st["C_J"] / 4184.0)
        else:
            local_gly_A_absolute_data.append(0.0)
            local_gly_B_absolute_data.append(0.0)
            local_gly_C_absolute_data.append(0.0)

        # 行動食（1.5h 後に段階的回復）
        action_food_timer += dt_seg / 60.0
        if action_food_timer >= params["action_food_interval_minutes"]:
            total_kcal = params["action_food_fruits_kcal"] + params["action_food_nuts_kcal"]
            action_food_pending += total_kcal * 4184.0
            action_food_supplement_time = total_time + 1.5 * 3600
            action_food_timer = 0.0

        if action_food_pending > 0.0 and total_time >= action_food_supplement_time:
            recovery_per_step = action_food_pending * (dt_seg / 3600.0)
            supplement_amount = min(recovery_per_step, action_food_pending)
            # 局所グリコーゲンに補給分を比例配分
            _localglyco_add_supplement(params, state, supplement_amount)
            # 局所グリコーゲンの合計からglycogen_Jを再計算
            if state.local_gly is not None:
                st = state.local_gly
                glycogen_J = st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]
            else:
                glycogen_J += supplement_amount
            action_food_pending -= supplement_amount
            # 行動食補給後の局所グリコーゲン残存率を再記録（グラフ用）
            if state.local_gly is not None:
                st = state.local_gly
                rA = st["A_J"] / max(1e-6, st["A_init"]) if st["A_init"] > 0 else 1.0
                rB = st["B_J"] / max(1e-6, st["B_init"]) if st["B_init"] > 0 else 1.0
                rC = st["C_J"] / max(1e-6, st["C_init"]) if st["C_init"] > 0 else 1.0
                if len(local_gly_A_ratio_data) > 0:
                    local_gly_A_ratio_data[-1] = max(0.0, min(1.0, rA))
                    local_gly_B_ratio_data[-1] = max(0.0, min(1.0, rB))
                    local_gly_C_ratio_data[-1] = max(0.0, min(1.0, rC))
                    local_gly_min_ratio_data[-1] = min(rA, rB, rC)

        if peak_rest_pending > 0.0 and total_time >= peak_rest_supplement_time:
            recovery_per_step = peak_rest_pending * (dt_seg / 3600.0)
            supplement_amount = min(recovery_per_step, peak_rest_pending)
            # 局所グリコーゲンに補給分を比例配分
            _localglyco_add_supplement(params, state, supplement_amount)
            # 局所グリコーゲンの合計からglycogen_Jを再計算
            if state.local_gly is not None:
                st = state.local_gly
                glycogen_J = st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]
            else:
                glycogen_J += supplement_amount
            peak_rest_pending -= supplement_amount

        # 補給処理の後に局所グリコーゲン残存率を再記録（グラフ用）
        if state.local_gly is not None:
            st = state.local_gly
            rA = st["A_J"] / max(1e-6, st["A_init"]) if st["A_init"] > 0 else 1.0
            rB = st["B_J"] / max(1e-6, st["B_init"]) if st["B_init"] > 0 else 1.0
            rC = st["C_J"] / max(1e-6, st["C_init"]) if st["C_init"] > 0 else 1.0
            # 既に記録された最後の値を上書き（補給後の値に更新）
            if len(local_gly_A_ratio_data) > 0:
                local_gly_A_ratio_data[-1] = max(0.0, min(1.0, rA))
                local_gly_B_ratio_data[-1] = max(0.0, min(1.0, rB))
                local_gly_C_ratio_data[-1] = max(0.0, min(1.0, rC))
                local_gly_min_ratio_data[-1] = min(rA, rB, rC)

        hr_data.append(current_HR)
        elevation_data.append(elevation_m)
        time_data.append(total_time)

        total_dist += dist3d
        total_time += dt_seg
        total_sweat += sweat_kg

        if dz > 0:
            total_up += dz
            up_time += dt_seg
            up_sweat += sweat_kg
        elif dz < 0:
            total_down += abs(dz)
            down_time += dt_seg
            down_sweat += sweat_kg

    # デバッグ出力
    logger.info(f"\n[デバッグ] ルート統計:")
    logger.info(f"  勾配分布（時間）: 急登={grade_stats['steep_up']/3600:.2f}h, 登り={grade_stats['up']/3600:.2f}h, 水平={grade_stats['flat']/3600:.2f}h, 緩下り={grade_stats['gentle_down']/3600:.2f}h, 急下り={grade_stats['steep_down']/3600:.2f}h")
    logger.info(f"  部位別累積消費（実際）: A={muscle_consumption_actual['A_total']:.1f}kcal, B={muscle_consumption_actual['B_total']:.1f}kcal, C={muscle_consumption_actual['C_total']:.1f}kcal")

    # 最終的な残存率を表示
    if state.local_gly is not None:
        st_final = state.local_gly
        A_init_kcal = st_final["A_init"] / 4184.0
        B_init_kcal = st_final["B_init"] / 4184.0
        C_init_kcal = st_final["C_init"] / 4184.0
        A_final_kcal = st_final["A_J"] / 4184.0
        B_final_kcal = st_final["B_J"] / 4184.0
        C_final_kcal = st_final["C_J"] / 4184.0
        rA_final = st_final["A_J"] / max(1e-6, st_final["A_init"]) if st_final["A_init"] > 0 else 1.0
        rB_final = st_final["B_J"] / max(1e-6, st_final["B_init"]) if st_final["B_init"] > 0 else 1.0
        rC_final = st_final["C_J"] / max(1e-6, st_final["C_init"]) if st_final["C_init"] > 0 else 1.0
        logger.info(f"  初期値: A={A_init_kcal:.1f}kcal, B={B_init_kcal:.1f}kcal, C={C_init_kcal:.1f}kcal")
        logger.info(f"  最終値: A={A_final_kcal:.1f}kcal, B={B_final_kcal:.1f}kcal, C={C_final_kcal:.1f}kcal")
        logger.info(f"  最終残存率: A={rA_final:.3f} ({A_final_kcal:.1f}/{A_init_kcal:.1f}), B={rB_final:.3f} ({B_final_kcal:.1f}/{B_init_kcal:.1f}), C={rC_final:.3f} ({C_final_kcal:.1f}/{C_init_kcal:.1f})")
        logger.info(f"  実際の消費量（初期-最終）: A={A_init_kcal-A_final_kcal:.1f}kcal, B={B_init_kcal-B_final_kcal:.1f}kcal, C={C_init_kcal-C_final_kcal:.1f}kcal")

    logger.info(f"  登り合計: {total_up:.1f}m, 下り合計: {total_down:.1f}m")

    return DayResult(
        date=route_day.date,
        distance_km=round(total_dist / 1000.0, 3),
        up_m=round(total_up, 1),
        down_m=round(total_down, 1),
        duration_h=round(total_time / 3600.0, 3),
        sweat_kg=round(total_sweat, 3),
        up_time_h=round(up_time / 3600.0, 3),
        down_time_h=round(down_time / 3600.0, 3),
        up_sweat_kg=round(up_sweat, 3),
        down_sweat_kg=round(down_sweat, 3),
        T_core_final=round(T_core, 2),
        hr_data=hr_data,
        elevation_data=elevation_data,
        time_data=time_data,
        mechanical_power_data=mechanical_power_data,
        sweat_data=sweat_data,
        dx_data=dx_data,
        glycogen_data=glycogen_data,
        fat_data=fat_data,
        muscle_efficiency_data=muscle_efficiency_data,
        final_muscle_efficiency_data=final_muscle_efficiency_data,
        vo2_usage_ratio_data=vo2_usage_ratio_data,
        intensity_data=intensity_data,
        high_intensity_time_data=high_intensity_time_data,
        frac_glyc_actual_data=frac_glyc_actual_data,
        sigmoid_factor_data=sigmoid_factor_data,
        local_gly_A_ratio_data=local_gly_A_ratio_data,
        local_gly_B_ratio_data=local_gly_B_ratio_data,
        local_gly_C_ratio_data=local_gly_C_ratio_data,
        local_gly_min_ratio_data=local_gly_min_ratio_data,
        mechanical_energy_data=mechanical_energy_data,
        metabolic_energy_data=metabolic_energy_data,
        sweat_incremental_data=sweat_incremental_data,
        local_gly_A_absolute_data=local_gly_A_absolute_data,
        local_gly_B_absolute_data=local_gly_B_absolute_data,
        local_gly_C_absolute_data=local_gly_C_absolute_data,
        distance_cumulative_data=distance_cumulative_data,
        timestamp_data=timestamp_data,
    )

# Terrain factor estimation from GPX log removed - using pure physical model
