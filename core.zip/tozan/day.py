"""1日のシミュレーション。

simulate_day は区間ごとのループで、各段の計算を順に呼ぶ（M-6 で分離、2026-10-02）。
補給休憩 meal_rest / 目標強度と W′ pacing / 旧式のエネルギー項 mechanics /
心拍 hr_model / 速度 speed / 代謝 metabolism / 熱収支 thermal / 補給 supply /
記録 recorder。各モジュールの内部は引き続き触らない（CLAUDE.md §3-3）。
"""

import logging
import math

from tozan.constants import E_O2_J_per_L
from tozan.environment import P_O2, calculate_body_surface_area
from tozan.hr_model import aerobic_ceiling, o2_line, update_heart_rate
from tozan.local_glycogen import _localglyco_init_if_needed
from tozan.meal_rest import (recover_ecc_at_rest_end, recover_fatigue_at_rest_end,
                              recover_fatigue_during_rest, rest_final_muscle_efficiency,
                              rest_heart_rate, rest_muscle_efficiency)
from tozan.mechanics import legacy_mech_power, legacy_work_terms
from tozan.metabolism import calculate_energy_metabolism_physical
from tozan.pacing import target_ratio, update_w_prime
from tozan.recorder import DayRecorder
from tozan.result import DayResult
from tozan.speed import segment_speed
from tozan.state import _glycogen_kcal_for_day, fat_kcal
from tozan.supply import absorb_carbs, action_food_step, eat_meal, gluconeogenesis_step
from tozan.terrain import estimate_terrain_factor
from tozan.thermal import rest_heat_step, walk_heat_step

logger = logging.getLogger(__name__)


def _init_carryover_fatigue(state, params):
    """前日からの疲労の持ち越しを state に入れ、high_intensity_time_seconds を返す。"""
    # 疲労の初期化（前日からの持ち越しがある場合は使用）
    if state.initial_fatigue_hours is not None:
        high_intensity_time_seconds = state.initial_fatigue_hours * 3600.0
        state.initial_fatigue_hours = None
    else:
        high_intensity_time_seconds = 0.0

    # 局所疲労の初期化（前日からの持ち越しがある場合は使用）
    if state.initial_local_fatigue is not None:
        initial_local_fatigue = state.initial_local_fatigue
        # 局所グリコーゲン状態を初期化（グリコーゲンは後で設定される）
        _localglyco_init_if_needed(params, state, 0.0)
        st = state.local_gly
        # 前日からの持ち越し疲労を設定
        st["fatigue_A"] = initial_local_fatigue.get("fatigue_A", 0.0)
        st["fatigue_B"] = initial_local_fatigue.get("fatigue_B", 0.0)
        st["fatigue_C"] = initial_local_fatigue.get("fatigue_C", 0.0)
        state.initial_local_fatigue = None
        logger.info(f"Day: Initial local fatigue set - A: {st['fatigue_A']/3600.0:.2f}h, B: {st['fatigue_B']/3600.0:.2f}h, C: {st['fatigue_C']/3600.0:.2f}h")
    return high_intensity_time_seconds


def _add_grade_time(grade_stats, grade, dt_seg):
    """勾配帯ごとの時間を足す（デバッグ出力用）。"""
    if grade >= 0.25:
        grade_stats["steep_up"] += dt_seg
    elif grade >= 0.10:
        grade_stats["up"] += dt_seg
    elif grade > -0.10:
        grade_stats["flat"] += dt_seg
    elif grade > -0.25:
        grade_stats["gentle_down"] += dt_seg
    else:
        grade_stats["steep_down"] += dt_seg


def _log_day_debug(grade_stats, muscle_consumption_actual, state, total_up, total_down):
    """日の終わりのデバッグ出力（勾配帯ごとの時間・部位別の消費・残存率）。"""
    logger.info(f"\n[デバッグ] ルート統計:")
    logger.info(f"  勾配分布（時間）: 急登={grade_stats['steep_up']/3600:.2f}h, 登り={grade_stats['up']/3600:.2f}h, 水平={grade_stats['flat']/3600:.2f}h, 緩下り={grade_stats['gentle_down']/3600:.2f}h, 急下り={grade_stats['steep_down']/3600:.2f}h")
    logger.info(f"  部位別累積消費（実際）: A={muscle_consumption_actual['A_total']:.1f}kcal, B={muscle_consumption_actual['B_total']:.1f}kcal, C={muscle_consumption_actual['C_total']:.1f}kcal")

    # 最終的な残存率を表示
    if state.local_gly is not None:
        st_final = state.local_gly
        A_init_kcal = st_final["A_init"] / 4184.0
        B_init_kcal = st_final["B_init"] / 4184.0
        C_init_kcal = st_final["C_init"] / 4184.0
        A_final_kcal = st_final["A_J"] / 4184.0
        B_final_kcal = st_final["B_J"] / 4184.0
        C_final_kcal = st_final["C_J"] / 4184.0
        rA_final = st_final["A_J"] / max(1e-6, st_final["A_init"]) if st_final["A_init"] > 0 else 1.0
        rB_final = st_final["B_J"] / max(1e-6, st_final["B_init"]) if st_final["B_init"] > 0 else 1.0
        rC_final = st_final["C_J"] / max(1e-6, st_final["C_init"]) if st_final["C_init"] > 0 else 1.0
        logger.info(f"  初期値: A={A_init_kcal:.1f}kcal, B={B_init_kcal:.1f}kcal, C={C_init_kcal:.1f}kcal")
        logger.info(f"  最終値: A={A_final_kcal:.1f}kcal, B={B_final_kcal:.1f}kcal, C={C_final_kcal:.1f}kcal")
        logger.info(f"  最終残存率: A={rA_final:.3f} ({A_final_kcal:.1f}/{A_init_kcal:.1f}), B={rB_final:.3f} ({B_final_kcal:.1f}/{B_init_kcal:.1f}), C={rC_final:.3f} ({C_final_kcal:.1f}/{C_init_kcal:.1f})")
        logger.info(f"  実際の消費量（初期-最終）: A={A_init_kcal-A_final_kcal:.1f}kcal, B={B_init_kcal-B_final_kcal:.1f}kcal, C={C_init_kcal-C_final_kcal:.1f}kcal")

    logger.info(f"  登り合計: {total_up:.1f}m, 下り合計: {total_down:.1f}m")


def simulate_day(route_day, params, state):
    points = route_day.points
    # 質量は「その日の朝の体重」＋ザック。多日では前日までに燃やした脂肪と
    # 失ったグリコーゲン（随伴水込み）のぶん軽くなる（Phase 6-3、2026-09-23）。
    # VO2max は心肺機能で決まる絶対量なので、weight_kg（初期体重）のまま使う
    # ―― 体重に連動させると体力まで落ちたことになり符号が逆になる（作者の指摘）。
    # 安静時代謝も除脂肪量に比例するので初期体重のままでよい。
    day_weight_kg = state.current_weight_kg if state.current_weight_kg is not None else params["weight_kg"]
    mass = day_weight_kg + params["pack_kg"]
    current_HR = params["HR_rest"]
    # 安静時代謝は体重に比例する（1 MET = 3.5 ml/(kg・分)、ACSM の定義値）。
    # 以前は 85 W（作者の 71kg での値）を体重によらない定数として持っており、
    # 体格の違う人ほど「天井 − 安静」から過大に引かれて遅くなっていた（2026-09-23）。
    PWR_rest_W = (params["rest_vo2_ml_per_kg_min"] * params["weight_kg"]
                  * E_O2_J_per_L / 1000.0 / 60.0)

    # 心拍の直線の最大点は、本人の VO2max × 体重そのもの。以前は体脂肪率による補正
    # r_muscle = (1 − f_fat)/(1 − 0.22) を掛けていたが、0.22 は作者の旧体脂肪率の
    # 取り残しで出典がなく、VO2max は本人の体組成で測った値なので補正は不要（2026-09-27）。
    VO2_L_per_min = (params["vo2max_ml_kg_min"] * params["weight_kg"]) / 1000.0

    P_O2_std = P_O2(20.0, 0.5, 0.0)
    C_body = 3494.0 * params["weight_kg"]
    A_body = calculate_body_surface_area(params["weight_kg"], params["height_cm"])

    HR_rest = params["HR_rest"]

    total_up = total_down = total_dist = total_time = total_sweat = 0.0

    # 持続できる強度（CP）と、それを超えて出せる余力（W'）。Phase 4a-1、2026-09-22。
    # vo2_usage_ratio は「その時間だけ出し続けられる出力の割合」（80% なら1時間、
    # 70% なら2時間、依頼者の経験式）。CP を超えて出した分 (r − CP) × 時間 が W' を
    # 減らし、尽きたら天井が CP に落ちる。日内の回復はしない（疲労は補給しても
    # すぐには戻らない）。日の始めは満タン。翌日も満タン（Phase 4b で見直す）。
    w_prime_left_h = params["w_prime_h"]
    P_met_vo2max_day_W = params["vo2max_ml_kg_min"] * params["weight_kg"] / 1000.0 * E_O2_J_per_L / 60.0
    up_time = down_time = up_sweat = down_sweat = 0.0
    T_core = params["T_core_init"]

    # エネルギーストアの初期化
    params.setdefault("glycogen_depletion_effect_c", 0.35)
    params.setdefault("glycogen_depletion_muscle_eff_c", 0.3)
    params.setdefault("sigmoid_k", 8.0)
    params.setdefault("sigmoid_x0", 0.3)
    params.setdefault("I_low", 0.30)
    params.setdefault("I_high", 0.90)
    params.setdefault("fat_supply_limit_W", 400.0)
    params.setdefault("fatigue_base_rate", 0.02)
    params.setdefault("min_muscle_efficiency_multiplier", 0.65)

    glycogen_J = _glycogen_kcal_for_day(params, state) * 4184.0
    # 初日は体組成から、2日目以降は前夜の収支を通した持ち越し（Phase 6-3）
    fat_J = (state.fat_kcal_start if state.fat_kcal_start is not None
             else fat_kcal(params)) * 4184.0

    # まとまった補給（休憩つき）のタイマー（Phase 4b-2、2026-09-22）。
    # 以前は最高標高−10m に達した点で1回だけ山頂休憩（10 分、おにぎり＋アミノバイタル）を
    # 取っていたが、縦走・周回では山頂が到着点にならず、計画ツールとしては補給を
    # 「歩行時間 N 分ごとに M 分止まって K kcal」と計画的に置くほうが一貫する（作者決定）。
    meal_timer_s = 0.0           # 前回のまとまった補給からの歩行時間 [s]
    in_rest = False
    rest_start_time = None       # 休憩開始時刻
    hr_at_rest_start = None      # 休憩開始時の心拍数

    # 補給管理
    action_food_timer = 0.0
    # 吸収の待ち行列 [吸収が始まる時刻 [s], 残り [J]]（Phase 4b-2）。行動食もまとまった補給も同じ経路
    carb_queue = []
    carb_rate_W = params["carb_absorption_g_per_h"] * 4.0 * 4184.0 / 3600.0
    carb_delay_s = params["carb_absorption_delay_min"] * 60.0
    max_fat_power_W = 0.007 * params["weight_kg"] * 37e3 / 60   # metabolism.py と同じ脂肪酸化の上限


    # 前日からの疲労の持ち越し
    high_intensity_time_seconds = _init_carryover_fatigue(state, params)

    muscle_efficiency = 1.0
    # 疲労だけの経路（M-11-1）。休憩中は更新しない＝直前の値を持ち越す。
    # 遠心性の筋損傷も高強度の蓄積も、数分の休憩では回復しないため。
    muscle_efficiency_fatigue_only = 1.0
    ecc_damage_factor = 1.0   # 下りの筋損傷の因子 1/(1+ecc)（前ステップの値。Phase 4b-1）

    # 時系列の記録（M-6-1。最初のポイントのtimestampを記録）
    rec = DayRecorder(points[0].timestamp if len(points) > 0 else None)

    # デバッグ用：勾配分布と部位別消費の統計
    grade_stats = {"steep_up": 0, "up": 0, "flat": 0, "gentle_down": 0, "steep_down": 0}
    muscle_consumption_actual = {"A_total": 0.0, "B_total": 0.0, "C_total": 0.0}  # 実際の消費量

    # 補給休憩中はこの点をまだ歩いていないので i を進めない。for だと休憩の
    # 10秒ステップごとに点を1つ捨ててしまい、その距離と標高差が加算されないまま
    # ルートが切り詰められる（休憩1分＝6点。M-1、2026-09-21）。
    i = 1
    dt_seg_prev = None   # 前の区間の dt_seg（ⓜ の分岐だけが使う。M-6-6）
    while i < len(points):
        dx = points[i].dist_m
        dz = points[i].ele_diff
        dist3d = math.hypot(dx, dz)
        if dist3d <= 0:
            i += 1
            continue

        elevation_m = points[i].ele

        # 勾配（局所モデル用）
        grade = dz / max(dx, 1e-6)
        state.last_grade = grade

        # この区間の天井の割合（W′ → CP、勾配の変調。M-6-5 で tozan/pacing.py へ）
        ratio_eff = target_ratio(w_prime_left_h, grade, params)

        # まとまった補給のタイマー。歩行時間が間隔に達したら、この点を歩く前に止まる。
        # 最後の点の手前では止まらない（ゴール後の休憩は計画に要らない）。
        if not in_rest and meal_timer_s >= params["meal_interval_minutes"] * 60.0 and i < len(points) - 1:
            meal_timer_s = 0.0
            carb_queue, fat_J = eat_meal(carb_queue, fat_J, total_time, carb_delay_s, params)
            if params["meal_rest_minutes"] > 0.0:
                in_rest = True
                rest_start_time = total_time
                hr_at_rest_start = current_HR
                logger.info(f"Meal rest started: HR={hr_at_rest_start:.1f} bpm at time={total_time/3600:.2f}h")

        # 休憩処理（まとまった補給）
        if in_rest:
            rest_time_seconds = params["meal_rest_minutes"] * 60.0

            # 休憩中は各ステップで時間を進める（dt_segを固定値に設定）
            # 休憩中の時間ステップ（10秒ごと）
            dt_rest_step = 10.0  # 休憩中の時間ステップ [秒]
            total_time += dt_rest_step
            rest_elapsed_seconds = total_time - rest_start_time

            # 休憩中は各ステップで心拍数を回復させる
            if rest_elapsed_seconds < rest_time_seconds:
                # 休憩中：休憩開始時からの経過時間に基づいて心拍数を回復
                current_HR = rest_heart_rate(hr_at_rest_start, rest_elapsed_seconds, params)

                # 部位別疲労の回復（休憩中。1 ステップぶん、§5 ⓚ）
                high_intensity_time_seconds = recover_fatigue_during_rest(state, rest_elapsed_seconds, dt_rest_step, params)
            else:
                # 休憩終了
                current_HR = rest_heart_rate(hr_at_rest_start, rest_time_seconds, params)
                logger.info(f"Meal rest completed: HR={current_HR:.1f} bpm after {rest_time_seconds/60:.1f} min")

                # 疲労回復を最終的に適用（M-6-8 で tozan/meal_rest.py へ）
                high_intensity_time_seconds = recover_fatigue_at_rest_end(
                    state, rest_time_seconds, dt_rest_step, high_intensity_time_seconds, params)

            # 休憩中の筋効率（M-6-8 で tozan/meal_rest.py へ）
            muscle_efficiency = rest_muscle_efficiency(state, glycogen_J, params)

            # 休憩中は筋効率を前の値を保持（M-6-8 で tozan/meal_rest.py へ）
            final_muscle_efficiency = rest_final_muscle_efficiency(rec.last_final_muscle_efficiency(), muscle_efficiency, params)

            # 休憩中の熱収支（Phase 7-1。M-6-2 で tozan/thermal.py へ）
            T_core, sweat_rest_kg = rest_heat_step(T_core, elevation_m, PWR_rest_W, dt_rest_step, A_body, C_body, params)
            total_sweat += sweat_rest_kg

            # 休憩中のデータ記録（各ステップで記録）
            # 休憩中は通常の運動計算をスキップするため、ここでデータを記録してcontinue
            rec.record_rest(
                current_HR, elevation_m, total_time, glycogen_J, fat_J,
                muscle_efficiency, final_muscle_efficiency, params["vo2_usage_ratio"],
                high_intensity_time_seconds, total_sweat, state.hypoglycemic,
                sweat_rest_kg, total_dist, state.local_gly)

            # 休憩終了
            if rest_elapsed_seconds >= rest_time_seconds:
                recover_ecc_at_rest_end(state, rest_time_seconds, params)
                in_rest = False
                rest_start_time = None

            # 休憩中は通常の運動計算をスキップする。i を進めないので、
            # この点は休憩が終わってから改めて歩く。
            continue

        terrain_factor = estimate_terrain_factor(
            0.0, elevation_m,
            params["terrain_z0_m"], params["terrain_z1_m"], params["terrain_factor_max"])

        # 旧式のエネルギー項（発汗の経路と記録用。M-6-3 で tozan/mechanics.py へ）
        E_vertical, E_horizontal = legacy_work_terms(dx, dz, mass, terrain_factor, params)

        T_air_seg = params["T_air"] - params["lapse_rate"] * (elevation_m - params["T_air_elevation"])
        # 心拍と酸素摂取量の直線（M-6-7 で tozan/hr_model.py へ）
        O2_pulse_ml_per_beat, VO2_offset_ml_per_min = o2_line(
            elevation_m, T_air_seg, VO2_L_per_min, P_O2_std, PWR_rest_W, HR_rest, params)

        # 目標強度で出せる天井（M-6-7 で tozan/hr_model.py へ）
        P_met_limit_W_env = aerobic_ceiling(
            current_HR, ratio_eff, O2_pulse_ml_per_beat, VO2_offset_ml_per_min,
            max_fat_power_W, state, params)

        # 速度の決定（M-6-6 で tozan/speed.py へ）
        current_muscle_efficiency, dt_seg, P_used_net_W, P_final_W = segment_speed(
            dx, dz, dist3d, grade, mass, terrain_factor, P_met_limit_W_env, PWR_rest_W,
            ecc_damage_factor, points[i].hands, E_vertical, E_horizontal, dt_seg_prev, params)
        dt_seg_prev = dt_seg

        # エネルギー代謝（局所モデル含む）
        #
        # 貯蔵から引く燃料は、疲労で低下したあとの筋効率で計算する。
        # 以前は疲労前の定数（efficiency_up / efficiency_down、既定0.25）で
        # 割っており、表示用kcal（metabolic_energy で final_muscle_efficiency を使う）とは
        # 別の値になっていた。多日縦走の後半では最大1.7倍ずれ、
        # 「疲労→効率低下→燃料消費増→さらに枯渇」の連鎖が切れていた。
        #
        # 筋効率倍率は代謝計算の出力なので同一ステップ内では確定しない。
        # 速度の決定（segment_speed）が既に前ステップの muscle_efficiency を使っているので、
        # それに揃えて1ステップ遅れで参照する（明示的時間積分の標準的な扱い）。
        P_met_used_current = P_final_W / max(1e-6, current_muscle_efficiency * muscle_efficiency)

        # デバッグ：勾配分類
        _add_grade_time(grade_stats, grade, dt_seg)

        # デバッグ：局所グリコーゲンの消費前の値を記録
        st_before = None
        if state.local_gly is not None:
            st_before = state.local_gly.copy()

        energy_result = calculate_energy_metabolism_physical(
            P_met_used_current, dt_seg, P_met_limit_W_env, params, state,
            glycogen_J, fat_J, high_intensity_time_seconds, dz
        )

        # デバッグ：実際の局所グリコーゲン消費量を記録
        drawn_pools = None
        if st_before is not None and state.local_gly is not None:
            st_after = state.local_gly
            # 各部位の実際の消費量（J単位）
            consumed_A = (st_before["A_J"] - st_after["A_J"]) / 4184.0  # kcal換算
            consumed_B = (st_before["B_J"] - st_after["B_J"]) / 4184.0
            consumed_C = (st_before["C_J"] - st_after["C_J"]) / 4184.0
            muscle_consumption_actual["A_total"] += max(0.0, consumed_A)
            muscle_consumption_actual["B_total"] += max(0.0, consumed_B)
            muscle_consumption_actual["C_total"] += max(0.0, consumed_C)
            # この区間で各プールから取り崩した量[J]。あとで吸収した糖を
            # 「需要の肩代わり」として同じ比率で戻すのに使う（Phase 6-4）。
            drawn_pools = dict(
                (key, max(0.0, st_before[key] - st_after[key]))
                for key in ("Liver_J", "A_J", "B_J", "C_J"))

        glycogen_J = energy_result["glycogen_J"]
        fat_J = energy_result["fat_J"]
        frac_glyc_actual = energy_result["frac_glyc_actual"]
        muscle_efficiency = energy_result["muscle_efficiency"]
        muscle_efficiency_fatigue_only = energy_result["muscle_efficiency_fatigue_only"]
        ecc_damage_factor = energy_result["local_damage_factor"]
        eff_up = energy_result["eff_up"]
        eff_down = energy_result["eff_down"]
        high_intensity_time_seconds = energy_result["high_intensity_time_seconds"]
        intensity = energy_result["intensity"]
        sigmoid_factor = energy_result["sigmoid_factor"]

        if dz > 0:
            final_muscle_efficiency = eff_up
        elif dz < 0:
            final_muscle_efficiency = eff_down
        else:
            final_muscle_efficiency = (eff_up + eff_down) / 2.0

        P_met_used = P_final_W / max(1e-6, final_muscle_efficiency)

        # 心拍の目標と更新（M-6-7 で tozan/hr_model.py へ）
        current_HR, P_met_actual, P_met_limit_W_env_eff = update_heart_rate(
            current_HR, P_met_used, ratio_eff, dz, dt_seg, O2_pulse_ml_per_beat,
            VO2_offset_ml_per_min, PWR_rest_W, HR_rest, params)

        rec.record_walk_fuel(
            glycogen_J, fat_J, muscle_efficiency, final_muscle_efficiency, ratio_eff, intensity,
            high_intensity_time_seconds, frac_glyc_actual, sigmoid_factor, state.local_gly)

        P_mech_used = legacy_mech_power(E_horizontal, E_vertical, dz, dt_seg, params)
        # 熱収支と発汗（M-6-2 で tozan/thermal.py へ）
        T_core, sweat_kg = walk_heat_step(
            T_core, dist3d, dt_seg, elevation_m, T_air_seg, P_met_actual, P_met_limit_W_env_eff,
            P_mech_used, PWR_rest_W, A_body, C_body, params)

        # CSV出力用の時系列データ（通常ステップ）
        total_work_J = E_horizontal + E_vertical
        rec.record_walk_heat(
            P_mech_used, total_sweat, sweat_kg, dx, total_work_J, P_met_used, dt_seg, total_dist,
            points[i].timestamp if i < len(points) else None,
            state.local_gly)

        # 行動食・糖新生・吸収（M-6-4 で tozan/supply.py へ）
        action_food_timer, carb_queue, fat_J = action_food_step(
            action_food_timer, carb_queue, fat_J, total_time, dt_seg, carb_delay_s, params)
        fat_J = gluconeogenesis_step(state, fat_J, dt_seg, params)
        carb_queue, glycogen_J = absorb_carbs(
            carb_queue, total_time, dt_seg, carb_rate_W, glycogen_J, drawn_pools, state, params)
        rec.record_hypoglycemic(state.hypoglycemic)

        # 補給処理の後に局所グリコーゲン残存率を再記録（グラフ用）
        rec.overwrite_last_ratios(state.local_gly)

        rec.record_walk_position(current_HR, elevation_m, total_time)

        total_dist += dist3d
        # W' の更新（M-6-5 で tozan/pacing.py へ）
        w_prime_left_h = update_w_prime(w_prime_left_h, P_used_net_W, PWR_rest_W, P_met_vo2max_day_W, dt_seg, params)
        total_time += dt_seg
        meal_timer_s += dt_seg
        total_sweat += sweat_kg

        if dz > 0:
            total_up += dz
            up_time += dt_seg
            up_sweat += sweat_kg
        elif dz < 0:
            total_down += abs(dz)
            down_time += dt_seg
            down_sweat += sweat_kg

        i += 1

    # デバッグ出力
    _log_day_debug(grade_stats, muscle_consumption_actual, state, total_up, total_down)

    state.fat_kcal_end = fat_J / 4184.0

    return DayResult(
        date=route_day.date,
        distance_km=round(total_dist / 1000.0, 3),
        up_m=round(total_up, 1),
        down_m=round(total_down, 1),
        duration_h=round(total_time / 3600.0, 3),
        sweat_kg=round(total_sweat, 3),
        up_time_h=round(up_time / 3600.0, 3),
        down_time_h=round(down_time / 3600.0, 3),
        up_sweat_kg=round(up_sweat, 3),
        down_sweat_kg=round(down_sweat, 3),
        T_core_final=round(T_core, 2),
        **rec.as_kwargs(),
    )

# Terrain factor estimation from GPX log removed - using pure physical model
