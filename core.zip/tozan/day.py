"""Single-day simulation. Internals are kept as one function."""

import logging
import math

from tozan.constants import E_O2_J_per_L, L_v_J_per_kg, WALK_EFF, g
from tozan.environment import P_O2, calculate_body_surface_area, h_c_of_v_elevation
from tozan.heart_rate import calculate_heart_rate_recovery_exponential
from tozan.local_glycogen import _localglyco_add_supplement, _localglyco_init_if_needed
from tozan.metabolism import calculate_energy_metabolism_physical
from tozan.result import DayResult
from tozan.state import _glycogen_kcal_for_day, fat_kcal, glycogen_capacity_kcal, liver_capacity_g
from tozan.terrain import estimate_terrain_factor

logger = logging.getLogger(__name__)


def simulate_day(route_day, params, state, terrain_factor_dict=None):
    points = route_day.points
    # 質量は「その日の朝の体重」＋ザック。多日では前日までに燃やした脂肪と
    # 失ったグリコーゲン（随伴水込み）のぶん軽くなる（Phase 6-3、2026-09-23）。
    # VO2max は心肺機能で決まる絶対量なので、weight_kg（初期体重）のまま使う
    # ―― 体重に連動させると体力まで落ちたことになり符号が逆になる（作者の指摘）。
    # 安静時代謝も除脂肪量に比例するので初期体重のままでよい。
    day_weight_kg = state.current_weight_kg if state.current_weight_kg is not None else params["weight_kg"]
    mass = day_weight_kg + params["pack_kg"]
    current_HR = params["HR_rest"]
    # 安静時代謝は体重に比例する（1 MET = 3.5 ml/(kg・分)、ACSM の定義値）。
    # 以前は 85 W（作者の 71kg での値）を体重によらない定数として持っており、
    # 体格の違う人ほど「天井 − 安静」から過大に引かれて遅くなっていた（2026-09-23）。
    PWR_rest_W = (params["rest_vo2_ml_per_kg_min"] * params["weight_kg"]
                  * E_O2_J_per_L / 1000.0 / 60.0)

    # Calculate muscle ratio from body fat percentage
    r_muscle = (1 - params["f_fat"]) / (1 - 0.22)
    VO2_L_per_min = (params["vo2max_ml_kg_min"] * params["weight_kg"]) * r_muscle / 1000.0

    P_O2_std = P_O2(20.0, 0.5, 0.0)
    C_body = 3494.0 * params["weight_kg"]
    A_body = calculate_body_surface_area(params["weight_kg"], params["height_cm"])

    HR_max = params["HR_max"]
    HR_rest = params["HR_rest"]

    total_up = total_down = total_dist = total_time = total_sweat = 0.0

    # 持続できる強度（CP）と、それを超えて出せる余力（W'）。Phase 4a-1、2026-09-22。
    # vo2_usage_ratio は「その時間だけ出し続けられる出力の割合」（80% なら1時間、
    # 70% なら2時間、依頼者の経験式）。CP を超えて出した分 (r − CP) × 時間 が W' を
    # 減らし、尽きたら天井が CP に落ちる。日内の回復はしない（疲労は補給しても
    # すぐには戻らない）。日の始めは満タン。翌日も満タン（Phase 4b で見直す）。
    w_prime_left_h = params["w_prime_h"]
    P_met_vo2max_day_W = params["vo2max_ml_kg_min"] * params["weight_kg"] / 1000.0 * E_O2_J_per_L / 60.0
    up_time = down_time = up_sweat = down_sweat = 0.0
    T_core = params["T_core_init"]

    # エネルギーストアの初期化
    params.setdefault("glycogen_depletion_effect_c", 0.35)
    params.setdefault("glycogen_depletion_muscle_eff_c", 0.3)
    params.setdefault("sigmoid_k", 8.0)
    params.setdefault("sigmoid_x0", 0.3)
    params.setdefault("I_low", 0.30)
    params.setdefault("I_high", 0.90)
    params.setdefault("fat_supply_limit_W", 400.0)
    params.setdefault("fatigue_base_rate", 0.02)
    params.setdefault("min_muscle_efficiency_multiplier", 0.65)

    glycogen_J = _glycogen_kcal_for_day(params, state) * 4184.0
    # 初日は体組成から、2日目以降は前夜の収支を通した持ち越し（Phase 6-3）
    fat_J = (state.fat_kcal_start if state.fat_kcal_start is not None
             else fat_kcal(params)) * 4184.0

    # 山頂検出の準備
    # まとまった補給（休憩つき）のタイマー（Phase 4b-2、2026-09-22）。
    # 以前は最高標高−10m に達した点で1回だけ山頂休憩（10 分、おにぎり＋アミノバイタル）を
    # 取っていたが、縦走・周回では山頂が到着点にならず、計画ツールとしては補給を
    # 「歩行時間 N 分ごとに M 分止まって K kcal」と計画的に置くほうが一貫する（作者決定）。
    meal_timer_s = 0.0           # 前回のまとまった補給からの歩行時間 [s]
    in_rest = False
    rest_start_time = None       # 休憩開始時刻
    hr_at_rest_start = None      # 休憩開始時の心拍数

    # 補給管理
    action_food_timer = 0.0
    # 吸収の待ち行列 [吸収が始まる時刻 [s], 残り [J]]（Phase 4b-2）。行動食も山頂の補給も同じ経路
    carb_queue = []
    carb_rate_W = params["carb_absorption_g_per_h"] * 4.0 * 4184.0 / 3600.0
    carb_delay_s = params["carb_absorption_delay_min"] * 60.0
    max_fat_power_W = 0.007 * params["weight_kg"] * 37e3 / 60   # metabolism.py と同じ脂肪酸化の上限


    # 疲労の初期化（前日からの持ち越しがある場合は使用）
    if state.initial_fatigue_hours is not None:
        high_intensity_time_seconds = state.initial_fatigue_hours * 3600.0
        state.initial_fatigue_hours = None
    else:
        high_intensity_time_seconds = 0.0

    # 局所疲労の初期化（前日からの持ち越しがある場合は使用）
    if state.initial_local_fatigue is not None:
        initial_local_fatigue = state.initial_local_fatigue
        # 局所グリコーゲン状態を初期化（グリコーゲンは後で設定される）
        _localglyco_init_if_needed(params, state, 0.0)
        st = state.local_gly
        # 前日からの持ち越し疲労を設定
        st["fatigue_A"] = initial_local_fatigue.get("fatigue_A", 0.0)
        st["fatigue_B"] = initial_local_fatigue.get("fatigue_B", 0.0)
        st["fatigue_C"] = initial_local_fatigue.get("fatigue_C", 0.0)
        state.initial_local_fatigue = None
        logger.info(f"Day: Initial local fatigue set - A: {st['fatigue_A']/3600.0:.2f}h, B: {st['fatigue_B']/3600.0:.2f}h, C: {st['fatigue_C']/3600.0:.2f}h")

    muscle_efficiency = 1.0
    # 疲労だけの経路（M-11-1）。休憩中は更新しない＝直前の値を持ち越す。
    # 遠心性の筋損傷も高強度の蓄積も、数分の休憩では回復しないため。
    muscle_efficiency_fatigue_only = 1.0
    ecc_damage_factor = 1.0   # 下りの筋損傷の因子 1/(1+ecc)（前ステップの値。Phase 4b-1）

    # Record lists
    hr_data = []
    elevation_data = []
    time_data = []
    mechanical_power_data = []
    sweat_data = []
    dx_data = []

    glycogen_data = []
    fat_data = []
    muscle_efficiency_data = []
    final_muscle_efficiency_data = []  # 実際の筋効率（eff_up/eff_down）
    vo2_usage_ratio_data = []
    intensity_data = []
    high_intensity_time_data = []
    frac_glyc_actual_data = []
    sigmoid_factor_data = []

    # 局所グリコーゲン残量データ（グラフ用）
    local_gly_A_ratio_data = []
    local_gly_B_ratio_data = []
    local_gly_C_ratio_data = []
    local_gly_min_ratio_data = []  # 最も消費が激しい部位の残存率

    # CSV出力用の時系列データ
    mechanical_energy_data = []  # 必要な機械的エネルギー [J]
    hypoglycemic_data = []       # しゃりばて中か（肝が空かつ吸収なし。Phase 4b-2）
    metabolic_energy_data = []  # 代謝エネルギー [J]
    sweat_incremental_data = []  # 各ステップでの発汗量 [kg]
    local_gly_A_absolute_data = []  # 部位Aのグリコーゲン残量 [kcal]
    local_gly_B_absolute_data = []  # 部位Bのグリコーゲン残量 [kcal]
    local_gly_C_absolute_data = []  # 部位Cのグリコーゲン残量 [kcal]
    local_gly_liver_absolute_data = []  # 肝グリコーゲン残量 [kcal]（UI表示用、2026-09-22）
    distance_cumulative_data = []  # 累積距離 [m]
    timestamp_data = []  # GPXポイントのtimestamp

    # 最初のポイントのtimestampを記録
    if len(points) > 0:
        timestamp_data.append(points[0].timestamp)
    else:
        timestamp_data.append(None)

    # デバッグ用：勾配分布と部位別消費の統計
    grade_stats = {"steep_up": 0, "up": 0, "flat": 0, "gentle_down": 0, "steep_down": 0}
    muscle_consumption_actual = {"A_total": 0.0, "B_total": 0.0, "C_total": 0.0}  # 実際の消費量

    # 山頂休憩中はこの点をまだ歩いていないので i を進めない。for だと休憩の
    # 10秒ステップごとに点を1つ捨ててしまい、その距離と標高差が加算されないまま
    # ルートが切り詰められる（休憩1分＝6点。M-1、2026-09-21）。
    i = 1
    while i < len(points):
        dx = points[i].dist_m
        dz = points[i].ele_diff
        dist3d = math.hypot(dx, dz)
        if dist3d <= 0:
            i += 1
            continue

        slope_deg = math.degrees(math.atan2(abs(dz), dx)) if dx > 0 else 0.0
        elevation_m = points[i].ele

        # 勾配（局所モデル用）
        grade = dz / max(dx, 1e-6)
        state.last_grade = grade

        # この区間の天井の割合。W' が残っていれば目標どおり、尽きたら CP
        # （目標が CP 以下ならそのまま）。有酸素の天井と心拍の上限に使う。
        # 下りの上限（ecc_power_ratio）には使わない ―― W' は代謝の余力で、
        # 脚が落下を止める側（機械的・神経筋）とは別の系（docs/06_ Phase 4a）。
        if w_prime_left_h > 1e-9 or params["vo2_usage_ratio"] <= params["cp_ratio"]:
            ratio_eff = params["vo2_usage_ratio"]
        else:
            ratio_eff = params["cp_ratio"]

        # まとまった補給のタイマー。歩行時間が間隔に達したら、この点を歩く前に止まる。
        # 最後の点の手前では止まらない（ゴール後の休憩は計画に要らない）。
        if not in_rest and meal_timer_s >= params["meal_interval_minutes"] * 60.0 and i < len(points) - 1:
            meal_timer_s = 0.0
            meal_carb_kcal = params["meal_kcal"] * params["meal_carb_fraction"]
            carb_queue.append([total_time + carb_delay_s, meal_carb_kcal * 4184.0])
            fat_J += (params["meal_kcal"] - meal_carb_kcal) * 4184.0   # 糖質以外は脂肪プールへ
            if params["meal_rest_minutes"] > 0.0:
                in_rest = True
                rest_start_time = total_time
                hr_at_rest_start = current_HR
                logger.info(f"Meal rest started: HR={hr_at_rest_start:.1f} bpm at time={total_time/3600:.2f}h")

        # 休憩処理（まとまった補給）
        if in_rest:
            rest_time_seconds = params["meal_rest_minutes"] * 60.0

            # 休憩中は各ステップで時間を進める（dt_segを固定値に設定）
            # 休憩中の時間ステップ（10秒ごと）
            dt_rest_step = 10.0  # 休憩中の時間ステップ [秒]
            total_time += dt_rest_step
            rest_elapsed_seconds = total_time - rest_start_time

            # 休憩中は各ステップで心拍数を回復させる
            if rest_elapsed_seconds < rest_time_seconds:
                # 休憩中：休憩開始時からの経過時間に基づいて心拍数を回復
                recovery_time_constant = params["rest_hr_recovery_time_constant"]
                current_HR = calculate_heart_rate_recovery_exponential(
                    hr_at_rest_start, params["HR_rest"], rest_elapsed_seconds,
                    recovery_time_constant,
                    hr_target_offset=35.0
                )

                # 部位別疲労の回復（休憩中、累積的に）
                if state.local_gly is not None:
                    st = state.local_gly
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    if fatigue_model_type == "exponential":
                        # 指数関数的回復（累積的に）
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-rest_elapsed_seconds / tau_recovery_seconds)
                        st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-rest_elapsed_seconds / tau_recovery_seconds)
                        st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-rest_elapsed_seconds / tau_recovery_seconds)
                        st["fatigue_A"] = max(0.0, st["fatigue_A"])
                        st["fatigue_B"] = max(0.0, st["fatigue_B"])
                        st["fatigue_C"] = max(0.0, st["fatigue_C"])
                    else:
                        # 線形回復（累積的に）
                        fatigue_recovery_rate = params["rest_fatigue_recovery_rate"]
                        fatigue_recovery_seconds = fatigue_recovery_rate * rest_elapsed_seconds / 3600.0
                        # 休憩開始時の疲労値を保持する必要があるため、初回のみ記録。
                        # st は dict なので hasattr ではなく in で調べる（ⓔ と同種のバグ、
                        # docs/06_ §10-3。hasattr(dict, ...) は常に False で、毎ステップ
                        # 上書きされていた）
                        if "_fatigue_at_rest_start" not in st:
                            st["_fatigue_at_rest_start"] = {
                                "A": st.get("fatigue_A", 0.0),
                                "B": st.get("fatigue_B", 0.0),
                                "C": st.get("fatigue_C", 0.0)
                            }
                        st["fatigue_A"] = max(0.0, st["_fatigue_at_rest_start"]["A"] - fatigue_recovery_seconds)
                        st["fatigue_B"] = max(0.0, st["_fatigue_at_rest_start"]["B"] - fatigue_recovery_seconds)
                        st["fatigue_C"] = max(0.0, st["_fatigue_at_rest_start"]["C"] - fatigue_recovery_seconds)

                # 後方互換性のため、high_intensity_time_secondsも更新（最大値を使用）
                if state.local_gly is not None:
                    st = state.local_gly
                    max_fatigue = max(st.get("fatigue_A", 0.0), st.get("fatigue_B", 0.0), st.get("fatigue_C", 0.0))
                    high_intensity_time_seconds = max_fatigue
                else:
                    # 局所グリコーゲン状態が未初期化のまま休憩に入った場合。
                    # その日の2点目が既に最高標高付近（＝代謝計算を1度も通らずに
                    # 山頂検出される）でないと起きない。実GPX 11本で該当0日。
                    #
                    # 以前はここに旧モデル用のフォールバックがあったが、
                    # dict に対する hasattr は常に False なので毎ステップ
                    # params を上書きし、対になる del 側（休憩終了時）は
                    # 到達不能だった。黙って誤った値で計算を続けるより、
                    # 到達したことが分かるほうがよい。
                    raise RuntimeError(
                        "休憩に入った時点で局所グリコーゲン状態が未初期化です。"
                    )
            else:
                # 休憩終了
                recovery_time_constant = params["rest_hr_recovery_time_constant"]
                current_HR = calculate_heart_rate_recovery_exponential(
                    hr_at_rest_start, params["HR_rest"], rest_time_seconds,
                    recovery_time_constant,
                    hr_target_offset=35.0
                )
                logger.info(f"Meal rest completed: HR={current_HR:.1f} bpm after {rest_time_seconds/60:.1f} min")

                # 疲労回復を最終的に適用
                if state.local_gly is not None:
                    st = state.local_gly
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    if fatigue_model_type == "exponential":
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-rest_time_seconds / tau_recovery_seconds)
                        st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-rest_time_seconds / tau_recovery_seconds)
                        st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-rest_time_seconds / tau_recovery_seconds)
                    else:
                        fatigue_recovery_rate = params["rest_fatigue_recovery_rate"]
                        fatigue_recovery_seconds = fatigue_recovery_rate * rest_time_seconds / 3600.0
                        if "_fatigue_at_rest_start" in st:
                            st["fatigue_A"] = max(0.0, st["_fatigue_at_rest_start"]["A"] - fatigue_recovery_seconds)
                            st["fatigue_B"] = max(0.0, st["_fatigue_at_rest_start"]["B"] - fatigue_recovery_seconds)
                            st["fatigue_C"] = max(0.0, st["_fatigue_at_rest_start"]["C"] - fatigue_recovery_seconds)
                        else:
                            st["fatigue_A"] = max(0.0, st.get("fatigue_A", 0.0) - fatigue_recovery_seconds)
                            st["fatigue_B"] = max(0.0, st.get("fatigue_B", 0.0) - fatigue_recovery_seconds)
                            st["fatigue_C"] = max(0.0, st.get("fatigue_C", 0.0) - fatigue_recovery_seconds)
                    # 一時変数を削除
                    if "_fatigue_at_rest_start" in st:
                        del st["_fatigue_at_rest_start"]

                if state.local_gly is not None:
                    st = state.local_gly
                    max_fatigue = max(st.get("fatigue_A", 0.0), st.get("fatigue_B", 0.0), st.get("fatigue_C", 0.0))
                    high_intensity_time_seconds = max_fatigue
                # local_gly が None のケースは上で RuntimeError にしているので、
                # ここに else は要らない。

            # 休憩中の筋効率計算（部位別疲労因子を使用）
            if state.local_gly is not None:
                st = state.local_gly
                fitness_level = params.get("fitness_level", 1.0)
                fatigue_base_rate = params.get("fatigue_base_rate", 0.02)
                min_eff = params.get("min_muscle_efficiency_multiplier", 0.65) - 0.1 * (1.0 - fitness_level)

                # 各部位の疲労因子を計算（休憩中は強度0）
                fatigue_hours_A = st.get("fatigue_A", 0.0) / 3600.0
                fatigue_hours_B = st.get("fatigue_B", 0.0) / 3600.0
                fatigue_hours_C = st.get("fatigue_C", 0.0) / 3600.0

                # 休憩中は強度0なので疲労率は0
                fatigue_factor_A = 1.0
                fatigue_factor_B = 1.0
                fatigue_factor_C = 1.0

                # 下限を適用
                fatigue_factor_A = max(min_eff, fatigue_factor_A)
                fatigue_factor_B = max(min_eff, fatigue_factor_B)
                fatigue_factor_C = max(min_eff, fatigue_factor_C)

                # 最も疲労が激しい部位の疲労因子を採用
                muscle_efficiency_fatigue = min(fatigue_factor_A, fatigue_factor_B, fatigue_factor_C)
            else:
                # フォールバック（局所モデルがない場合）
                muscle_efficiency_fatigue = 1.0

            # 残存率の分母は容量（役割3）。Phase 4b-0 で開始量から容量に変えた。
            glyciprop = glycogen_J / (glycogen_capacity_kcal(params) * 4184.0)
            glyciprop = max(0.0, min(1.0, glyciprop))
            k = params.get("sigmoid_k", 8.0)
            x0 = params.get("sigmoid_x0", 0.3)
            sigmoid_factor = 1.0 / (1.0 + math.exp(-k * (x0 - glyciprop)))
            c_glycogen_eff = params.get("glycogen_depletion_muscle_eff_c", 0.3)
            muscle_efficiency_glycogen = max(0.75, 1.0 - c_glycogen_eff * sigmoid_factor)

            muscle_efficiency = muscle_efficiency_fatigue * muscle_efficiency_glycogen

            # 休憩中は筋効率を前の値を保持（短時間の休憩では筋効率は変化しない）
            # 疲労回復やグリコーゲン補給の影響は、実際の運動再開後に段階的に反映される
            if len(final_muscle_efficiency_data) > 0:
                final_muscle_efficiency = final_muscle_efficiency_data[-1]  # 前の値を保持
            else:
                # 初回の場合のみ計算
                eff_up_orig = params.get("efficiency_up", 0.25)
                eff_down_orig = params.get("efficiency_down", 0.25)
                eff_up = max(1e-6, eff_up_orig * muscle_efficiency)
                eff_down = max(1e-6, eff_down_orig * muscle_efficiency)
                final_muscle_efficiency = (eff_up + eff_down) / 2.0

            # 休憩中のデータ記録（各ステップで記録）
            # 休憩中は通常の運動計算をスキップするため、ここでデータを記録してcontinue
            hr_data.append(current_HR)
            elevation_data.append(elevation_m)
            time_data.append(total_time)
            glycogen_data.append(glycogen_J / 4184.0)
            fat_data.append(fat_J / 4184.0)
            # 休憩中は前の値を保持
            if len(muscle_efficiency_data) > 0:
                muscle_efficiency_data.append(muscle_efficiency_data[-1])
            else:
                muscle_efficiency_data.append(muscle_efficiency)
            final_muscle_efficiency_data.append(final_muscle_efficiency)  # 前の値を保持
            vo2_usage_ratio_data.append(params["vo2_usage_ratio"])
            intensity_data.append(0.0)
            high_intensity_time_data.append(high_intensity_time_seconds / 3600.0)
            frac_glyc_actual_data.append(0.0)
            sigmoid_factor_data.append(1.0)
            mechanical_power_data.append(0.0)
            # 休憩中は発汗がないが、累積発汗量は保持する
            sweat_data.append(total_sweat)
            dx_data.append(0.0)

            # CSV出力用の時系列データ（休憩中）
            mechanical_energy_data.append(0.0)
            hypoglycemic_data.append(state.hypoglycemic)
            metabolic_energy_data.append(0.0)
            sweat_incremental_data.append(0.0)  # 休憩中は発汗なし
            distance_cumulative_data.append(total_dist)
            if len(timestamp_data) > 0:
                timestamp_data.append(timestamp_data[-1])
            else:
                timestamp_data.append(None)
            # 局所グリコーゲン残量（休憩中は変化なし）
            if state.local_gly is not None:
                st = state.local_gly
                if len(local_gly_A_absolute_data) > 0:
                    local_gly_A_absolute_data.append(local_gly_A_absolute_data[-1])
                    local_gly_B_absolute_data.append(local_gly_B_absolute_data[-1])
                    local_gly_C_absolute_data.append(local_gly_C_absolute_data[-1])
                    local_gly_liver_absolute_data.append(local_gly_liver_absolute_data[-1])
                else:
                    local_gly_A_absolute_data.append(st["A_J"] / 4184.0)
                    local_gly_B_absolute_data.append(st["B_J"] / 4184.0)
                    local_gly_C_absolute_data.append(st["C_J"] / 4184.0)
                    local_gly_liver_absolute_data.append(st["Liver_J"] / 4184.0)
            else:
                local_gly_A_absolute_data.append(0.0)
                local_gly_B_absolute_data.append(0.0)
                local_gly_C_absolute_data.append(0.0)
                local_gly_liver_absolute_data.append(0.0)

            # 局所グリコーゲン残存率（休憩中は変化なし）
            if len(local_gly_A_ratio_data) > 0:
                local_gly_A_ratio_data.append(local_gly_A_ratio_data[-1])
                local_gly_B_ratio_data.append(local_gly_B_ratio_data[-1])
                local_gly_C_ratio_data.append(local_gly_C_ratio_data[-1])
                local_gly_min_ratio_data.append(local_gly_min_ratio_data[-1])
            else:
                local_gly_A_ratio_data.append(1.0)
                local_gly_B_ratio_data.append(1.0)
                local_gly_C_ratio_data.append(1.0)
                local_gly_min_ratio_data.append(1.0)

            # 休憩終了
            if rest_elapsed_seconds >= rest_time_seconds:
                # 遠心性損傷は休憩中も回復する（Phase 4b-1 の時定数）。休憩の合計時間で一度に
                if state.local_gly is not None:
                    st = state.local_gly
                    decay = math.exp(-rest_time_seconds / (params["ecc_recovery_time_constant_h"] * 3600.0))
                    st["ecc_A"] *= decay
                    st["ecc_B"] *= decay
                in_rest = False
                rest_start_time = None

            # 休憩中は通常の運動計算をスキップする。i を進めないので、
            # この点は休憩が終わってから改めて歩く。
            continue

        terrain_factor = estimate_terrain_factor(
            0.0, elevation_m,
            params["terrain_z0_m"], params["terrain_z1_m"], params["terrain_factor_max"])

        E_vertical_step = 0.2 * mass * g * abs(dz)  # 無効化（係数0）
        E_vertical = mass * g * dz + E_vertical_step
        E_horizontal = WALK_EFF * mass * g * params["friction_coefficient"] * dx

        E_vertical *= terrain_factor
        E_horizontal *= terrain_factor

        if dz < 0:
            E_pe_total = params["descent_fraction"] * mass * g * abs(dz)
            transfer_J = (1.0 - params["brake_factor"]) * E_pe_total
            transfer_used = min(transfer_J, E_horizontal)
            E_vertical = abs(E_pe_total - transfer_J)  # 下りの吸収エネルギーは常に正
            E_horizontal = WALK_EFF * mass * g * params["friction_coefficient"] * dx
            E_horizontal = max(0.0, E_horizontal - transfer_used)
            E_vertical *= terrain_factor
            E_horizontal *= terrain_factor

        elevation_diff = elevation_m - params["T_air_elevation"]
        absolute_humidity_ratio = math.exp(-elevation_diff / 2000.0)
        RH_seg = params["RH"] * absolute_humidity_ratio
        T_air_seg = params["T_air"] - params["lapse_rate"] * (elevation_m - params["T_air_elevation"])
        P_O2_seg = P_O2(T_air_seg, RH_seg, elevation_m)

        # 心拍と酸素摂取量の関係。安静点 (HR_rest, 安静時代謝) と最大点 (HR_max, VO2max)
        # を結ぶ直線で、O2_pulse_ml_per_beat はその傾き、VO2_offset_ml_per_min は切片。
        #   順方向 VO2 = O2_pulse * HR + VO2_offset
        #   逆方向 HR  = (VO2 - VO2_offset) / O2_pulse
        # 旧実装は原点を通る直線（VO2_offset = 0、傾きは最大時の1拍あたり）で、
        # 低心拍側で酸素摂取量を過大に出していた。心拍105での強度を、依頼者の平地
        # ウォーキングの実測 + ACSM 歩行式は31%、Fick の式から引いた曲線は34%と
        # 出すのに対し、旧実装は55%と出す（docs/06_ M-7b）。
        # 安静時代謝は高度で下がらないので P_O2_seg で補正しない。
        #
        # 高所での VO2max の低下（Phase 5-1、2026-09-22）。吸気酸素分圧 P_O2 の
        # 計算（標準大気・Tetens・体積分率 0.2095）はそのままで、そこから VO2max への
        # 伝達だけを po2_to_vo2max_ratio（0.60）で縮める。ヘモグロビンの解離曲線が
        # 上端で平らなので、動脈血酸素飽和度は吸気酸素分圧ほど下がらないため。
        # 以前は比例させており（伝達率 1.0 相当）、高所の VO2max を文献
        # （Wehrlin & Hallén 2006、-6.3%/1000m）の約2倍下げて心拍を押し上げていた。
        VO2_max_ml_per_min = VO2_L_per_min * max(
            0.0, 1.0 - params["po2_to_vo2max_ratio"] * (1.0 - P_O2_seg / P_O2_std)) * 1000
        VO2_rest_ml_per_min = PWR_rest_W * 60.0 / E_O2_J_per_L * 1000
        O2_pulse_ml_per_beat = (VO2_max_ml_per_min - VO2_rest_ml_per_min) / max(1e-6, params["HR_max"] - HR_rest)
        VO2_offset_ml_per_min = VO2_rest_ml_per_min - O2_pulse_ml_per_beat * HR_rest

        oxygen_demand_ml_per_min = params["vo2max_ml_kg_min"] * params["weight_kg"] * ratio_eff
        HR_demand = min(params["HR_max"], (oxygen_demand_ml_per_min - VO2_offset_ml_per_min) / O2_pulse_ml_per_beat)

        # 循環依存を解消：available_VO2の計算で、current_HRではなく目標心拍数（HR_demand）を使う
        # これにより、初期の低い心拍数による制限を回避し、実際の代謝需要に基づいたパワーを発揮できる
        HR_for_available_VO2 = max(current_HR, HR_demand)  # 現在の心拍数と目標心拍数の大きい方を使用
        available_VO2 = (HR_for_available_VO2 * O2_pulse_ml_per_beat + VO2_offset_ml_per_min) / 1000.0
        P_met_limit_W_env = available_VO2 * E_O2_J_per_L / 60.0

        # しゃりばて（Phase 4b-2、2026-09-22）。前ステップで肝が空かつ吸収中の糖もなければ、
        # 血糖の供給源が無い。出せる代謝パワーは脂肪の酸化速度の上限（0.5 g/分 ＝ 約 308 W）
        # ＋ 吸収中の糖 まで。食べて吸収が始まれば戻る（作者: 燃やすものを入れれば戻る）。
        if state.hypoglycemic:
            P_met_limit_W_env = min(P_met_limit_W_env, max_fat_power_W + state.absorbed_W_last)

        if dz > 0:
            current_muscle_efficiency = params["efficiency_up"]
        elif dz < 0:
            current_muscle_efficiency = params["efficiency_down"]
        else:
            current_muscle_efficiency = (params["efficiency_up"] + params["efficiency_down"]) / 2.0

        P_mech_available_W = (P_met_limit_W_env - PWR_rest_W) * current_muscle_efficiency

        if P_mech_available_W > 0:
            # 所要時間は単位距離あたりの代謝コスト C(i) から出す（M-7、2026-09-21）。
            #
            #   登り (i >= 0)  C(i) = g * [ c_con*i      + (c_con + c_ecc)*k ]
            #   下り (i <  0)  C(i) = g * [ c_desc*|i|   + (c_con + c_ecc)*k ]
            #   v = （運動に使える代謝パワー） / (C(i) * 質量)
            #
            # k は一歩あたり重心が上下する量を水平移動距離で割った比。
            # step_height_m / step_length_m がこれにあたる（実測 0.055〜0.100、docs/06_）。
            # 地形が荒いほど余計に上下するので terrain_factor を掛ける。
            #
            # 式は両枝とも同じ切片 (c_con + c_ecc)*k を持ち、実測の回帰でも
            # 登りと下りの切片はほぼ一致した（塔ノ岳 3.39 対 4.18）。
            k_bob = params["step_height_m"] / max(1e-6, params["step_length_m"]) * terrain_factor
            c_con_cost = params["c_con_cost"]
            c_ecc_cost = params["c_ecc_cost"]
            grade_cost = (c_con_cost * grade) if dz >= 0 else (params["c_desc_cost"] * abs(grade))
            C_cost = g * (grade_cost + (c_con_cost + c_ecc_cost) * k_bob)

            # 速度は「有酸素で出せる速度」と「歩行で出せる速度」の小さいほう。
            # 急な登りでは前者が、それ以外では後者が効く。実測11ルートでは
            # 切り替わりが勾配 0.10〜0.12 に来ており、ザック重量が倍近く違っても
            # 同じ勾配で切り替わる（docs/06_ M-7c）。
            # 歩きにくい地形では歩行の上限そのものが下がるので terrain_factor で割る。
            # コストに掛けるのとは別の経路（歩行が上限のときコストは速度を決めない）。
            # 下りだけは「下りの得意度」を掛ける（Phase 6-6、2026-09-23）。
            # v_flat_gait は作者の実測から出た値なので、下りが速い人には天井として
            # 効いてしまう（下りの速い友人の試用で、下山日が +40% ずれた）。
            # 既定 1.0 は作者の位置なので、既定では出力は1ビットも変わらない。
            gait_skill = params["descent_gait_factor"] if dz < 0 else 1.0
            v_gait = params["v_flat_gait"] * gait_skill / max(1e-6, terrain_factor)
            P_met_net_W = max(0.0, P_met_limit_W_env - PWR_rest_W)
            v_horizontal = P_met_net_W / max(1e-9, C_cost * mass)
            v_horizontal = min(v_horizontal, v_gait)

            # 急な下りは有酸素ではなく、一歩ごとに落下を止める脚の側が速度を決める
            # （Phase 3-2、2026-09-22。実測の心拍は急な下りで天井より低い）。
            # 脚が受け止められる負の機械パワーの最大を、VO2max で出せる正の機械パワー
            # （筋効率 1/c_con_cost）の ecc_power_ratio 倍とし、これにも vo2_usage_ratio
            # が「その時間だけ出し続けられる割合」として掛かる。
            #   v_z ≤ ratio × ecc_power_ratio × η × P_met,VO2max / (質量 × g × terrain_factor)
            # 荷重は質量で、地形は terrain_factor で、行程の長さは ratio で入るので、
            # 個人の入力は VO2max だけ。1.24 は依頼者の実測（急な下りの全ルートが
            # 275〜390 W、中央値 330 W）から（docs/06_ Phase 3-2）。
            if dz < 0:
                P_met_vo2max_W = params["vo2max_ml_kg_min"] * params["weight_kg"] / 1000.0 * E_O2_J_per_L / 60.0
                P_ecc_avail_W = params["vo2_usage_ratio"] * params["ecc_power_ratio"] * P_met_vo2max_W / c_con_cost
                # 損傷した大腿四頭筋は受け止められる負のパワーが小さい（Phase 4b-1、2026-09-22）。
                # 下った高さに比例して溜まる遠心性損傷の因子（M-10-1）を、そのまま脚の上限に掛ける。
                # 泊まりの2日目以降の下山（黒戸 D2・雲ノ平 D4/D5・火打 D2）が急な帯で速すぎ、
                # 1日目は合っていたことから（docs/06_ Phase 4b）。前ステップの値を使う。
                P_ecc_avail_W = P_ecc_avail_W * ecc_damage_factor
                v_desc = P_ecc_avail_W / (mass * g * max(1e-6, abs(grade)) * max(1e-6, terrain_factor))
                v_horizontal = min(v_horizontal, v_desc)

            v_horizontal = max(v_horizontal, params["v_min"])
            dt_seg = dx / max(1e-9, v_horizontal)

            # 実際に使う正味の代謝パワーは、その速度で歩くのに要る C(i)・質量・v
            # （Phase 3-1、2026-09-21）。有酸素が効く区間では天井に等しく、歩行上限で
            # 歩く区間（平地・緩い下り）では天井より小さい。心拍・燃料・発汗は
            # 以後すべてこの1つの値から出す。
            #
            # 以前は天井のパワー（下りはさらに 0.5 倍）を使っていた。
            # 下りでは、旧式のエネルギー項から出した心拍目標でパワーを出し直す
            # 再計算ブロックが dt_seg を上書きしており、急な下りで天井の 1.23 倍、
            # 緩い下りで心拍下限 105 相当のパワーが速度を決めていた（docs/06_ Phase 3）。
            # 燃料の経路（P_met_used = P_final_W / 筋効率）は機械相当で受けるので、
            # 筋効率を掛けて渡す。
            P_used_net_W = C_cost * mass * v_horizontal
            P_final_W = P_used_net_W * current_muscle_efficiency

            O2_target_ml_per_min = (P_final_W + PWR_rest_W) / E_O2_J_per_L * 1000 * 60 / max(1e-6, muscle_efficiency)
            HR_target_bpm = min(params["HR_max"], (O2_target_ml_per_min - VO2_offset_ml_per_min) / O2_pulse_ml_per_beat)
        else:
            # 出せる機械パワーがゼロ以下。最低歩行速度で進むしかない。
            #
            # 以前はここで dt_seg だけを決めており、直後で使う P_final_W が
            # 未定義のまま（前区間の値が残った状態で）参照されていた。
            # 実GPX 11本・約12,000区間で1度も到達しないことを確認済み
            # （最小でも 102.4 W の余裕がある）が、到達したときに前区間の値で
            # 計算を続けるのは危険なので、ここで値を確定させる。
            total_work_J = E_horizontal + (E_vertical if dz != 0 else 0.0)
            P_final_W = total_work_J / max(1e-6, dt_seg)
            P_used_net_W = P_final_W / max(1e-6, current_muscle_efficiency)
            dt_seg = dist3d / params["v_min"]

        # エネルギー代謝（局所モデル含む）
        #
        # 貯蔵から引く燃料は、疲労で低下したあとの筋効率で計算する。
        # 以前は疲労前の定数（efficiency_up / efficiency_down、既定0.25）で
        # 割っており、表示用kcal（:534 で final_muscle_efficiency を使う）とは
        # 別の値になっていた。多日縦走の後半では最大1.7倍ずれ、
        # 「疲労→効率低下→燃料消費増→さらに枯渇」の連鎖が切れていた。
        #
        # 筋効率倍率は代謝計算の出力なので同一ステップ内では確定しない。
        # :476 が既に前ステップの muscle_efficiency を使っているので、
        # それに揃えて1ステップ遅れで参照する（明示的時間積分の標準的な扱い）。
        P_met_used_current = P_final_W / max(1e-6, current_muscle_efficiency * muscle_efficiency)

        # デバッグ：勾配分類
        if grade >= 0.25:
            grade_stats["steep_up"] += dt_seg
        elif grade >= 0.10:
            grade_stats["up"] += dt_seg
        elif grade > -0.10:
            grade_stats["flat"] += dt_seg
        elif grade > -0.25:
            grade_stats["gentle_down"] += dt_seg
        else:
            grade_stats["steep_down"] += dt_seg

        # デバッグ：局所グリコーゲンの消費前の値を記録
        st_before = None
        if state.local_gly is not None:
            st_before = state.local_gly.copy()

        energy_result = calculate_energy_metabolism_physical(
            P_met_used_current, dt_seg, P_met_limit_W_env, params, state,
            glycogen_J, fat_J, high_intensity_time_seconds, dz
        )

        # デバッグ：実際の局所グリコーゲン消費量を記録
        drawn_pools = None
        if st_before is not None and state.local_gly is not None:
            st_after = state.local_gly
            # 各部位の実際の消費量（J単位）
            consumed_A = (st_before["A_J"] - st_after["A_J"]) / 4184.0  # kcal換算
            consumed_B = (st_before["B_J"] - st_after["B_J"]) / 4184.0
            consumed_C = (st_before["C_J"] - st_after["C_J"]) / 4184.0
            muscle_consumption_actual["A_total"] += max(0.0, consumed_A)
            muscle_consumption_actual["B_total"] += max(0.0, consumed_B)
            muscle_consumption_actual["C_total"] += max(0.0, consumed_C)
            # この区間で各プールから取り崩した量[J]。あとで吸収した糖を
            # 「需要の肩代わり」として同じ比率で戻すのに使う（Phase 6-4）。
            drawn_pools = dict(
                (key, max(0.0, st_before[key] - st_after[key]))
                for key in ("Liver_J", "A_J", "B_J", "C_J"))

        glycogen_J = energy_result["glycogen_J"]
        fat_J = energy_result["fat_J"]
        frac_glyc_actual = energy_result["frac_glyc_actual"]
        muscle_efficiency = energy_result["muscle_efficiency"]
        muscle_efficiency_fatigue_only = energy_result["muscle_efficiency_fatigue_only"]
        ecc_damage_factor = energy_result["local_damage_factor"]
        eff_up = energy_result["eff_up"]
        eff_down = energy_result["eff_down"]
        high_intensity_time_seconds = energy_result["high_intensity_time_seconds"]
        intensity = energy_result["intensity"]
        sigmoid_factor = energy_result["sigmoid_factor"]

        if dz > 0:
            final_muscle_efficiency = eff_up
        elif dz < 0:
            final_muscle_efficiency = eff_down
        else:
            final_muscle_efficiency = (eff_up + eff_down) / 2.0

        P_met_used = P_final_W / max(1e-6, final_muscle_efficiency)

        # 固定比率（vo2_usage_ratio）から計算した代謝パワー
        oxygen_demand_ml_per_min_eff = params["vo2max_ml_kg_min"] * params["weight_kg"] * ratio_eff
        P_met_fixed_ratio = oxygen_demand_ml_per_min_eff * E_O2_J_per_L / 1000.0 / 60.0  # 固定比率の代謝パワー [W]
        HR_demand_eff = min(params["HR_max"], (oxygen_demand_ml_per_min_eff - VO2_offset_ml_per_min) / O2_pulse_ml_per_beat)

        # 心拍目標は、実際に使う代謝パワーから出す。登り・下り・平地で同じ式
        # （Phase 3-1、2026-09-21）。以前は下りと平地だけ旧式のエネルギー項
        # （E_horizontal / E_vertical を dt_seg で割ったもの）から出し、下りには
        # 床 HR_min_downhill_bpm を当てていた。床は外す。実測（塔ノ岳の下り）では
        # 急な登りの直後に心拍が落ちきらないのは時定数（下り 90 秒）で表現できる
        # 量であり、床で持ち上げると緩い下りの速度まで床が決めてしまう。
        P_met_actual = P_met_used + PWR_rest_W
        O2_target_ml_per_min_eff = P_met_actual / E_O2_J_per_L * 1000 * 60
        HR_target_bpm_eff = min(params["HR_max"], (O2_target_ml_per_min_eff - VO2_offset_ml_per_min) / O2_pulse_ml_per_beat)
        HR_target_bpm_eff = min(HR_demand_eff, HR_target_bpm_eff)

        # 心拍の上昇速度の上限で dt_seg とパワーを出し直す再計算ブロックは外した
        # （Phase 3-1、2026-09-21）。速度は上の C(i) と歩行上限だけで決まる。
        # 心拍の上昇速度の上限は、下の心拍の更新にだけ残る。
        # 以前はここで下りの心拍目標（旧式のエネルギー項から）を HR_achievable で
        # 切った値からパワーを出し直し、急な下りで天井を超えるパワー（810 W）で
        # 速度を決めていた（docs/06_ Phase 3）。

        # 心拍数の更新（時定数を考慮）
        tau = 90.0 if dz < 0 else 20.0  # 下り90秒、登り20秒
        beta = min(dt_seg / tau, 1.0)
        # 登り時はbetaの最小値を設定して、心拍数の上昇を速くする
        if dz > 0:
            beta = max(beta, 0.4)  # 最小値0.4を保証
        hr_change = beta * (HR_target_bpm_eff - current_HR)
        # 心拍数の上昇速度の上限を適用
        max_hr_increase_per_sec = params.get("max_hr_increase_per_sec", 5.0)
        max_hr_change = max_hr_increase_per_sec * dt_seg  # [bpm]
        if hr_change > 0:  # 上昇時のみ上限を適用
            hr_change = min(hr_change, max_hr_change)
        current_HR += hr_change
        current_HR = max(current_HR, HR_rest)

        #available_VO2_eff = current_HR * O2_pulse_ml_per_beat / 1000.0
        available_VO2_eff = (max(current_HR, HR_target_bpm_eff) * O2_pulse_ml_per_beat + VO2_offset_ml_per_min) / 1000.0
        P_met_limit_W_env_eff = available_VO2_eff * E_O2_J_per_L / 60.0

        glycogen_data.append(glycogen_J / 4184.0)
        fat_data.append(fat_J / 4184.0)
        muscle_efficiency_data.append(muscle_efficiency)
        final_muscle_efficiency_data.append(final_muscle_efficiency)  # 実際の筋効率を記録
        vo2_usage_ratio_data.append(ratio_eff)   # その区間の天井の割合（W' が尽きると cp_ratio）
        intensity_data.append(intensity)
        high_intensity_time_data.append(high_intensity_time_seconds / 3600.0)
        frac_glyc_actual_data.append(frac_glyc_actual)
        sigmoid_factor_data.append(sigmoid_factor)

        # 局所グリコーゲン残存率の記録
        if state.local_gly is not None:
            st = state.local_gly
            # 各部位の残存率
            rA = st["A_J"] / max(1e-6, st["A_init"]) if st["A_init"] > 0 else 1.0
            rB = st["B_J"] / max(1e-6, st["B_init"]) if st["B_init"] > 0 else 1.0
            rC = st["C_J"] / max(1e-6, st["C_init"]) if st["C_init"] > 0 else 1.0
            local_gly_A_ratio_data.append(max(0.0, min(1.0, rA)))
            local_gly_B_ratio_data.append(max(0.0, min(1.0, rB)))
            local_gly_C_ratio_data.append(max(0.0, min(1.0, rC)))
            # 最も消費が激しい部位（最小残存率）
            local_gly_min_ratio_data.append(min(rA, rB, rC))
        else:
            local_gly_A_ratio_data.append(1.0)
            local_gly_B_ratio_data.append(1.0)
            local_gly_C_ratio_data.append(1.0)
            local_gly_min_ratio_data.append(1.0)

        v = dist3d / max(1e-6, dt_seg)

        h_c = h_c_of_v_elevation(v, elevation_m, T_air_seg)
        R_conv = 1.0 / h_c if h_c > 0 else 1e9
        R_total = params["R_cloth"] + R_conv
        U = 1.0 / R_total if R_total > 0 else 0.0
        Q_conv = U * A_body * max(0.0, (T_core - T_air_seg))

        P_mech_used = (E_horizontal + (E_vertical * (params["descent_fraction"] if dz < 0 else 1.0))) / max(1e-6, dt_seg)
        Q_excess_W = P_met_limit_W_env_eff - P_mech_used - Q_conv
        Q_excess_W = max(0.0, Q_excess_W)
        Q_gen_J = Q_excess_W * dt_seg

        if params["use_thermal_storage"]:
            avail_storage_J = C_body * max(0.0, params["T_core_limit"] - T_core)
        else:
            avail_storage_J = 0.0
        Q_store_J = min(Q_gen_J, avail_storage_J)
        Q_evap_J = max(0.0, Q_gen_J - Q_store_J)

        if Q_store_J > 0 and params["use_thermal_storage"]:
            T_core += Q_store_J / C_body
            T_core = min(T_core, params["T_core_limit"])

        sweat_kg = Q_evap_J / L_v_J_per_kg
        sweat_kg = max(0.0, sweat_kg)

        mechanical_power_data.append(P_mech_used)
        sweat_data.append(total_sweat + sweat_kg)
        dx_data.append(dx)

        # CSV出力用の時系列データ（通常ステップ）
        total_work_J = E_horizontal + E_vertical
        mechanical_energy_data.append(total_work_J)
        metabolic_energy_data.append(P_met_used * dt_seg)
        sweat_incremental_data.append(sweat_kg)  # 各ステップでの発汗量
        distance_cumulative_data.append(total_dist)
        if i < len(points):
            timestamp_data.append(points[i].timestamp)
        else:
            timestamp_data.append(None)
        # 局所グリコーゲン残量（絶対値）
        if state.local_gly is not None:
            st = state.local_gly
            local_gly_A_absolute_data.append(st["A_J"] / 4184.0)
            local_gly_B_absolute_data.append(st["B_J"] / 4184.0)
            local_gly_C_absolute_data.append(st["C_J"] / 4184.0)
            local_gly_liver_absolute_data.append(st["Liver_J"] / 4184.0)
        else:
            local_gly_A_absolute_data.append(0.0)
            local_gly_B_absolute_data.append(0.0)
            local_gly_C_absolute_data.append(0.0)
            local_gly_liver_absolute_data.append(0.0)

        # 行動食（Phase 4b-2: 摂取の carb_absorption_delay_min 後から、carb_absorption_g_per_h を
        # 上限に線形に吸収。以前は 1.5 時間後から残量比例の指数吸収だった）
        action_food_timer += dt_seg / 60.0
        if action_food_timer >= params["action_food_interval_minutes"]:
            # 栄養素に分ける（Phase 6-3、2026-09-23）。以前は全量を糖質として
            # carb_queue に入れており、ナッツ（脂質が主）まで糖になっていた。
            carb_kcal = (params["action_food_fruits_kcal"] * params["action_food_fruits_carb_fraction"]
                         + params["action_food_nuts_kcal"] * params["action_food_nuts_carb_fraction"])
            other_kcal = (params["action_food_fruits_kcal"] + params["action_food_nuts_kcal"]) - carb_kcal
            carb_queue.append([total_time + carb_delay_s, carb_kcal * 4184.0])
            fat_J += other_kcal * 4184.0   # 糖質以外は脂肪プールへ
            action_food_timer = 0.0

        # 糖新生（Phase 6-3、2026-09-23）。肝臓が乳酸・アミノ酸・グリセロールから
        # 糖を作る。長時間の行動では行動食に匹敵する量になる（0.4 g/分 ＝ 96 kcal/h）。
        # 材料は脂肪プールから引く（グリセロール経由の正味の糖供給として扱う）。
        if state.local_gly is not None and params["gluconeogenesis_g_per_min"] > 0.0:
            st_g = state.local_gly
            liver_cap_J = liver_capacity_g(params) * 4.0 * 4184.0
            gng_J = params["gluconeogenesis_g_per_min"] * 4.0 * 4184.0 / 60.0 * dt_seg
            gng_J = min(gng_J, max(0.0, liver_cap_J - st_g["Liver_J"]), max(0.0, fat_J))
            st_g["Liver_J"] += gng_J
            fat_J -= gng_J

        absorbed_J = 0.0
        room_J = carb_rate_W * dt_seg
        for item in carb_queue:
            if room_J <= 0.0:
                break
            if item[0] <= total_time and item[1] > 0.0:
                take = min(item[1], room_J)
                item[1] -= take
                room_J -= take
                absorbed_J += take
        carb_queue = [it for it in carb_queue if it[1] > 0.0]
        if absorbed_J > 0.0:
            # 吸収した糖は、まずこの区間の需要を肩代わりする（Phase 6-4、2026-09-23）。
            #
            # 以前は「吸収した糖はまず肝（血糖）の空きを全部埋めてから、余りが筋へ」
            # だった。この規則だと、肝から出る量（糖の消費の from_liver_frac）より
            # 吸収の上限（carb_absorption_g_per_h）のほうがはるかに大きいので、
            # 出た分がその都度埋め戻され、1回目のまとまった補給のあと肝が容量に
            # 張り付いたまま動かなくなっていた（作者が実機のグラフで発見）。
            #
            # 13C-MRS で運動中の肝グリコーゲンを直接測った研究では、糖を 102 g/h
            # 摂ってようやく「横ばい」（325→345 mmol/L、有意差なし。Gonzalez ら
            # 2015、doi:10.1152/ajpendo.00376.2015）、60 g ではプラセボと同じだけ
            # 減る（doi:10.1152/ajpendo.00139.2026）。レビューも「>1.5 g/分で
            # 枯渇を防げる」が上限で（Gonzalez ら 2016、doi:10.1152/ajpendo.00232.2016）、
            # 運動中に肝グリコーゲンが増えるという報告はない。既定の補給は
            # 約 29 g/h なので、増えて張り付くのはどの条件にも当てはまらない。
            #
            # そこで、この区間で取り崩した分を取り崩した比率のまま戻し、需要を
            # 超えた分だけを貯蔵（肝の空き→筋）に回す。肝と筋のどちらが先に
            # 節約されるかは文献でも一定しないので、比率は取り崩しと同じにして
            # 恣意的な優先順位を置かない（§7 に残す）。
            if state.local_gly is not None:
                st = state.local_gly
                total_drawn = sum(drawn_pools.values()) if drawn_pools else 0.0
                cover_J = min(absorbed_J, total_drawn)
                if cover_J > 0.0:
                    for key, drawn in drawn_pools.items():
                        st[key] += cover_J * drawn / total_drawn
                surplus_J = absorbed_J - cover_J
                if surplus_J > 0.0:
                    _localglyco_add_supplement(params, state, surplus_J)
                glycogen_J = st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]
            else:
                glycogen_J += absorbed_J
        state.absorbed_W_last = absorbed_J / max(1e-6, dt_seg)
        state.hypoglycemic = (state.local_gly is not None and state.local_gly["Liver_J"] <= 1.0 and absorbed_J <= 0.0)
        hypoglycemic_data.append(state.hypoglycemic)

        # 補給処理の後に局所グリコーゲン残存率を再記録（グラフ用）
        if state.local_gly is not None:
            st = state.local_gly
            rA = st["A_J"] / max(1e-6, st["A_init"]) if st["A_init"] > 0 else 1.0
            rB = st["B_J"] / max(1e-6, st["B_init"]) if st["B_init"] > 0 else 1.0
            rC = st["C_J"] / max(1e-6, st["C_init"]) if st["C_init"] > 0 else 1.0
            # 既に記録された最後の値を上書き（補給後の値に更新）
            if len(local_gly_A_ratio_data) > 0:
                local_gly_A_ratio_data[-1] = max(0.0, min(1.0, rA))
                local_gly_B_ratio_data[-1] = max(0.0, min(1.0, rB))
                local_gly_C_ratio_data[-1] = max(0.0, min(1.0, rC))
                local_gly_min_ratio_data[-1] = min(rA, rB, rC)

        hr_data.append(current_HR)
        elevation_data.append(elevation_m)
        time_data.append(total_time)

        total_dist += dist3d
        # W' の更新。使った強度 r（疲労・枯渇の倍率を含まない、意図した強度）が
        # CP を超えた分 × 時間だけ減る。CP 未満でも戻さない（日内の回復なし）。
        r_used = (P_used_net_W + PWR_rest_W) / max(1e-9, P_met_vo2max_day_W)
        if r_used > params["cp_ratio"]:
            w_prime_left_h = max(0.0, w_prime_left_h - (r_used - params["cp_ratio"]) * dt_seg / 3600.0)
        total_time += dt_seg
        meal_timer_s += dt_seg
        total_sweat += sweat_kg

        if dz > 0:
            total_up += dz
            up_time += dt_seg
            up_sweat += sweat_kg
        elif dz < 0:
            total_down += abs(dz)
            down_time += dt_seg
            down_sweat += sweat_kg

        i += 1

    # デバッグ出力
    logger.info(f"\n[デバッグ] ルート統計:")
    logger.info(f"  勾配分布（時間）: 急登={grade_stats['steep_up']/3600:.2f}h, 登り={grade_stats['up']/3600:.2f}h, 水平={grade_stats['flat']/3600:.2f}h, 緩下り={grade_stats['gentle_down']/3600:.2f}h, 急下り={grade_stats['steep_down']/3600:.2f}h")
    logger.info(f"  部位別累積消費（実際）: A={muscle_consumption_actual['A_total']:.1f}kcal, B={muscle_consumption_actual['B_total']:.1f}kcal, C={muscle_consumption_actual['C_total']:.1f}kcal")

    # 最終的な残存率を表示
    if state.local_gly is not None:
        st_final = state.local_gly
        A_init_kcal = st_final["A_init"] / 4184.0
        B_init_kcal = st_final["B_init"] / 4184.0
        C_init_kcal = st_final["C_init"] / 4184.0
        A_final_kcal = st_final["A_J"] / 4184.0
        B_final_kcal = st_final["B_J"] / 4184.0
        C_final_kcal = st_final["C_J"] / 4184.0
        rA_final = st_final["A_J"] / max(1e-6, st_final["A_init"]) if st_final["A_init"] > 0 else 1.0
        rB_final = st_final["B_J"] / max(1e-6, st_final["B_init"]) if st_final["B_init"] > 0 else 1.0
        rC_final = st_final["C_J"] / max(1e-6, st_final["C_init"]) if st_final["C_init"] > 0 else 1.0
        logger.info(f"  初期値: A={A_init_kcal:.1f}kcal, B={B_init_kcal:.1f}kcal, C={C_init_kcal:.1f}kcal")
        logger.info(f"  最終値: A={A_final_kcal:.1f}kcal, B={B_final_kcal:.1f}kcal, C={C_final_kcal:.1f}kcal")
        logger.info(f"  最終残存率: A={rA_final:.3f} ({A_final_kcal:.1f}/{A_init_kcal:.1f}), B={rB_final:.3f} ({B_final_kcal:.1f}/{B_init_kcal:.1f}), C={rC_final:.3f} ({C_final_kcal:.1f}/{C_init_kcal:.1f})")
        logger.info(f"  実際の消費量（初期-最終）: A={A_init_kcal-A_final_kcal:.1f}kcal, B={B_init_kcal-B_final_kcal:.1f}kcal, C={C_init_kcal-C_final_kcal:.1f}kcal")

    logger.info(f"  登り合計: {total_up:.1f}m, 下り合計: {total_down:.1f}m")

    state.fat_kcal_end = fat_J / 4184.0

    return DayResult(
        date=route_day.date,
        distance_km=round(total_dist / 1000.0, 3),
        up_m=round(total_up, 1),
        down_m=round(total_down, 1),
        duration_h=round(total_time / 3600.0, 3),
        sweat_kg=round(total_sweat, 3),
        up_time_h=round(up_time / 3600.0, 3),
        down_time_h=round(down_time / 3600.0, 3),
        up_sweat_kg=round(up_sweat, 3),
        down_sweat_kg=round(down_sweat, 3),
        T_core_final=round(T_core, 2),
        hr_data=hr_data,
        elevation_data=elevation_data,
        time_data=time_data,
        mechanical_power_data=mechanical_power_data,
        sweat_data=sweat_data,
        dx_data=dx_data,
        glycogen_data=glycogen_data,
        fat_data=fat_data,
        muscle_efficiency_data=muscle_efficiency_data,
        final_muscle_efficiency_data=final_muscle_efficiency_data,
        vo2_usage_ratio_data=vo2_usage_ratio_data,
        intensity_data=intensity_data,
        high_intensity_time_data=high_intensity_time_data,
        frac_glyc_actual_data=frac_glyc_actual_data,
        sigmoid_factor_data=sigmoid_factor_data,
        local_gly_A_ratio_data=local_gly_A_ratio_data,
        local_gly_B_ratio_data=local_gly_B_ratio_data,
        local_gly_C_ratio_data=local_gly_C_ratio_data,
        local_gly_min_ratio_data=local_gly_min_ratio_data,
        mechanical_energy_data=mechanical_energy_data,
        hypoglycemic_data=hypoglycemic_data,
        metabolic_energy_data=metabolic_energy_data,
        sweat_incremental_data=sweat_incremental_data,
        local_gly_A_absolute_data=local_gly_A_absolute_data,
        local_gly_B_absolute_data=local_gly_B_absolute_data,
        local_gly_C_absolute_data=local_gly_C_absolute_data,
        local_gly_liver_absolute_data=local_gly_liver_absolute_data,
        distance_cumulative_data=distance_cumulative_data,
        timestamp_data=timestamp_data,
    )

# Terrain factor estimation from GPX log removed - using pure physical model
