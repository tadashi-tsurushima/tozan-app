"""Environment and body-surface helpers."""

def P_O2(temp_C, RH, elevation_m):
    P_atm = 101325 * (1 - 2.25577e-5 * elevation_m) ** 5.25588
    P_H2O = RH * 6.1078 * 10 ** ((7.5 * temp_C) / (temp_C + 237.3)) * 100
    return 0.2095 * (P_atm - P_H2O)


def h_c_of_v_elevation(v, elevation_m, T_air):
    """Convective heat transfer coefficient considering elevation effects [W/m²·K]"""
    if v <= 0:
        return 5.0  # Natural convection (simplified)
    rho_air = 1.225 * (1 - 2.25577e-5 * elevation_m) ** 4.25588
    T_air_K = T_air + 273.15
    mu_air = 1.81e-5 * (T_air_K / 288.15) ** 0.7
    k_air = 0.026 * (T_air_K / 288.15) ** 0.9
    Pr = 0.71
    L_char = 0.3
    Re = rho_air * v * L_char / mu_air
    if Re < 0.1:
        Nu = 0.3
    else:
        Nu = 0.3 + 0.62 * Re**0.5 * Pr**(1/3) / (1 + (0.4/Pr)**(2/3))**(1/4) * (1 + (Re/282000)**(5/8))**(4/5)
    h_c = Nu * k_air / L_char
    # 弱い風・ゆっくり歩くときは、体の熱による自然対流を下回らない（Phase 7-5、2026-09-29）。
    # 強制対流の式だけでは 0.5 m/s で約 4 W/m²/K と、止まっているときの仮置き 5.0 より小さく
    # なっていた。5.0 は人体の自然対流の標準式 2.38 × ΔT^0.25（皮膚と気温の差 14℃ で約 4.6、
    # 教科書値・PubMed では未確認）とほぼ合う。
    return max(5.0, h_c)


def calculate_body_surface_area(weight_kg, height_cm):
    return 0.007184 * (weight_kg ** 0.425) * (height_cm ** 0.725)


def p_sat_kPa(temp_C):
    """飽和水蒸気圧 [kPa]（Tetens。P_O2 と同じ式）。"""
    return 0.61078 * 10 ** ((7.5 * temp_C) / (temp_C + 237.3))


def skin_temperature_C(T_air_C, params):
    """運動中の平均皮膚温 [℃]（Phase 7-3、2026-09-29）。

    皮膚温は気温とともに上がる: 気温 10℃ ごとに約 4℃（Kenefick ら 2010
    doi:10.1152/japplphysiol.00135.2010、10〜40℃・VO2peak 50%）。基準は気温 22.5℃ で
    32.5℃（Greenhaff & Clough 1989 doi:10.1007/BF00643508、1時間の運動の終わりの値）。
    どちらも自転車こぎ・薄着の実験で、服を着た登山では皮膚は文献より温かいはずだが、
    その補正は根拠がないので入れていない。上限は深部体温を超えないための仮置き。
    """
    T = params["T_skin_ref_C"] + params["T_skin_slope"] * (T_air_C - params["T_skin_ref_air_C"])
    return min(params["T_skin_max_C"], T)


def radiative_h(T_surface_C, T_air_C, params):
    """放射の熱伝達係数 [W/m²/K]（Phase 7-3、2026-09-29）。

    h_r = 4 ε σ (A_r/A_D) (T̄ + 273.15)³、T̄ は体表と周囲（気温で代用）の平均。
    ε = 0.95（皮膚・衣服）、A_r/A_D = 0.72（立位の有効放射面積の比）。どちらも
    教科書的な標準値（PubMed では未確認）。気温 25℃ 付近で約 4 W/m²/K で、
    ゆっくり歩くときの対流（約 3 W/m²/K）と同じ大きさ。日射（短波）は入っていない。
    """
    sigma = 5.67e-8
    T_mean_K = 0.5 * (T_surface_C + T_air_C) + 273.15
    return 4.0 * params["emissivity"] * sigma * params["radiating_area_ratio"] * T_mean_K ** 3


def open_sky_fraction(elevation_m, z_line_m, band_m, canopy_fraction):
    """その標高で空が開けている度合い（Phase 7-5、2026-09-29）。森林限界 z_line_m の
    前後 band_m で canopy_fraction（樹林の中）から 1（森林限界の上）へ直線で移す。
    GPX に樹林かどうかの情報が無いので標高だけで決める（作者の判断：ルートごとの設定は
    できない）。丹沢の稜線のように低くても開けた道は表せない。"""
    x = (elevation_m - (z_line_m - band_m)) / max(1e-6, 2.0 * band_m)
    x = min(1.0, max(0.0, x))
    return canopy_fraction + (1.0 - canopy_fraction) * x


def wind_at_body_ms(elevation_m, params):
    """体の周りの外気の流れ [m/s]（Phase 7-5、2026-09-29）。無風の日はまれなので、
    常に ambient_air_ms の流れがあるとする（作者の案「0.5〜1 m くらいの風がある前提を
    デフォルトに」）。ERA5 の 10m 風速を樹林や高さで換算する案は、仮置きが多いので採らない。"""
    return params["ambient_air_ms"]


def solar_gain_W(elevation_m, h_c, h_r, A_body, params):
    """体に入る日射 [W]（Phase 7-5、2026-09-29）。

    吸収率 × 日射を受ける面積の割合 × 体表面積 × 日射（水平面、ERA5）× 空の開け方
    × R_外 / (R_内 + R_外)。最後の係数は、服の表面で吸収した熱が皮膚側と外気側に
    抵抗の比で分かれるぶん（Nielsen 1990 doi:10.1007/BF00705036：日の当たる服の表面が
    熱くなり乾いた放熱が増える）。吸収率 0.7・面積の割合 0.3 は人体熱モデルの標準値で
    PubMed では未確認（仮定）。
    """
    sw = params["solar_W_m2"]
    if sw <= 0.0:
        return 0.0
    f_sky = open_sky_fraction(elevation_m, params["tree_line_m"], params["tree_line_band_m"],
                              params["canopy_solar_fraction"])
    R_out = 1.0 / max(1e-6, h_c + h_r)
    to_body = R_out / (params["R_cloth"] + R_out)
    return (params["solar_absorptivity"] * params["solar_area_fraction"] * A_body * sw * f_sky * to_body)


def sweat_for_cooling(E_req_W, P_a_kPa, T_air_C, h_c, R_cloth, A_body, T_skin_C, lewis_K_per_kPa, eff_a):
    """体を E_req_W だけ冷やすのに要る汗（潜熱換算 [W]）と、実際に冷やせる量 [W] を返す
    （Phase 7-2、2026-09-29）。

    皮膚 ─[R_内 = R_cloth]─ 濡れた生地（表面は飽和）─[R_外 = 1/h_c]─ 外気
    ① 皮膚での蒸発。上限 Em = ルイス比 / (R_内 + R_外) × (Psat(皮膚温) − 外気の水蒸気圧) × A。
       濡れ率 w = 皮膚での蒸発 / Em、蒸発効率 η = 1 − eff_a × w²（Candas ら 1979
       doi:10.1152/jappl.1979.46.3.522：w とともに 1.0 → 0.74、全身が濡れて 0.67）
    ② 皮膚で蒸発しきれない汗（1 − η）は生地に移り、生地で蒸発する。体を冷やすのは
       その熱のうち f = R_外 / (R_内 + R_外) だけで、残りは外気から来る（Havenith ら 2013
       doi:10.1152/japplphysiol.01271.2012：外側で蒸発するほど有効な潜熱が下がる）
    ③ 生地の蒸発の上限 = ルイス比 / R_外 × (Psat(生地の温度) − 外気の水蒸気圧) × A。
       生地の温度は皮膚温と気温を抵抗の比で内分した値（蒸発による冷却は無視）
    冷やしきれないとき（① ② が上限）は、両方が上限に達する汗の量で止め、不足を返す。
    """
    if E_req_W <= 0.0:
        return 0.0, 0.0
    R_out = 1.0 / max(1e-6, h_c)
    R_in = R_cloth
    f = R_out / (R_in + R_out)
    Em = lewis_K_per_kPa / (R_in + R_out) * max(0.0, p_sat_kPa(T_skin_C) - P_a_kPa) * A_body
    T_cl = T_air_C + (T_skin_C - T_air_C) * f
    E_fab_max = lewis_K_per_kPa / R_out * max(0.0, p_sat_kPa(T_cl) - P_a_kPa) * A_body

    def cooled(S):
        # 皮膚での蒸発 E は E = S (1 − a (E/Em)²) の正の解（w ≤ 1 で打ち切り）
        if Em <= 0.0:
            E = 0.0
        else:
            k = eff_a * S / (Em * Em)
            E = S if k <= 1e-12 else (-1.0 + (1.0 + 4.0 * k * S) ** 0.5) / (2.0 * k)
            E = min(E, Em)
        E_fab = min(S - E, E_fab_max)
        return E + f * E_fab

    # 両方が上限に達する汗の量（これ以上汗を出しても冷えない）
    S_top = max(Em / max(1e-6, 1.0 - eff_a), Em + E_fab_max, E_req_W)
    if cooled(S_top) < E_req_W:
        lo, hi, target = 0.0, S_top, cooled(S_top) * (1.0 - 1e-9)
    else:
        lo, hi, target = 0.0, S_top, E_req_W
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if cooled(mid) < target:
            lo = mid
        else:
            hi = mid
    return hi, min(E_req_W, cooled(hi))


def update_core_temperature(T_core, Q_net_W, H_prod_W, rest_W, dt_s, C_body, weight_kg,
                            T_floor, k_rise, use_storage):
    """深部体温を1ステップ進め、汗で逃がした熱 [J] を返す（Phase 7-1、2026-09-29）。

    正味の熱 Q_net_W（代謝 − 機械仕事 − 対流。切り捨てない）で体温が上下する。
    体温が「熱の産生で決まる目標値」を超えるぶんは汗で逃がし、体温は目標値に留まる。
    目標値 = T_floor + k_rise × (熱産生 − 安静時代謝) / 体重
    （熱産生を体重あたりで見ると直腸温の上昇がそろう。Jay ら 2011
    doi:10.1152/ajpregu.00257.2011、Cramer & Jay 2014 doi:10.1152/japplphysiol.01312.2013、
    Cramer & Jay 2015 doi:10.1152/japplphysiol.00281.2015）。
    目標値がすでに体温より低い（運動をやめた等）ときは、熱が増える分だけ汗にし、
    体温は対流で下がるのを待つ。下限 T_floor より下には下げない（皮膚血流を絞る調節）。
    use_storage が False なら従来どおり体温は動かさず、正の熱をすべて汗にする。
    """
    if not use_storage:
        return T_core, max(0.0, Q_net_W) * dt_s
    target = T_floor + k_rise * max(0.0, H_prod_W - rest_W) / weight_kg
    T_new = T_core + Q_net_W * dt_s / C_body
    cap = max(target, T_core)
    evap_J = 0.0
    if T_new > cap:
        evap_J = C_body * (T_new - cap)
        T_new = cap
    if T_new < T_floor:
        T_new = T_floor
    return T_new, evap_J
