"""Environment and body-surface helpers."""

def P_O2(temp_C, RH, elevation_m):
    P_atm = 101325 * (1 - 2.25577e-5 * elevation_m) ** 5.25588
    P_H2O = RH * 6.1078 * 10 ** ((7.5 * temp_C) / (temp_C + 237.3)) * 100
    return 0.2095 * (P_atm - P_H2O)


def h_c_of_v_elevation(v, elevation_m, T_air):
    """Convective heat transfer coefficient considering elevation effects [W/m²·K]"""
    if v <= 0:
        return 5.0  # Natural convection (simplified)
    rho_air = 1.225 * (1 - 2.25577e-5 * elevation_m) ** 4.25588
    T_air_K = T_air + 273.15
    mu_air = 1.81e-5 * (T_air_K / 288.15) ** 0.7
    k_air = 0.026 * (T_air_K / 288.15) ** 0.9
    Pr = 0.71
    L_char = 0.3
    Re = rho_air * v * L_char / mu_air
    if Re < 0.1:
        Nu = 0.3
    else:
        Nu = 0.3 + 0.62 * Re**0.5 * Pr**(1/3) / (1 + (0.4/Pr)**(2/3))**(1/4) * (1 + (Re/282000)**(5/8))**(4/5)
    h_c = Nu * k_air / L_char
    return h_c


def calculate_body_surface_area(weight_kg, height_cm):
    return 0.007184 * (weight_kg ** 0.425) * (height_cm ** 0.725)
