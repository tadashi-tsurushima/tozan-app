"""旧式のエネルギー項（M-6-3、2026-10-02 に simulate_day から分離）。

所要時間・心拍・燃料は Phase 3-1 以降 C(i)·質量·v の1つのパワーから出しており、
この項は使っていない。発汗の経路（熱から差し引く機械仕事）と、記録の
mechanical_energy、到達しない分岐（docs/06_ §5 ⓜ）だけが使う。
Phase 3-3b で作者の判断により、係数（descent_fraction、brake_factor、
friction_coefficient、WALK_EFF、E_vertical_step の 0.2）ごと残している。
式は simulate_day にあったものを文字単位でそのまま移した（出力不変）。
"""

from tozan.constants import WALK_EFF, g


def legacy_work_terms(dx, dz, mass, terrain_factor, params):
    """区間の鉛直と水平の仕事 [J]。(E_vertical, E_horizontal) を返す。"""
    E_vertical_step = 0.2 * mass * g * abs(dz)  # 発汗の経路用に残す（Phase 3-3b、作者の判断）
    E_vertical = mass * g * dz + E_vertical_step
    E_horizontal = WALK_EFF * mass * g * params["friction_coefficient"] * dx

    E_vertical *= terrain_factor
    E_horizontal *= terrain_factor

    if dz < 0:
        E_pe_total = params["descent_fraction"] * mass * g * abs(dz)
        transfer_J = (1.0 - params["brake_factor"]) * E_pe_total
        transfer_used = min(transfer_J, E_horizontal)
        E_vertical = abs(E_pe_total - transfer_J)  # 下りの吸収エネルギーは常に正
        E_horizontal = WALK_EFF * mass * g * params["friction_coefficient"] * dx
        E_horizontal = max(0.0, E_horizontal - transfer_used)
        E_vertical *= terrain_factor
        E_horizontal *= terrain_factor

    return E_vertical, E_horizontal


def legacy_mech_power(E_horizontal, E_vertical, dz, dt_seg, params):
    """発汗の経路で熱から差し引く機械パワー P_mech_used [W]。"""
    return (E_horizontal + (E_vertical * (params["descent_fraction"] if dz < 0 else 1.0))) / max(1e-6, dt_seg)
