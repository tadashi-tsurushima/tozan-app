"""速度の決定（M-6-6、2026-10-02 に simulate_day から分離）。

区間の速度は「有酸素で出せる速度」「歩行で出せる速度」「脚が落下を受け止められる
速度（下り）」の小さいほうで、手を使う区間ではさらに沿面速度の天井が掛かる。
所要時間 dt_seg と、心拍・燃料・発汗のもとになる正味の代謝パワー P_used_net_W を
ここで1つに決める（Phase 3-1）。式は simulate_day にあったものを文字単位で
そのまま移した（出力不変）。使われていなかった HR_target_bpm（docs/06_ §5 ⓛ）は
このとき削除した（作者承認 2026-10-02）。
"""

import math

from tozan.constants import E_O2_J_per_L, g


def segment_speed(dx, dz, grade, mass, terrain_factor, P_met_limit_W_env, PWR_rest_W,
                  ecc_damage_factor, hands, params):
    """区間の速度を決める。(current_muscle_efficiency, dt_seg, P_used_net_W, P_final_W) を返す。"""
    if dz > 0:
        current_muscle_efficiency = params["efficiency_up"]
    elif dz < 0:
        current_muscle_efficiency = params["efficiency_down"]
    else:
        current_muscle_efficiency = (params["efficiency_up"] + params["efficiency_down"]) / 2.0

    P_mech_available_W = (P_met_limit_W_env - PWR_rest_W) * current_muscle_efficiency

    # 所要時間は単位距離あたりの代謝コスト C(i) から出す（M-7、2026-09-21）。
    #
    #   登り (i >= 0)  C(i) = g * [ c_con*i      + (c_con + c_ecc)*k ]
    #   下り (i <  0)  C(i) = g * [ c_desc*|i|   + (c_con + c_ecc)*k ]
    #   v = （運動に使える代謝パワー） / (C(i) * 質量)
    #
    # k は一歩あたり重心が上下する量を水平移動距離で割った比。
    # step_height_m / step_length_m がこれにあたる（実測 0.055〜0.100、docs/06_）。
    # 地形が荒いほど余計に上下するので terrain_factor を掛ける。
    #
    # 式は両枝とも同じ切片 (c_con + c_ecc)*k を持ち、実測の回帰でも
    # 登りと下りの切片はほぼ一致した（塔ノ岳 3.39 対 4.18）。
    k_bob = params["step_height_m"] / max(1e-6, params["step_length_m"]) * terrain_factor
    c_con_cost = params["c_con_cost"]
    c_ecc_cost = params["c_ecc_cost"]
    # 急な下りの技術（descent_steep_factor）は傾きの項だけを割る（Phase 6-16）。
    # 急な階段をいなして重力を前への推進力に変える人は、下る高さに対して払う代謝が減る
    # （作者の説明）。上下動の項 (c_con + c_ecc)*k には掛けない。既定 1.0。
    grade_cost = (c_con_cost * grade) if dz >= 0 else (params["c_desc_cost"] * abs(grade) / params["descent_steep_factor"])
    C_cost = g * (grade_cost + (c_con_cost + c_ecc_cost) * k_bob)

    if P_mech_available_W > 0:
        # 速度は「有酸素で出せる速度」と「歩行で出せる速度」の小さいほう。
        # 急な登りでは前者が、それ以外では後者が効く。実測11ルートでは
        # 切り替わりが勾配 0.10〜0.12 に来ており、ザック重量が倍近く違っても
        # 同じ勾配で切り替わる（docs/06_ M-7c）。
        # 歩きにくい地形では歩行の上限そのものが下がるので terrain_factor で割る。
        # コストに掛けるのとは別の経路（歩行が上限のときコストは速度を決めない）。
        # 下りだけは「下りの得意度」を掛ける（Phase 6-6、2026-09-23）。
        # v_flat_gait は作者の実測から出た値なので、下りが速い人には天井として
        # 効いてしまう（下りの速い友人の試用で、下山日が +40% ずれた）。
        # 既定 1.0 は作者の位置なので、既定では出力は1ビットも変わらない。
        gait_skill = params["descent_gait_factor"] if dz < 0 else 1.0
        v_gait = params["v_flat_gait"] * gait_skill / max(1e-6, terrain_factor)
        P_met_net_W = max(0.0, P_met_limit_W_env - PWR_rest_W)
        v_horizontal = P_met_net_W / max(1e-9, C_cost * mass)
        v_horizontal = min(v_horizontal, v_gait)

        # 急な下りは有酸素ではなく、一歩ごとに落下を止める脚の側が速度を決める
        # （Phase 3-2、2026-09-22。実測の心拍は急な下りで天井より低い）。
        # 脚が受け止められる負の機械パワーの最大を、VO2max で出せる正の機械パワー
        # （筋効率 1/c_con_cost）の ecc_power_ratio 倍とし、これにも vo2_usage_ratio
        # が「その時間だけ出し続けられる割合」として掛かる。
        #   v_z ≤ ratio × ecc_power_ratio × η × P_met,VO2max / (質量 × g × terrain_factor)
        # 荷重は質量で、地形は terrain_factor で、行程の長さは ratio で入るので、
        # 個人の入力は VO2max だけ。1.24 は依頼者の実測（急な下りの全ルートが
        # 275〜390 W、中央値 330 W）から（docs/06_ Phase 3-2）。
        if dz < 0:
            P_met_vo2max_W = params["vo2max_ml_kg_min"] * params["weight_kg"] / 1000.0 * E_O2_J_per_L / 60.0
            P_ecc_avail_W = params["vo2_usage_ratio"] * params["ecc_power_ratio"] * P_met_vo2max_W / c_con_cost
            # 損傷した大腿四頭筋は受け止められる負のパワーが小さい（Phase 4b-1、2026-09-22）。
            # 下った高さに比例して溜まる遠心性損傷の因子（M-10-1）を、そのまま脚の上限に掛ける。
            # 泊まりの2日目以降の下山（黒戸 D2・雲ノ平 D4/D5・火打 D2）が急な帯で速すぎ、
            # 1日目は合っていたことから（docs/06_ Phase 4b）。前ステップの値を使う。
            P_ecc_avail_W = P_ecc_avail_W * ecc_damage_factor
            # 急な下りの技術（Phase 6-16）: いなすぶん脚で受け止める量が減り、上限が上がる。
            P_ecc_avail_W = P_ecc_avail_W * params["descent_steep_factor"]
            v_desc = P_ecc_avail_W / (mass * g * max(1e-6, abs(grade)) * max(1e-6, terrain_factor))
            v_horizontal = min(v_horizontal, v_desc)

        # 手を使わないと登れない／下れない区間では、有酸素でも歩行でも脚でもなく
        # 手足の置き場が速度を決める（Phase 6-15、2026-09-27）。鎖場・はしご・岩稜と、
        # 草木をつかまないと滑落する土の激登り（作者の指摘 ―― 分けるのは岩か土かでは
        # なく手を使うかどうか）。区間は GPX の記録の欠落から見つける
        # （`loaders/gpx.py` の `_mark_hands_segments`。山行アプリは水平速度でしか
        # 「動いている」を判定しないので、手を使っている間は自動一時停止で記録が切れる）。
        # 上限は斜面に沿った速度で置く ―― 実測282区間で鉛直速度は勾配帯ごとに
        # 0.011〜0.089 m/s と8倍ばらつくのに、沿面速度は 0.064〜0.139 m/s に収まる。
        # 水平成分に直すため √(1 + grade²) で割る。
        # 時刻は区間を見つけるためだけに使い、所要時間には使わない（CLAUDE.md §5）。
        # v_min（0.2 m/s、「止まっている」とみなす速度）より遅いのが実態なので、
        # 下限を掛けたあとに天井を適用する。
        v_horizontal = max(v_horizontal, params["v_min"])
        if hands:
            v_hands = params["v_hands_m_s"] / math.sqrt(1.0 + grade * grade)
            v_horizontal = min(v_horizontal, v_hands)
        dt_seg = dx / max(1e-9, v_horizontal)

        # 実際に使う正味の代謝パワーは、その速度で歩くのに要る C(i)・質量・v
        # （Phase 3-1、2026-09-21）。有酸素が効く区間では天井に等しく、歩行上限で
        # 歩く区間（平地・緩い下り）では天井より小さい。心拍・燃料・発汗は
        # 以後すべてこの1つの値から出す。
        #
        # 以前は天井のパワー（下りはさらに 0.5 倍）を使っていた。
        # 下りでは、旧式のエネルギー項から出した心拍目標でパワーを出し直す
        # 再計算ブロックが dt_seg を上書きしており、急な下りで天井の 1.23 倍、
        # 緩い下りで心拍下限 105 相当のパワーが速度を決めていた（docs/06_ Phase 3）。
        # 燃料の経路（P_met_used = P_final_W / 筋効率）は機械相当で受けるので、
        # 筋効率を掛けて渡す。
        P_used_net_W = C_cost * mass * v_horizontal
        P_final_W = P_used_net_W * current_muscle_efficiency
    else:
        # 出せる機械パワーがゼロ以下。最低歩行速度 v_min で進むしかない（実 GPX では到達しない。
        # 最小でも 102.4 W の余裕がある）。ほかの区間と同じく、時間は水平距離 ÷ 水平速度、
        # パワーは C(i)・質量・v の1つから出す（Phase 3-1）。手を使う区間の天井も同じく掛ける。
        # 以前は旧式のエネルギー項を前の区間の dt_seg で割っており、その日の最初の区間で
        # 入ると止まり、時間も斜面に沿った長さで割っていた（docs/06_ §5 ⓜ、2026-10-02 に修正）。
        v_horizontal = params["v_min"]
        if hands:
            v_hands = params["v_hands_m_s"] / math.sqrt(1.0 + grade * grade)
            v_horizontal = min(v_horizontal, v_hands)
        dt_seg = dx / max(1e-9, v_horizontal)
        P_used_net_W = C_cost * mass * v_horizontal
        P_final_W = P_used_net_W * current_muscle_efficiency

    return current_muscle_efficiency, dt_seg, P_used_net_W, P_final_W
