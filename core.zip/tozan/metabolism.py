"""Energy metabolism core."""

import math

from tozan.constants import E_O2_J_per_L
from tozan.local_glycogen import (
    _localglyco_init_if_needed,
    _localglyco_update_and_fatigue,
    _localglyco_update_and_fatigue_exponential,
)
from tozan.state import _glycogen_kcal_for_day, glycogen_capacity_kcal


def calculate_energy_metabolism_physical(P_met_used, dt, P_met_limit_W_env, params, state, glycogen_J, fat_J, high_intensity_time_seconds, dz=0):
    """
    物理的に妥当なエネルギー代謝モデル（低強度時の脂肪燃焼を考慮）
    + NEW (047): 局所筋群グリコーゲン消費・遠心性疲労を統合し、
                 筋効率 multiplier に local_factor を掛け合わせる。
    """
    # ---- Initialization for local pools (only once per simulate run) ----
    _localglyco_init_if_needed(params, state, glycogen_J)

    # エネルギー需要量
    E_req = P_met_used * dt  # J

    # 強度 = 代謝パワー ÷ VO2max での代謝パワー（VO2max 比）。
    # 以前は 0.5 の補正係数で「強度 1.0 = VO2max の 50%」という尺度だった（⑦）。
    # Phase 4b-3（2026-09-22）で素の VO2max 比にし、疲労の蓄積には部位の強度
    # （局所モデルで 募集率 ÷ 容量比 を掛けたもの）を使う。閾値は cp_ratio。
    P_met_VO2max = params["vo2max_ml_kg_min"] * params["weight_kg"] * E_O2_J_per_L / 1000.0 / 60.0
    intensity = 0.0
    if P_met_VO2max > 0:
        intensity = P_met_used / max(1e-6, P_met_VO2max)
    intensity = max(0.0, min(intensity, 3.0))

    # 1. 脂肪燃焼の最大値
    #
    # 以前は 1.2 g/分（全身の値）から W を出したうえで体重を掛けており、
    # 上限が 52,540 W ＝ VO2max パワーの53倍という事実上の無限になっていた。
    # そのためグリコーゲンが尽きても脂肪が無制限に肩代わりし、
    # 「脂肪は最大酸化速度が低いのでパワーの上限が下がる」という
    # ハンガーノックの機構が働いていなかった。
    #
    # 体格の違う相手にも配るので体重あたりで持つ。0.007 g/(kg・分) は
    # 71kg で 0.5 g/分。文献では FATMAX の速度は 0.3〜0.6 g/分
    # （Noakes et al. 2023 Front Physiol、Purdom et al. 2018 JISSN）。
    # 1.2 g/分は低糖質高脂肪食に適応したアスリートの値。
    max_fat_oxidation_rate_g_per_min_per_kg = 0.007
    max_fat_power_W = max_fat_oxidation_rate_g_per_min_per_kg * params["weight_kg"] * 37e3 / 60

    # 2. グリコーゲン燃焼の最大値。こちらも体重あたりに直す。
    # 0.035 g/(kg・分) は 71kg で 2.5 g/分（従来の全身の値と同じ）。
    max_glycogen_oxidation_rate_g_per_min_per_kg = 0.035
    max_glycogen_power_W = max_glycogen_oxidation_rate_g_per_min_per_kg * params["weight_kg"] * 17e3 / 60

    # 利用可能量
    available_glycogen_J = glycogen_J
    available_fat_J = fat_J

    # 時間あたり最大供給量
    max_gly_dt = min(max_glycogen_power_W * dt, available_glycogen_J)
    max_fat_dt = min(max_fat_power_W * dt, available_fat_J)

    # 燃料比率（連続変化）。文献値は %VO2max で定義されている。
    pct_vo2max = max(0.0, min(intensity, 1.5))

    # 文献（2026-09-21 調査、docs/06_ §M-11「燃料配分」）:
    #   クロスオーバー点（糖が50%を超える点）は 60〜65%VO2max
    #     Noakes et al. 2023 Front Physiol / Purdom et al. 2018 JISSN
    #   脂肪酸化が最小になるのは 85%VO2max 以上であって 70% ではない
    #   最大脂肪酸化（FATMAX）が起きるのは 45〜65%VO2max
    if pct_vo2max <= 0.30:
        fat_ratio = 0.70
    elif pct_vo2max >= 0.85:
        fat_ratio = 0.15
    elif pct_vo2max < 0.60:
        # 30-60%: 0.70 → 0.50 へ線形（60%がクロスオーバー点）
        fat_ratio = 0.70 - (pct_vo2max - 0.30) / (0.60 - 0.30) * (0.70 - 0.50)
    else:
        # 60-85%: 0.50 → 0.15 へ線形
        fat_ratio = 0.50 - (pct_vo2max - 0.60) / (0.85 - 0.60) * (0.50 - 0.15)

    E_from_fat_target = E_req * fat_ratio
    E_from_glyc_target = E_req * (1.0 - fat_ratio)

    E_from_fat = min(E_from_fat_target, max_fat_dt)
    E_from_glyc = min(E_from_glyc_target, max_gly_dt)

    total_available = E_from_fat + E_from_glyc
    if total_available < E_req:
        fat_deficit = E_req - total_available
        E_from_fat = min(E_from_fat + fat_deficit, max_fat_dt)
        remaining_deficit = E_req - (E_from_fat + E_from_glyc)
        E_from_glyc = min(E_from_glyc + remaining_deficit, max_gly_dt)

    energy_deficit = 0.0
    if E_from_glyc + E_from_fat < E_req:
        energy_deficit = E_req - (E_from_glyc + E_from_fat)

    # 6. ストア更新（ここでは total glycogen を一旦減らす前に local モデルへ委譲）
    #    Local model will compute true pool updates and return new total.

    # ===== 旧：全身平均のグリコーゲン閾値モデル =====
    # 残存率の分母は容量（役割3）。Phase 4b-0 で開始量から容量に変えた。
    # 30% の閾値は容量 180 mmol/kg に対する 54 mmol/kg にあたり、枯渇で出力が
    # 落ち始める絶対濃度の目安と合う。
    glyciprop = glycogen_J / max(1e-6, glycogen_capacity_kcal(params) * 4184.0)
    glyciprop = max(0.0, min(1.0, glyciprop))
    k = params.get("sigmoid_k", 8.0)
    x0 = params.get("sigmoid_x0", 0.3)
    sigmoid_factor = 1.0 / (1.0 + math.exp(-k * (x0 - glyciprop)))
    c_glycogen_eff = params.get("glycogen_depletion_muscle_eff_c", 0.3)
    muscle_efficiency_glycogen_sig = max(0.75, 1.0 - c_glycogen_eff * sigmoid_factor)

    # ===== NEW: 局所筋群グリコーゲン＆遠心性疲労＆部位別疲労 =====
    intensity_threshold = params["cp_ratio"]   # 持続できる強度を超えた分だけ疲労が溜まる（Phase 4b-3）
    fatigue_recovery_rate = params.get("fatigue_recovery_rate", 0.05)

    # モデルタイプに応じて適切な疲労モデルを選択
    fatigue_model_type = params.get("fatigue_model_type", "exponential")
    if fatigue_model_type == "exponential":
        local_factor, glycogen_J_updated, local_fatigue_factor, local_damage_factor = _localglyco_update_and_fatigue_exponential(
            params, state, E_req, E_from_glyc, dt, dz, intensity, intensity_threshold, fatigue_recovery_rate
        )
    else:
        local_factor, glycogen_J_updated, local_fatigue_factor, local_damage_factor = _localglyco_update_and_fatigue(
            params, state, E_req, E_from_glyc, dt, dz, intensity, intensity_threshold, fatigue_recovery_rate
        )

    # 部位別疲労因子を使用（最も疲労が激しい部位の疲労因子）
    muscle_efficiency_fatigue = local_fatigue_factor

    # 返却する glycogen_J は局所モデルで更新された合計
    glycogen_J = glycogen_J_updated

    # 統合：全身平均の閾値効果と局所疲労効果のうち、より厳しい方を採用
    muscle_efficiency_glycogen_local = max(params.get("local_factor_floor", 0.60), local_factor)
    glycogen_component = min(muscle_efficiency_glycogen_sig, muscle_efficiency_glycogen_local)

    # 総合 multiplier（鶴島さん仕様：fatigue_factor を筋効率に掛ける）
    muscle_efficiency_multiplier = muscle_efficiency_fatigue * glycogen_component

    # 疲労だけの経路（M-11-1、2026-09-21）
    #
    # 上の muscle_efficiency_multiplier は「疲労」と「燃料（グリコーゲン）」の
    # 混合物なので、所要時間に繋ぐと起きていないハンガーノックが歩く速さに効く。
    # 高強度の継続時間による疲労と、下りの遠心性損傷だけを掛けたものをここで
    # 別に作る。この時点ではまだどこからも使っていない（出力は変わらない）。
    muscle_efficiency_fatigue_only = muscle_efficiency_fatigue * local_damage_factor

    # 後方互換性のため、high_intensity_time_secondsを局所疲労の最大値に更新
    if state.local_gly is not None:
        st = state.local_gly
        high_intensity_time_seconds = max(st.get("fatigue_A", 0.0), st.get("fatigue_B", 0.0), st.get("fatigue_C", 0.0))

    # 機械→代謝効率へ適用
    eff_up_orig = params.get("efficiency_up", 0.25)
    eff_down_orig = params.get("efficiency_down", 0.25)
    eff_up = max(1e-6, eff_up_orig * muscle_efficiency_multiplier)
    eff_down = max(1e-6, eff_down_orig * muscle_efficiency_multiplier)

    # 実際の代謝パワー（供給制限を考慮、参考値）
    actual_metabolic_power = (E_from_glyc + E_from_fat) / max(1e-6, dt)

    frac_glyc_actual = (E_from_glyc / max(1e-12, E_req)) if E_req > 0 else 0.0

    return {
        "glycogen_J": glycogen_J,
        "fat_J": fat_J - E_from_fat,
        "frac_glyc_actual": frac_glyc_actual,
        "muscle_efficiency": muscle_efficiency_multiplier,
        "muscle_efficiency_fatigue_only": muscle_efficiency_fatigue_only,
        "local_damage_factor": local_damage_factor,
        "eff_up": eff_up,
        "eff_down": eff_down,
        "high_intensity_time_seconds": high_intensity_time_seconds,  # 後方互換性のため保持（実際の疲労は局所モデルで管理）
        "intensity": intensity,
        "sigmoid_factor": sigmoid_factor,
        "actual_metabolic_power": actual_metabolic_power,
        "energy_deficit": energy_deficit,
        "max_glycogen_power": max_glycogen_power_W,
        "max_fat_power": max_fat_power_W
    }
