"""Energy metabolism core."""

import math

from tozan.constants import E_O2_J_per_L
from tozan.local_glycogen import (
    _localglyco_init_if_needed,
    _localglyco_update_and_fatigue,
    _localglyco_update_and_fatigue_exponential,
)
from tozan.state import _glycogen_kcal_for_day


def calculate_energy_metabolism_physical(P_met_used, dt, P_met_limit_W_env, params, state, glycogen_J, fat_J, high_intensity_time_seconds, dz=0):
    """
    物理的に妥当なエネルギー代謝モデル（低強度時の脂肪燃焼を考慮）
    + NEW (047): 局所筋群グリコーゲン消費・遠心性疲労を統合し、
                 筋効率 multiplier に local_factor を掛け合わせる。
    """
    # ---- Initialization for local pools (only once per simulate run) ----
    _localglyco_init_if_needed(params, state, glycogen_J)

    # エネルギー需要量
    E_req = P_met_used * dt  # J

    # 強度の計算：VO2max Powerに対する割合
    # VO2maxから計算される最大代謝パワー
    P_met_VO2max = params["vo2max_ml_kg_min"] * params["weight_kg"] * E_O2_J_per_L / 1000.0 / 60.0
    # 補正係数を適用（0.5）
    intensity_correction_factor = 0.5
    P_met_VO2max_base = P_met_VO2max * intensity_correction_factor
    intensity = 0.0
    if P_met_VO2max_base > 0:
        intensity = P_met_used / max(1e-6, P_met_VO2max_base)
    intensity = max(0.0, min(intensity, 3.0))

    # 1. 脂肪燃焼の最大値
    max_fat_oxidation_rate_g_per_min = 1.2  # g/min
    max_fat_oxidation_rate_W_per_kg = max_fat_oxidation_rate_g_per_min * 37e3 / 60
    max_fat_power_W = max_fat_oxidation_rate_W_per_kg * params["weight_kg"]

    # 2. グリコーゲン燃焼の最大値
    max_glycogen_oxidation_rate_g_per_min = 2.5  # g/min
    max_glycogen_oxidation_rate_W_per_kg = max_glycogen_oxidation_rate_g_per_min * 17e3 / 60
    max_glycogen_power_W = max_glycogen_oxidation_rate_W_per_kg * params["weight_kg"]

    # 利用可能量
    available_glycogen_J = glycogen_J
    available_fat_J = fat_J

    # 時間あたり最大供給量
    max_gly_dt = min(max_glycogen_power_W * dt, available_glycogen_J)
    max_fat_dt = min(max_fat_power_W * dt, available_fat_J)

    # 燃料比率（連続変化）：学術的研究に基づく値
    # 30%VO2max以下: 69.4%の脂肪燃焼（研究報告値）
    # 30-50%: 線形減少（69.4% → 50%）
    # 50-70%: 線形減少（50% → 15%）（crossover point付近）
    # 70%以上: 15%の脂肪燃焼（炭水化物が優位）
    if intensity <= 0.3:
        fat_ratio = 0.694
    elif intensity >= 0.7:
        fat_ratio = 0.15
    elif intensity <= 0.5:
        # 30-50%: 線形減少（69.4% → 50%）
        fat_ratio = 0.694 - (intensity - 0.3) / (0.5 - 0.3) * (0.694 - 0.50)
    else:
        # 50-70%: 線形減少（50% → 15%）
        fat_ratio = 0.50 - (intensity - 0.5) / (0.7 - 0.5) * (0.50 - 0.15)

    E_from_fat_target = E_req * fat_ratio
    E_from_glyc_target = E_req * (1.0 - fat_ratio)

    E_from_fat = min(E_from_fat_target, max_fat_dt)
    E_from_glyc = min(E_from_glyc_target, max_gly_dt)

    total_available = E_from_fat + E_from_glyc
    if total_available < E_req:
        fat_deficit = E_req - total_available
        E_from_fat = min(E_from_fat + fat_deficit, max_fat_dt)
        remaining_deficit = E_req - (E_from_fat + E_from_glyc)
        E_from_glyc = min(E_from_glyc + remaining_deficit, max_gly_dt)

    energy_deficit = 0.0
    if E_from_glyc + E_from_fat < E_req:
        energy_deficit = E_req - (E_from_glyc + E_from_fat)

    # 6. ストア更新（ここでは total glycogen を一旦減らす前に local モデルへ委譲）
    #    Local model will compute true pool updates and return new total.

    # ===== 旧：全身平均のグリコーゲン閾値モデル =====
    # 役割3の分母は役割2（その日の開始量）を参照している。
    # 本来は最大貯蔵量（将来の glycogen_kcal_max。現状は params['glycogen_kcal_init'] が兼ねる）を
    # 参照すべきだが、現状維持のため day_init を使う。モデル改良で対応予定。
    glyciprop = glycogen_J / max(1e-6, _glycogen_kcal_for_day(params, state) * 4184.0)
    glyciprop = max(0.0, min(1.0, glyciprop))
    k = params.get("sigmoid_k", 8.0)
    x0 = params.get("sigmoid_x0", 0.3)
    sigmoid_factor = 1.0 / (1.0 + math.exp(-k * (x0 - glyciprop)))
    c_glycogen_eff = params.get("glycogen_depletion_muscle_eff_c", 0.3)
    muscle_efficiency_glycogen_sig = max(0.75, 1.0 - c_glycogen_eff * sigmoid_factor)

    # ===== NEW: 局所筋群グリコーゲン＆遠心性疲労＆部位別疲労 =====
    intensity_threshold = params.get("I_fatigue_threshold", 0.65)
    fatigue_recovery_rate = params.get("fatigue_recovery_rate", 0.05)

    # モデルタイプに応じて適切な疲労モデルを選択
    fatigue_model_type = params.get("fatigue_model_type", "exponential")
    if fatigue_model_type == "exponential":
        local_factor, glycogen_J_updated, local_fatigue_factor = _localglyco_update_and_fatigue_exponential(
            params, state, E_req, E_from_glyc, dt, dz, intensity, intensity_threshold, fatigue_recovery_rate
        )
    else:
        local_factor, glycogen_J_updated, local_fatigue_factor = _localglyco_update_and_fatigue(
            params, state, E_req, E_from_glyc, dt, dz, intensity, intensity_threshold, fatigue_recovery_rate
        )

    # 部位別疲労因子を使用（最も疲労が激しい部位の疲労因子）
    muscle_efficiency_fatigue = local_fatigue_factor

    # 返却する glycogen_J は局所モデルで更新された合計
    glycogen_J = glycogen_J_updated

    # 統合：全身平均の閾値効果と局所疲労効果のうち、より厳しい方を採用
    muscle_efficiency_glycogen_local = max(params.get("local_factor_floor", 0.60), local_factor)
    glycogen_component = min(muscle_efficiency_glycogen_sig, muscle_efficiency_glycogen_local)

    # 総合 multiplier（鶴島さん仕様：fatigue_factor を筋効率に掛ける）
    muscle_efficiency_multiplier = muscle_efficiency_fatigue * glycogen_component

    # 後方互換性のため、high_intensity_time_secondsを局所疲労の最大値に更新
    if state.local_gly is not None:
        st = state.local_gly
        high_intensity_time_seconds = max(st.get("fatigue_A", 0.0), st.get("fatigue_B", 0.0), st.get("fatigue_C", 0.0))

    # 機械→代謝効率へ適用
    eff_up_orig = params.get("efficiency_up", 0.25)
    eff_down_orig = params.get("efficiency_down", 0.25)
    eff_up = max(1e-6, eff_up_orig * muscle_efficiency_multiplier)
    eff_down = max(1e-6, eff_down_orig * muscle_efficiency_multiplier)

    # 実際の代謝パワー（供給制限を考慮、参考値）
    actual_metabolic_power = (E_from_glyc + E_from_fat) / max(1e-6, dt)

    frac_glyc_actual = (E_from_glyc / max(1e-12, E_req)) if E_req > 0 else 0.0

    return {
        "glycogen_J": glycogen_J,
        "fat_J": fat_J - E_from_fat,
        "frac_glyc_actual": frac_glyc_actual,
        "muscle_efficiency": muscle_efficiency_multiplier,
        "eff_up": eff_up,
        "eff_down": eff_down,
        "high_intensity_time_seconds": high_intensity_time_seconds,  # 後方互換性のため保持（実際の疲労は局所モデルで管理）
        "intensity": intensity,
        "sigmoid_factor": sigmoid_factor,
        "actual_metabolic_power": actual_metabolic_power,
        "energy_deficit": energy_deficit,
        "max_glycogen_power": max_glycogen_power_W,
        "max_fat_power": max_fat_power_W
    }
