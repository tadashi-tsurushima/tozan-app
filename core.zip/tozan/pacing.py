"""目標強度と W′（M-6-5、2026-10-02 に simulate_day から分離）。

持続できる強度 CP（cp_ratio）と、それを超えて出せる余力 W′（w_prime_h）
（Phase 4a-1）、登りの勾配による強度の変調 φ（Phase 6-7）。
式は simulate_day にあったものを文字単位でそのまま移した（出力不変）。
"""


def target_ratio(w_prime_left_h, grade, params):
    """この区間の天井の割合 ratio_eff（VO2max 比）を返す。"""
    # この区間の天井の割合。W' が残っていれば目標どおり、尽きたら CP
    # （目標が CP 以下ならそのまま）。有酸素の天井と心拍の上限に使う。
    # 下りの上限（ecc_power_ratio）には使わない ―― W' は代謝の余力で、
    # 脚が落下を止める側（機械的・神経筋）とは別の系（docs/06_ Phase 4a）。
    if w_prime_left_h > 1e-9 or params["vo2_usage_ratio"] <= params["cp_ratio"]:
        ratio_eff = params["vo2_usage_ratio"]
    else:
        ratio_eff = params["cp_ratio"]

    # 勾配に応じた強度の変調（Phase 6-7、2026-09-24）。
    #
    # 人は急登に入ると速度を落としきらずに心拍を上げて頑張り、緩い登りでは
    # 力を抜く。vo2_usage_ratio を一定の天井として使っていたため、緩い帯で
    # 速すぎ（塔ノ岳 -13.7%）急な帯で遅すぎた（+8.5%）。心拍の実測から戻した
    # 強度を登り平均で正規化すると、指定ペースが 0.55〜0.70 とばらばらの4本で
    # 同じ形が出る（docs/06_ Phase 6-7）。
    #
    # 下りには掛けない ―― 下りの速度は脚が落下を受け止める側（ecc_power_ratio）
    # が支配していて、そこでの強度は目標ではなく結果だから。
    if grade > 0.0:
        m_grade = 1.0 + params["intensity_grade_slope"] * (grade - params["intensity_grade_ref"])
        m_grade = min(params["intensity_grade_max"],
                      max(params["intensity_grade_min"], m_grade))
        ratio_eff = min(1.0, ratio_eff * m_grade)
    return ratio_eff


def update_w_prime(w_prime_left_h, P_used_net_W, PWR_rest_W, P_met_vo2max_day_W, dt_seg, params):
    """区間を歩いたあとの W′ の残り [h] を返す。"""
    # W' の更新。使った強度 r（疲労・枯渇の倍率を含まない、意図した強度）が
    # CP を超えた分 × 時間だけ減る。CP 未満でも戻さない（日内の回復なし）。
    r_used = (P_used_net_W + PWR_rest_W) / max(1e-9, P_met_vo2max_day_W)
    if r_used > params["cp_ratio"]:
        w_prime_left_h = max(0.0, w_prime_left_h - (r_used - params["cp_ratio"]) * dt_seg / 3600.0)
    return w_prime_left_h
