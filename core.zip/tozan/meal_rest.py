"""補給休憩（M-6-8、2026-10-02 に simulate_day から分離）。

歩行 meal_interval_minutes ごとに meal_rest_minutes 止まる休憩（Phase 4b-2）の中身。
休憩の開始と 10 秒ステップの時刻の進め方はループの制御なので simulate_day に残し、
ここには1ステップの中身を役割ごとに置く。呼ぶ順番（心拍 → 疲労 → 筋効率 → 熱 →
記録 → 遠心性損傷）は simulate_day 側で今のまま。
式は simulate_day にあったものを文字単位でそのまま移した（出力不変）。

ⓚ（2026-10-02）: 指数モデルの部位の疲労は、休憩中も歩行中（閾値未満）と同じ
時定数で、1 ステップ dt_s ぶんずつ戻す。以前は休憩開始からの経過時間の減衰を
10 秒ごとに掛けていたので回復が積み重なり、15 分の休憩で約 11 時間ぶん戻っていた
（蛭ヶ岳で大腿の疲労時間 1.94 → 0.91 h。時定数どおりなら −1.7%）。
速い成分と遅い成分の2つの時定数に分ける形は、率 fatigue_base_rate が未較正のため
Step 7 で心拍と一緒に決める（docs/06_ §5 ⓚ・§7、作者決定）。
"""

import math

from tozan.heart_rate import calculate_heart_rate_recovery_exponential
from tozan.state import glycogen_capacity_kcal


def rest_heart_rate(hr_at_rest_start, elapsed_s, params):
    """休憩開始から elapsed_s 秒の心拍を返す。"""
    recovery_time_constant = params["rest_hr_recovery_time_constant"]
    return calculate_heart_rate_recovery_exponential(
        hr_at_rest_start, params["HR_rest"], elapsed_s,
        recovery_time_constant,
        # 下がり先は休憩直前の心拍で決まる（Phase 7-7、2026-09-30）。以前は一律 HR_rest + 35。
        hr_target_offset=params["rest_hr_retained_fraction"] * max(0.0, hr_at_rest_start - params["HR_rest"])
    )


def recover_fatigue_during_rest(state, rest_elapsed_seconds, dt_s, params):
    """休憩中（終了前）の部位の疲労の回復。state.local_gly を書き換え、
    high_intensity_time_seconds を返す。局所の状態が未初期化なら RuntimeError。
    dt_s は休憩の1ステップ [s]（指数モデル）、rest_elapsed_seconds は休憩開始からの
    経過時間 [s]（線形モデル。開始時の値を基準に引く）。"""
    # 部位別疲労の回復（休憩中）
    if state.local_gly is not None:
        st = state.local_gly
        fatigue_model_type = params.get("fatigue_model_type", "exponential")
        if fatigue_model_type == "exponential":
            # 指数関数的回復。歩行中に閾値を下回ったときと同じ時定数で、1 ステップぶん（ⓚ）
            tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
            st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-dt_s / tau_recovery_seconds)
            st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-dt_s / tau_recovery_seconds)
            st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-dt_s / tau_recovery_seconds)
            st["fatigue_A"] = max(0.0, st["fatigue_A"])
            st["fatigue_B"] = max(0.0, st["fatigue_B"])
            st["fatigue_C"] = max(0.0, st["fatigue_C"])
        else:
            # 線形回復（累積的に）
            fatigue_recovery_rate = params["rest_fatigue_recovery_rate"]
            fatigue_recovery_seconds = fatigue_recovery_rate * rest_elapsed_seconds / 3600.0
            # 休憩開始時の疲労値を保持する必要があるため、初回のみ記録。
            # st は dict なので hasattr ではなく in で調べる（ⓔ と同種のバグ、
            # docs/06_ §10-3。hasattr(dict, ...) は常に False で、毎ステップ
            # 上書きされていた）
            if "_fatigue_at_rest_start" not in st:
                st["_fatigue_at_rest_start"] = {
                    "A": st.get("fatigue_A", 0.0),
                    "B": st.get("fatigue_B", 0.0),
                    "C": st.get("fatigue_C", 0.0)
                }
            st["fatigue_A"] = max(0.0, st["_fatigue_at_rest_start"]["A"] - fatigue_recovery_seconds)
            st["fatigue_B"] = max(0.0, st["_fatigue_at_rest_start"]["B"] - fatigue_recovery_seconds)
            st["fatigue_C"] = max(0.0, st["_fatigue_at_rest_start"]["C"] - fatigue_recovery_seconds)

    # 後方互換性のため、high_intensity_time_secondsも更新（最大値を使用）
    if state.local_gly is not None:
        st = state.local_gly
        max_fatigue = max(st.get("fatigue_A", 0.0), st.get("fatigue_B", 0.0), st.get("fatigue_C", 0.0))
        high_intensity_time_seconds = max_fatigue
    else:
        # 局所グリコーゲン状態が未初期化のまま休憩に入った場合。
        # その日の2点目が既に最高標高付近（＝代謝計算を1度も通らずに
        # 山頂検出される）でないと起きない。実GPX 11本で該当0日。
        #
        # 以前はここに旧モデル用のフォールバックがあったが、
        # dict に対する hasattr は常に False なので毎ステップ
        # params を上書きし、対になる del 側（休憩終了時）は
        # 到達不能だった。黙って誤った値で計算を続けるより、
        # 到達したことが分かるほうがよい。
        raise RuntimeError(
            "休憩に入った時点で局所グリコーゲン状態が未初期化です。"
        )
    return high_intensity_time_seconds


def recover_fatigue_at_rest_end(state, rest_time_seconds, dt_s, high_intensity_time_seconds, params):
    """休憩終了時の部位の疲労の回復。state.local_gly を書き換え、
    high_intensity_time_seconds を返す（局所の状態が無ければ受け取った値のまま）。
    指数モデルは最後の1ステップ dt_s ぶん、線形モデルは休憩全体 rest_time_seconds ぶん。"""
    # 疲労回復を最終的に適用
    if state.local_gly is not None:
        st = state.local_gly
        fatigue_model_type = params.get("fatigue_model_type", "exponential")
        if fatigue_model_type == "exponential":
            # 最後の1ステップぶん（ⓚ。以前は休憩全体の時間ぶんをもう一度掛けていた）
            tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
            st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-dt_s / tau_recovery_seconds)
            st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-dt_s / tau_recovery_seconds)
            st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-dt_s / tau_recovery_seconds)
        else:
            fatigue_recovery_rate = params["rest_fatigue_recovery_rate"]
            fatigue_recovery_seconds = fatigue_recovery_rate * rest_time_seconds / 3600.0
            if "_fatigue_at_rest_start" in st:
                st["fatigue_A"] = max(0.0, st["_fatigue_at_rest_start"]["A"] - fatigue_recovery_seconds)
                st["fatigue_B"] = max(0.0, st["_fatigue_at_rest_start"]["B"] - fatigue_recovery_seconds)
                st["fatigue_C"] = max(0.0, st["_fatigue_at_rest_start"]["C"] - fatigue_recovery_seconds)
            else:
                st["fatigue_A"] = max(0.0, st.get("fatigue_A", 0.0) - fatigue_recovery_seconds)
                st["fatigue_B"] = max(0.0, st.get("fatigue_B", 0.0) - fatigue_recovery_seconds)
                st["fatigue_C"] = max(0.0, st.get("fatigue_C", 0.0) - fatigue_recovery_seconds)
        # 一時変数を削除
        if "_fatigue_at_rest_start" in st:
            del st["_fatigue_at_rest_start"]

    if state.local_gly is not None:
        st = state.local_gly
        max_fatigue = max(st.get("fatigue_A", 0.0), st.get("fatigue_B", 0.0), st.get("fatigue_C", 0.0))
        high_intensity_time_seconds = max_fatigue
    # local_gly が None のケースは上で RuntimeError にしているので、
    # ここに else は要らない。
    return high_intensity_time_seconds


def rest_muscle_efficiency(state, glycogen_J, params):
    """休憩中の筋効率の倍率 muscle_efficiency を返す。"""
    # 休憩中の筋効率計算（部位別疲労因子を使用）
    if state.local_gly is not None:
        st = state.local_gly
        fitness_level = params.get("fitness_level", 1.0)
        fatigue_base_rate = params.get("fatigue_base_rate", 0.02)
        min_eff = params.get("min_muscle_efficiency_multiplier", 0.65) - 0.1 * (1.0 - fitness_level)

        # 各部位の疲労因子を計算（休憩中は強度0）
        fatigue_hours_A = st.get("fatigue_A", 0.0) / 3600.0
        fatigue_hours_B = st.get("fatigue_B", 0.0) / 3600.0
        fatigue_hours_C = st.get("fatigue_C", 0.0) / 3600.0

        # 休憩中は強度0なので疲労率は0
        fatigue_factor_A = 1.0
        fatigue_factor_B = 1.0
        fatigue_factor_C = 1.0

        # 下限を適用
        fatigue_factor_A = max(min_eff, fatigue_factor_A)
        fatigue_factor_B = max(min_eff, fatigue_factor_B)
        fatigue_factor_C = max(min_eff, fatigue_factor_C)

        # 最も疲労が激しい部位の疲労因子を採用
        muscle_efficiency_fatigue = min(fatigue_factor_A, fatigue_factor_B, fatigue_factor_C)
    else:
        # フォールバック（局所モデルがない場合）
        muscle_efficiency_fatigue = 1.0

    # 残存率の分母は容量（役割3）。Phase 4b-0 で開始量から容量に変えた。
    glyciprop = glycogen_J / (glycogen_capacity_kcal(params) * 4184.0)
    glyciprop = max(0.0, min(1.0, glyciprop))
    k = params.get("sigmoid_k", 8.0)
    x0 = params.get("sigmoid_x0", 0.3)
    sigmoid_factor = 1.0 / (1.0 + math.exp(-k * (x0 - glyciprop)))
    c_glycogen_eff = params.get("glycogen_depletion_muscle_eff_c", 0.3)
    muscle_efficiency_glycogen = max(0.75, 1.0 - c_glycogen_eff * sigmoid_factor)

    muscle_efficiency = muscle_efficiency_fatigue * muscle_efficiency_glycogen
    return muscle_efficiency


def rest_final_muscle_efficiency(last_value, muscle_efficiency, params):
    """休憩中に記録する実際の筋効率。last_value は直前に記録した値（無ければ None）。"""
    # 休憩中は筋効率を前の値を保持（短時間の休憩では筋効率は変化しない）
    # 疲労回復やグリコーゲン補給の影響は、実際の運動再開後に段階的に反映される
    if last_value is not None:
        final_muscle_efficiency = last_value  # 前の値を保持
    else:
        # 初回の場合のみ計算
        eff_up_orig = params.get("efficiency_up", 0.25)
        eff_down_orig = params.get("efficiency_down", 0.25)
        eff_up = max(1e-6, eff_up_orig * muscle_efficiency)
        eff_down = max(1e-6, eff_down_orig * muscle_efficiency)
        final_muscle_efficiency = (eff_up + eff_down) / 2.0
    return final_muscle_efficiency


def recover_ecc_at_rest_end(state, rest_time_seconds, params):
    """休憩終了時の遠心性損傷の回復。state.local_gly を書き換える。"""
    # 遠心性損傷は休憩中も回復する（Phase 4b-1 の時定数）。休憩の合計時間で一度に
    if state.local_gly is not None:
        st = state.local_gly
        decay = math.exp(-rest_time_seconds / (params["ecc_recovery_time_constant_h"] * 3600.0))
        st["ecc_A"] *= decay
        st["ecc_B"] *= decay
