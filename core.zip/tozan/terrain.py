"""Terrain classification and elevation factor."""

# -------------------- Terrain Factor Estimation --------------------

def estimate_terrain_factor(slope_deg, elevation_m,
                            z0_m=1800.0, z1_m=3200.0, factor_max=2.0):
    """標高を代理指標にした地形の粗さ。z0_m 以下で 1.0、z1_m 以上で factor_max、
    その間は線形。3つの値は contract/params.json（terrain_z0_m / terrain_z1_m /
    terrain_factor_max）から渡す。z1_m は 2800 → 3200 に緩めた（Phase T-1、2026-09-22。
    高所ルートの 2300m 以上で登り・平坦・下りの三方向ともモデルが遅かったため）。
    """
    if elevation_m <= z0_m:
        elevation_factor = 1.0
    elif elevation_m >= z1_m:
        elevation_factor = factor_max
    else:
        elevation_factor = 1.0 + (elevation_m - z0_m) / (z1_m - z0_m) * (factor_max - 1.0)
    return elevation_factor
