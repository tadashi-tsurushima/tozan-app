"""Terrain classification and elevation factor."""

import math


def classify_terrain(slope_deg, elevation_m):
    if elevation_m > 2800 and slope_deg > 30:
        return "rocky"
    elif slope_deg > 25:
        return "scree"
    elif slope_deg > 15:
        return "mud"
    elif slope_deg < 10:
        return "trail"
    else:
        return "unknown"


def assign_terrain_types(route):
    points = route.points
    for i, p in enumerate(points):
        if i == 0:
            p.terrain_type = "trail"
            continue
        dx = p.dist_m
        dz = p.ele_diff
        ele = p.ele
        slope_deg = math.degrees(math.atan2(abs(dz), dx)) if dx > 0 else 0.0
        p.terrain_type = classify_terrain(slope_deg, ele)
    return route

# -------------------- Terrain Factor Estimation --------------------

def estimate_terrain_factor(slope_deg, elevation_m, terrain_type):
    if elevation_m <= 1800:
        elevation_factor = 1.0
    elif elevation_m >= 2800:
        elevation_factor = 2.0
    else:
        elevation_factor = 1.0 + (elevation_m - 1800) / (2800 - 1800) * (2.0 - 1.0)
    return elevation_factor
