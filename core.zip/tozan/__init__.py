"""Public calculation API."""

from tozan.api import default_params, simulate, validate_params
from tozan.constants import E_O2_J_per_L, J_PER_KCAL, L_v_J_per_kg, WALK_EFF, g
from tozan.day import simulate_day
from tozan.metabolism import calculate_energy_metabolism_physical
from tozan.multi_day import simulate_multi_day
from tozan.params import DEFAULT_PARAMS
from tozan.result import DayResult, SimResult
from tozan.route import Route, RoutePoint
from tozan.state import SimState

params = DEFAULT_PARAMS

__all__ = [
    "DEFAULT_PARAMS",
    "params",
    "SimState",
    "Route",
    "RoutePoint",
    "DayResult",
    "SimResult",
    "simulate",
    "default_params",
    "validate_params",
    "simulate_day",
    "simulate_multi_day",
    "calculate_energy_metabolism_physical",
    "g",
    "E_O2_J_per_L",
    "L_v_J_per_kg",
    "WALK_EFF",
    "J_PER_KCAL",
]
