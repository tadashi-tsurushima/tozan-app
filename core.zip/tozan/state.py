"""Simulation state separated from params."""

from dataclasses import dataclass


@dataclass
class SimState:
    local_gly: dict | None = None        # 旧 params["__local_gly_state"]
    last_grade: float = 0.0              # 旧 params["__last_grade"]
    glycogen_kcal_day_init: float | None = None  # 役割2: その日の開始グリコーゲン量
    initial_fatigue_hours: float | None = None
    initial_local_fatigue: dict | None = None


def _glycogen_kcal_for_day(params, state):
    """その日の開始グリコーゲン量 [kcal]。

    役割2（state.glycogen_kcal_day_init）が設定されていればそれを使う。
    未設定なら役割1（params['glycogen_kcal_init']、行程開始時の蓄積量）を使う。
    現状は glycogen_kcal_max が未実装で、params['glycogen_kcal_init'] がその役割を兼ねる。
    """
    if state.glycogen_kcal_day_init is not None:
        return state.glycogen_kcal_day_init
    return params.get("glycogen_kcal_init", 1800.0)
