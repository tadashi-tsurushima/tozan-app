"""Simulation state separated from params."""

from dataclasses import dataclass


@dataclass
class SimState:
    local_gly: dict | None = None        # 旧 params["__local_gly_state"]
    last_grade: float = 0.0              # 旧 params["__last_grade"]
    glycogen_kcal_day_init: float | None = None  # 役割2: その日の開始グリコーゲン量
    hypoglycemic: bool = False           # 前ステップで肝が空かつ吸収なし（しゃりばて。Phase 4b-2）
    absorbed_W_last: float = 0.0         # 前ステップの吸収速度 [W]（しゃりばて中の天井に足す）
    initial_local_fatigue: dict | None = None
    current_weight_kg: float | None = None   # その日の朝の体重 [kg]（Phase 6-3）
    fat_kcal_end: float | None = None        # その日の終わりの脂肪 [kcal]（Phase 6-3）
    fat_kcal_start: float | None = None      # その日の朝の脂肪 [kcal]（Phase 6-3）


def _muscle_mass_kg(params):
    """骨格筋量 [kg] = 体重 × (1 − 体脂肪率) × 除脂肪量に占める骨格筋の割合。"""
    return params["weight_kg"] * (1.0 - params["f_fat"]) * params["muscle_frac_of_lean"]


def fat_kcal(params):
    """体脂肪として蓄えているエネルギー [kcal]。

    体重 × 体脂肪率 × fat_kcal_per_kg。7700 kcal/kg は体脂肪組織 1 kg あたりの
    標準値（Wishnofsky 1958。純粋な脂質は 9 kcal/g だが、体脂肪組織は水分等を
    含むため）。必須脂肪（実際には使えない分）は引いていないが、1日の脂肪消費は
    700〜1440 kcal で枯渇しないため実害はない。以前は fat_kcal_init = 80000 kcal
    固定で、体脂肪率を入力させながら脂肪の量には使っていなかった（Phase 6-2、
    2026-09-23）。
    """
    return params["weight_kg"] * params["f_fat"] * params["fat_kcal_per_kg"]


GLUCOSYL_G_PER_MMOL = 0.16214   # グリコーゲンの繰り返し単位 C6H10O5 = 162.14 g/mol


def liver_capacity_g(params):
    """満タンの肝グリコーゲン量 [g]。

    肝の容積 × 満タンの濃度。容積は体表面積から Urata ら 1995 の標準肝容積の式で
    出す（LV[mL] = 706.2 × BSA + 2.4）。体表面積は発汗の計算で既に使っている
    Du Bois 式（environment.calculate_body_surface_area）。

    既定の体格（71 kg・176 cm、BSA 1.867 m^2）で肝 1321 mL × 400 mmol/L となり
    85.7 g。以前は体格によらず 100 g 固定で、小柄な人ほど肝の蓄えを過大に
    見積もり、しゃりばてが遅く出ていた（Phase 6-5、2026-09-23）。
    """
    from tozan.environment import calculate_body_surface_area
    bsa_m2 = calculate_body_surface_area(params["weight_kg"], params["height_cm"])
    volume_ml = params["liver_volume_bsa_slope_ml"] * bsa_m2 + params["liver_volume_bsa_intercept_ml"]
    return max(0.0, volume_ml) / 1000.0 * params["liver_glycogen_mmol_per_l"] * GLUCOSYL_G_PER_MMOL


def glycogen_capacity_kcal(params):
    """グリコーゲン容量 [kcal]（役割3: 正規化の分母、翌朝の上限）。

    (筋量 × 筋 1 kg あたりの容量 + 肝) × 4 kcal/g。容量はカーボローディング後の
    最大値（Bussau ら 2002 の 180 mmol/kg 湿重量 ＝ 29 g/kg）。Phase 4b-0、2026-09-22。
    以前は params['glycogen_kcal_init']（1800 kcal 固定）が入力・状態・分母の3役を
    兼ねていた（構想書 §2-3）。
    """
    return (_muscle_mass_kg(params) * params["glycogen_g_per_kg_muscle_max"]
            + liver_capacity_g(params)) * 4.0


def glycogen_initial_kcal(params):
    """初日の出発時のグリコーゲン量 [kcal]（役割1: 入力）。

    筋は容量 × 充填率（通常食 0.53、軽いローディング約 0.8、本格 1.0）、
    肝は容量 × liver_fill_ratio_init（一晩の絶食＋普通の朝食で 0.5。Phase 4b-2）。
    """
    return (_muscle_mass_kg(params) * params["glycogen_g_per_kg_muscle_max"]
            * params["glycogen_fill_ratio_init"]
            + liver_capacity_g(params) * params["liver_fill_ratio_init"]) * 4.0


def _glycogen_kcal_for_day(params, state):
    """その日の開始グリコーゲン量 [kcal]（役割2: 状態）。

    2日目以降は state.glycogen_kcal_day_init（multi_day が翌朝の値を置く）。
    初日は glycogen_initial_kcal(params)。
    """
    if state.glycogen_kcal_day_init is not None:
        return state.glycogen_kcal_day_init
    return glycogen_initial_kcal(params)
