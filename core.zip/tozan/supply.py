"""補給（M-6-4、2026-10-02 に simulate_day から分離）。

まとまった補給・行動食・糖新生・糖の吸収。吸収の待ち行列 carb_queue は
[吸収が始まる時刻 [s], 残り [J]] の並び（Phase 4b-2）で、関数の中では
書き換えずに複製して返す。肝と筋の量（state.local_gly）は代謝計算と同じく
直接書き換える。式は simulate_day にあったものを文字単位でそのまま移した（出力不変）。
いつ休憩に入るか（in_rest など休憩の状態）は simulate_day 側に残してある。
"""

from tozan.local_glycogen import _localglyco_add_supplement
from tozan.state import liver_capacity_g


def eat_meal(carb_queue, fat_J, total_time, carb_delay_s, params):
    """まとまった補給。糖質は吸収の待ち行列へ、残りは脂肪へ。(carb_queue, fat_J) を返す。"""
    carb_queue = [list(it) for it in carb_queue]
    meal_carb_kcal = params["meal_kcal"] * params["meal_carb_fraction"]
    carb_queue.append([total_time + carb_delay_s, meal_carb_kcal * 4184.0])
    fat_J += (params["meal_kcal"] - meal_carb_kcal) * 4184.0   # 糖質以外は脂肪プールへ
    return carb_queue, fat_J


def action_food_step(action_food_timer, carb_queue, fat_J, total_time, dt_seg, carb_delay_s, params):
    """行動食のタイマーと摂取。(action_food_timer, carb_queue, fat_J) を返す。"""
    carb_queue = [list(it) for it in carb_queue]
    # 行動食（Phase 4b-2: 摂取の carb_absorption_delay_min 後から、carb_absorption_g_per_h を
    # 上限に線形に吸収。以前は 1.5 時間後から残量比例の指数吸収だった）
    action_food_timer += dt_seg / 60.0
    if action_food_timer >= params["action_food_interval_minutes"]:
        # 栄養素に分ける（Phase 6-3、2026-09-23）。以前は全量を糖質として
        # carb_queue に入れており、ナッツ（脂質が主）まで糖になっていた。
        carb_kcal = (params["action_food_fruits_kcal"] * params["action_food_fruits_carb_fraction"]
                     + params["action_food_nuts_kcal"] * params["action_food_nuts_carb_fraction"])
        other_kcal = (params["action_food_fruits_kcal"] + params["action_food_nuts_kcal"]) - carb_kcal
        carb_queue.append([total_time + carb_delay_s, carb_kcal * 4184.0])
        fat_J += other_kcal * 4184.0   # 糖質以外は脂肪プールへ
        action_food_timer = 0.0
    return action_food_timer, carb_queue, fat_J


def gluconeogenesis_step(state, fat_J, dt_seg, params):
    """糖新生。肝を state.local_gly の中で増やし、材料を引いた fat_J を返す。"""
    # 糖新生（Phase 6-3、2026-09-23）。肝臓が乳酸・アミノ酸・グリセロールから
    # 糖を作る。長時間の行動では行動食に匹敵する量になる（0.4 g/分 ＝ 96 kcal/h）。
    # 材料は脂肪プールから引く（グリセロール経由の正味の糖供給として扱う）。
    if state.local_gly is not None and params["gluconeogenesis_g_per_min"] > 0.0:
        st_g = state.local_gly
        liver_cap_J = liver_capacity_g(params) * 4.0 * 4184.0
        gng_J = params["gluconeogenesis_g_per_min"] * 4.0 * 4184.0 / 60.0 * dt_seg
        gng_J = min(gng_J, max(0.0, liver_cap_J - st_g["Liver_J"]), max(0.0, fat_J))
        st_g["Liver_J"] += gng_J
        fat_J -= gng_J
    return fat_J


def absorb_carbs(carb_queue, total_time, dt_seg, carb_rate_W, glycogen_J, drawn_pools, state, params):
    """糖の吸収と、需要の肩代わり・貯蔵への振り分け。state.absorbed_W_last と
    state.hypoglycemic（しゃりばて）も更新する。(carb_queue, glycogen_J) を返す。"""
    carb_queue = [list(it) for it in carb_queue]
    absorbed_J = 0.0
    room_J = carb_rate_W * dt_seg
    for item in carb_queue:
        if room_J <= 0.0:
            break
        if item[0] <= total_time and item[1] > 0.0:
            take = min(item[1], room_J)
            item[1] -= take
            room_J -= take
            absorbed_J += take
    carb_queue = [it for it in carb_queue if it[1] > 0.0]
    if absorbed_J > 0.0:
        # 吸収した糖は、まずこの区間の需要を肩代わりする（Phase 6-4、2026-09-23）。
        #
        # 以前は「吸収した糖はまず肝（血糖）の空きを全部埋めてから、余りが筋へ」
        # だった。この規則だと、肝から出る量（糖の消費の from_liver_frac）より
        # 吸収の上限（carb_absorption_g_per_h）のほうがはるかに大きいので、
        # 出た分がその都度埋め戻され、1回目のまとまった補給のあと肝が容量に
        # 張り付いたまま動かなくなっていた（作者が実機のグラフで発見）。
        #
        # 13C-MRS で運動中の肝グリコーゲンを直接測った研究では、糖を 102 g/h
        # 摂ってようやく「横ばい」（325→345 mmol/L、有意差なし。Gonzalez ら
        # 2015、doi:10.1152/ajpendo.00376.2015）、60 g ではプラセボと同じだけ
        # 減る（doi:10.1152/ajpendo.00139.2026）。レビューも「>1.5 g/分で
        # 枯渇を防げる」が上限で（Gonzalez ら 2016、doi:10.1152/ajpendo.00232.2016）、
        # 運動中に肝グリコーゲンが増えるという報告はない。既定の補給は
        # 約 29 g/h なので、増えて張り付くのはどの条件にも当てはまらない。
        #
        # そこで、この区間で取り崩した分を取り崩した比率のまま戻し、需要を
        # 超えた分だけを貯蔵（肝の空き→筋）に回す。肝と筋のどちらが先に
        # 節約されるかは文献でも一定しないので、比率は取り崩しと同じにして
        # 恣意的な優先順位を置かない（§7 に残す）。
        if state.local_gly is not None:
            st = state.local_gly
            total_drawn = sum(drawn_pools.values()) if drawn_pools else 0.0
            cover_J = min(absorbed_J, total_drawn)
            if cover_J > 0.0:
                for key, drawn in drawn_pools.items():
                    st[key] += cover_J * drawn / total_drawn
            surplus_J = absorbed_J - cover_J
            if surplus_J > 0.0:
                _localglyco_add_supplement(params, state, surplus_J)
            glycogen_J = st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]
        else:
            glycogen_J += absorbed_J
    state.absorbed_W_last = absorbed_J / max(1e-6, dt_seg)
    state.hypoglycemic = (state.local_gly is not None and state.local_gly["Liver_J"] <= 1.0 and absorbed_J <= 0.0)
    return carb_queue, glycogen_J
