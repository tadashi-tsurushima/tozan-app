"""simulate_day の時系列の記録（M-6-1、2026-10-02）。

以前は simulate_day の中に29本のリストが並び、休憩中と歩行中の3か所で
それぞれ追加していた。記録する値の式はそのまま移してある（出力不変）。
歩行中の記録は計算の途中の3か所に分かれており、その時点の値を残すので、
呼ぶ位置は simulate_day の側で変えない。
"""


class DayRecorder:
    def __init__(self, first_timestamp):
        # Record lists
        self.hr_data = []
        self.elevation_data = []
        self.time_data = []
        self.mechanical_power_data = []
        self.sweat_data = []
        self.dx_data = []

        self.glycogen_data = []
        self.fat_data = []
        self.muscle_efficiency_data = []
        self.final_muscle_efficiency_data = []  # 実際の筋効率（eff_up/eff_down）
        self.vo2_usage_ratio_data = []
        self.intensity_data = []
        self.high_intensity_time_data = []
        self.frac_glyc_actual_data = []
        self.sigmoid_factor_data = []

        # 局所グリコーゲン残量データ（グラフ用）
        self.local_gly_A_ratio_data = []
        self.local_gly_B_ratio_data = []
        self.local_gly_C_ratio_data = []
        self.local_gly_min_ratio_data = []  # 最も消費が激しい部位の残存率

        # CSV出力用の時系列データ
        self.mechanical_energy_data = []  # 必要な機械的エネルギー [J]
        self.hypoglycemic_data = []       # しゃりばて中か（肝が空かつ吸収なし。Phase 4b-2）
        self.metabolic_energy_data = []  # 代謝エネルギー [J]
        self.sweat_incremental_data = []  # 各ステップでの発汗量 [kg]
        self.local_gly_A_absolute_data = []  # 部位Aのグリコーゲン残量 [kcal]
        self.local_gly_B_absolute_data = []  # 部位Bのグリコーゲン残量 [kcal]
        self.local_gly_C_absolute_data = []  # 部位Cのグリコーゲン残量 [kcal]
        self.local_gly_liver_absolute_data = []  # 肝グリコーゲン残量 [kcal]（UI表示用、2026-09-22）
        self.distance_cumulative_data = []  # 累積距離 [m]
        self.timestamp_data = []  # GPXポイントのtimestamp
        # 地点ごとの表（計画モード、2026-10-02）のため。time_data は歩いた区間では
        # 始まり、休憩では 10 秒ステップの終わりの時刻なので、到着時刻を別に持つ。
        self.point_index_data = []  # 歩いた区間の終点の点の番号。休憩は -1
        self.time_end_data = []     # 記録の終わりの時刻 [s]

        # 最初のポイントのtimestampを記録
        self.timestamp_data.append(first_timestamp)

    def last_final_muscle_efficiency(self):
        """直前に記録した実際の筋効率。まだ無ければ None。"""
        if len(self.final_muscle_efficiency_data) > 0:
            return self.final_muscle_efficiency_data[-1]
        return None

    def record_rest(self, current_HR, elevation_m, total_time, glycogen_J, fat_J,
                    muscle_efficiency, final_muscle_efficiency, vo2_usage_ratio,
                    high_intensity_time_seconds, total_sweat, hypoglycemic,
                    sweat_rest_kg, total_dist, local_gly):
        """休憩中のデータ記録（各ステップで記録）"""
        self.hr_data.append(current_HR)
        self.elevation_data.append(elevation_m)
        self.time_data.append(total_time)
        self.glycogen_data.append(glycogen_J / 4184.0)
        self.fat_data.append(fat_J / 4184.0)
        # 休憩中は前の値を保持
        if len(self.muscle_efficiency_data) > 0:
            self.muscle_efficiency_data.append(self.muscle_efficiency_data[-1])
        else:
            self.muscle_efficiency_data.append(muscle_efficiency)
        self.final_muscle_efficiency_data.append(final_muscle_efficiency)  # 前の値を保持
        self.vo2_usage_ratio_data.append(vo2_usage_ratio)
        self.intensity_data.append(0.0)
        self.high_intensity_time_data.append(high_intensity_time_seconds / 3600.0)
        self.frac_glyc_actual_data.append(0.0)
        self.sigmoid_factor_data.append(1.0)
        self.mechanical_power_data.append(0.0)
        # 累積発汗量（休憩中の発汗は呼ぶ前に total_sweat に足してある。Phase 7-1）
        self.sweat_data.append(total_sweat)
        self.dx_data.append(0.0)

        # CSV出力用の時系列データ（休憩中）
        self.mechanical_energy_data.append(0.0)
        self.hypoglycemic_data.append(hypoglycemic)
        self.metabolic_energy_data.append(0.0)
        self.sweat_incremental_data.append(sweat_rest_kg)  # 休憩中の発汗（Phase 7-1）
        self.distance_cumulative_data.append(total_dist)
        if len(self.timestamp_data) > 0:
            self.timestamp_data.append(self.timestamp_data[-1])
        else:
            self.timestamp_data.append(None)
        # 局所グリコーゲン残量（休憩中は変化なし）
        if local_gly is not None:
            st = local_gly
            if len(self.local_gly_A_absolute_data) > 0:
                self.local_gly_A_absolute_data.append(self.local_gly_A_absolute_data[-1])
                self.local_gly_B_absolute_data.append(self.local_gly_B_absolute_data[-1])
                self.local_gly_C_absolute_data.append(self.local_gly_C_absolute_data[-1])
                self.local_gly_liver_absolute_data.append(self.local_gly_liver_absolute_data[-1])
            else:
                self.local_gly_A_absolute_data.append(st["A_J"] / 4184.0)
                self.local_gly_B_absolute_data.append(st["B_J"] / 4184.0)
                self.local_gly_C_absolute_data.append(st["C_J"] / 4184.0)
                self.local_gly_liver_absolute_data.append(st["Liver_J"] / 4184.0)
        else:
            self.local_gly_A_absolute_data.append(0.0)
            self.local_gly_B_absolute_data.append(0.0)
            self.local_gly_C_absolute_data.append(0.0)
            self.local_gly_liver_absolute_data.append(0.0)

        self.point_index_data.append(-1)
        self.time_end_data.append(total_time)

        # 局所グリコーゲン残存率（休憩中は変化なし）
        if len(self.local_gly_A_ratio_data) > 0:
            self.local_gly_A_ratio_data.append(self.local_gly_A_ratio_data[-1])
            self.local_gly_B_ratio_data.append(self.local_gly_B_ratio_data[-1])
            self.local_gly_C_ratio_data.append(self.local_gly_C_ratio_data[-1])
            self.local_gly_min_ratio_data.append(self.local_gly_min_ratio_data[-1])
        else:
            self.local_gly_A_ratio_data.append(1.0)
            self.local_gly_B_ratio_data.append(1.0)
            self.local_gly_C_ratio_data.append(1.0)
            self.local_gly_min_ratio_data.append(1.0)

    def record_walk_fuel(self, glycogen_J, fat_J, muscle_efficiency, final_muscle_efficiency,
                         ratio_eff, intensity, high_intensity_time_seconds, frac_glyc_actual,
                         sigmoid_factor, local_gly):
        """歩行中の記録（1）: 代謝の直後の燃料・筋効率・残存率"""
        self.glycogen_data.append(glycogen_J / 4184.0)
        self.fat_data.append(fat_J / 4184.0)
        self.muscle_efficiency_data.append(muscle_efficiency)
        self.final_muscle_efficiency_data.append(final_muscle_efficiency)  # 実際の筋効率を記録
        self.vo2_usage_ratio_data.append(ratio_eff)   # その区間の天井の割合（W' が尽きると cp_ratio）
        self.intensity_data.append(intensity)
        self.high_intensity_time_data.append(high_intensity_time_seconds / 3600.0)
        self.frac_glyc_actual_data.append(frac_glyc_actual)
        self.sigmoid_factor_data.append(sigmoid_factor)

        # 局所グリコーゲン残存率の記録
        if local_gly is not None:
            st = local_gly
            # 各部位の残存率
            rA = st["A_J"] / max(1e-6, st["A_init"]) if st["A_init"] > 0 else 1.0
            rB = st["B_J"] / max(1e-6, st["B_init"]) if st["B_init"] > 0 else 1.0
            rC = st["C_J"] / max(1e-6, st["C_init"]) if st["C_init"] > 0 else 1.0
            self.local_gly_A_ratio_data.append(max(0.0, min(1.0, rA)))
            self.local_gly_B_ratio_data.append(max(0.0, min(1.0, rB)))
            self.local_gly_C_ratio_data.append(max(0.0, min(1.0, rC)))
            # 最も消費が激しい部位（最小残存率）
            self.local_gly_min_ratio_data.append(min(rA, rB, rC))
        else:
            self.local_gly_A_ratio_data.append(1.0)
            self.local_gly_B_ratio_data.append(1.0)
            self.local_gly_C_ratio_data.append(1.0)
            self.local_gly_min_ratio_data.append(1.0)

    def record_walk_heat(self, P_mech_used, total_sweat, sweat_kg, dx, total_work_J,
                         P_met_used, dt_seg, total_dist, timestamp, local_gly):
        """歩行中の記録（2）: 熱収支の直後の機械パワー・汗・距離・時刻・残量"""
        self.mechanical_power_data.append(P_mech_used)
        self.sweat_data.append(total_sweat + sweat_kg)
        self.dx_data.append(dx)

        # CSV出力用の時系列データ（通常ステップ）
        self.mechanical_energy_data.append(total_work_J)
        self.metabolic_energy_data.append(P_met_used * dt_seg)
        self.sweat_incremental_data.append(sweat_kg)  # 各ステップでの発汗量
        self.distance_cumulative_data.append(total_dist)
        self.timestamp_data.append(timestamp)
        # 局所グリコーゲン残量（絶対値）
        if local_gly is not None:
            st = local_gly
            self.local_gly_A_absolute_data.append(st["A_J"] / 4184.0)
            self.local_gly_B_absolute_data.append(st["B_J"] / 4184.0)
            self.local_gly_C_absolute_data.append(st["C_J"] / 4184.0)
            self.local_gly_liver_absolute_data.append(st["Liver_J"] / 4184.0)
        else:
            self.local_gly_A_absolute_data.append(0.0)
            self.local_gly_B_absolute_data.append(0.0)
            self.local_gly_C_absolute_data.append(0.0)
            self.local_gly_liver_absolute_data.append(0.0)

    def record_hypoglycemic(self, hypoglycemic):
        self.hypoglycemic_data.append(hypoglycemic)

    def overwrite_last_ratios(self, local_gly):
        """補給処理の後に局所グリコーゲン残存率を再記録（グラフ用）"""
        if local_gly is not None:
            st = local_gly
            rA = st["A_J"] / max(1e-6, st["A_init"]) if st["A_init"] > 0 else 1.0
            rB = st["B_J"] / max(1e-6, st["B_init"]) if st["B_init"] > 0 else 1.0
            rC = st["C_J"] / max(1e-6, st["C_init"]) if st["C_init"] > 0 else 1.0
            # 既に記録された最後の値を上書き（補給後の値に更新）
            if len(self.local_gly_A_ratio_data) > 0:
                self.local_gly_A_ratio_data[-1] = max(0.0, min(1.0, rA))
                self.local_gly_B_ratio_data[-1] = max(0.0, min(1.0, rB))
                self.local_gly_C_ratio_data[-1] = max(0.0, min(1.0, rC))
                self.local_gly_min_ratio_data[-1] = min(rA, rB, rC)

    def record_walk_position(self, current_HR, elevation_m, total_time):
        """歩行中の記録（3）: 区間の最後の心拍・標高・時刻（total_time は加算前）"""
        self.hr_data.append(current_HR)
        self.elevation_data.append(elevation_m)
        self.time_data.append(total_time)

    def record_walk_end(self, point_index, total_time_after):
        """歩行中の記録（4）: 区間の終点の点の番号と到着時刻（total_time は加算後）"""
        self.point_index_data.append(point_index)
        self.time_end_data.append(total_time_after)

    def as_kwargs(self):
        """DayResult に渡す時系列"""
        return dict(
            hr_data=self.hr_data,
            elevation_data=self.elevation_data,
            time_data=self.time_data,
            mechanical_power_data=self.mechanical_power_data,
            sweat_data=self.sweat_data,
            dx_data=self.dx_data,
            glycogen_data=self.glycogen_data,
            fat_data=self.fat_data,
            muscle_efficiency_data=self.muscle_efficiency_data,
            final_muscle_efficiency_data=self.final_muscle_efficiency_data,
            vo2_usage_ratio_data=self.vo2_usage_ratio_data,
            intensity_data=self.intensity_data,
            high_intensity_time_data=self.high_intensity_time_data,
            frac_glyc_actual_data=self.frac_glyc_actual_data,
            sigmoid_factor_data=self.sigmoid_factor_data,
            local_gly_A_ratio_data=self.local_gly_A_ratio_data,
            local_gly_B_ratio_data=self.local_gly_B_ratio_data,
            local_gly_C_ratio_data=self.local_gly_C_ratio_data,
            local_gly_min_ratio_data=self.local_gly_min_ratio_data,
            mechanical_energy_data=self.mechanical_energy_data,
            hypoglycemic_data=self.hypoglycemic_data,
            metabolic_energy_data=self.metabolic_energy_data,
            sweat_incremental_data=self.sweat_incremental_data,
            local_gly_A_absolute_data=self.local_gly_A_absolute_data,
            local_gly_B_absolute_data=self.local_gly_B_absolute_data,
            local_gly_C_absolute_data=self.local_gly_C_absolute_data,
            local_gly_liver_absolute_data=self.local_gly_liver_absolute_data,
            distance_cumulative_data=self.distance_cumulative_data,
            timestamp_data=self.timestamp_data,
            point_index_data=self.point_index_data,
            time_end_data=self.time_end_data,
        )
