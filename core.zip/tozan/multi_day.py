"""Multi-day simulation."""

import logging
import math

from tozan.day import simulate_day
from tozan.local_glycogen import _localglyco_update_from_total
from tozan.result import SimResult
from tozan.route import split_by_date
from tozan.state import SimState

logger = logging.getLogger(__name__)


def simulate_multi_day(route, params):
    state = SimState()

    days = []
    for i, route_day in enumerate(split_by_date(route)):
        if i > 0 and len(days) > 0:
            previous = days[-1]
            if previous.glycogen_data and len(previous.glycogen_data) > 0:
                previous_final_glycogen = previous.glycogen_data[-1]
                recovery_glycogen = min(1800.0, previous_final_glycogen + 1000.0)
                state.glycogen_kcal_day_init = recovery_glycogen
                logger.info(f"Day {i+1}: Initial glycogen set to {recovery_glycogen:.1f} kcal (previous: {previous_final_glycogen:.1f} + 1000.0)")

                # 局所グリコーゲンを補給分を考慮してアップデート
                recovery_glycogen_J = recovery_glycogen * 4184.0
                _localglyco_update_from_total(params, state, recovery_glycogen_J)
                logger.info(f"Day {i+1}: Local glycogen pools updated to {recovery_glycogen:.1f} kcal total")

                if previous.high_intensity_time_data and len(previous.high_intensity_time_data) > 0:
                    previous_final_fatigue_hours = previous.high_intensity_time_data[-1]
                    recovery_rate_per_hour = 0.15
                    sleep_hours = 8.0
                    fatigue_carryover_hours = previous_final_fatigue_hours * math.exp(-recovery_rate_per_hour * sleep_hours)
                    state.initial_fatigue_hours = fatigue_carryover_hours
                    logger.info(f"Day {i+1}: Initial fatigue set to {fatigue_carryover_hours:.2f} h")

                # 局所疲労の回復（宿泊による回復）
                if state.local_gly is not None:
                    st = state.local_gly
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    recovery_rate_per_hour = 0.15
                    sleep_hours = 8.0

                    if fatigue_model_type == "exponential":
                        # 指数関数的回復（時定数18時間を使用）
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        sleep_time_seconds = sleep_hours * 3600.0
                        st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                        st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                        st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                    else:
                        # 線形回復
                        recovery_seconds = recovery_rate_per_hour * sleep_hours
                        st["fatigue_A"] = max(0.0, st.get("fatigue_A", 0.0) - recovery_seconds)
                        st["fatigue_B"] = max(0.0, st.get("fatigue_B", 0.0) - recovery_seconds)
                        st["fatigue_C"] = max(0.0, st.get("fatigue_C", 0.0) - recovery_seconds)

                    # 回復後の局所疲労を次の日の初期値として保存
                    state.initial_local_fatigue = {
                        "fatigue_A": st["fatigue_A"],
                        "fatigue_B": st["fatigue_B"],
                        "fatigue_C": st["fatigue_C"]
                    }
                    logger.info(f"Day {i+1}: Local fatigue after sleep recovery - A: {st['fatigue_A']/3600.0:.2f}h, B: {st['fatigue_B']/3600.0:.2f}h, C: {st['fatigue_C']/3600.0:.2f}h")

        days.append(simulate_day(route_day, params, state))

    return SimResult(days=days)
