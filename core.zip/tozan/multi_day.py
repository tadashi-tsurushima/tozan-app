"""Multi-day simulation."""

import logging
import math

from tozan.day import simulate_day
from tozan.constants import E_O2_J_per_L
from tozan.state import fat_kcal, glycogen_initial_kcal, glycogen_capacity_kcal
from tozan.local_glycogen import _localglyco_update_from_total
from tozan.result import SimResult
from tozan.route import split_by_date
from tozan.state import SimState

logger = logging.getLogger(__name__)


def simulate_multi_day(route, params):
    state = SimState()

    days = []
    split_days = split_by_date(route)
    for i, route_day in enumerate(split_days):
        if i > 0 and len(days) > 0:
            previous = days[-1]
            # 夜間の経過時間（前日の終わり → 翌日の出発）。Phase 4b-1 の遠心性損傷の
            # 回復でも使う。時刻が無ければ 12 時間とする。
            t_prev = split_days[i - 1].points[0].timestamp
            t_this = route_day.points[0].timestamp
            if t_prev is not None and t_this is not None:
                gap_h = max(0.0, (t_this - t_prev).total_seconds() / 3600.0 - previous.duration_h)
            else:
                gap_h = 12.0

            if previous.glycogen_data and len(previous.glycogen_data) > 0:
                previous_final_glycogen = previous.glycogen_data[-1]
                # 翌朝のグリコーゲン = 前日終値 + (摂取した糖質 − 夜間に使った糖)。
                # Phase 6-3a（2026-09-23）。以前は食事の全量がそのままグリコーゲンに
                # なっており（overnight_glycogen_kcal = 1000 をそのまま加算）、
                # (1) 脂質・タンパク質もグリコーゲンにしていた、(2) 夜間に消費する分を
                # 引いていなかった、の2つで雲ノ平5日ではグリコーゲンが増えて容量に
                # 張り付いていた（作者は同じ山行で約3kg痩せている）。
                rest_W = (params["rest_vo2_ml_per_kg_min"] * params["weight_kg"]
                          * E_O2_J_per_L / 1000.0 / 60.0)
                night_kcal = rest_W * gap_h * 3600.0 / 4184.0
                carb_in = params["overnight_food_kcal"] * params["overnight_carb_fraction"]
                carb_out = night_kcal * params["rest_carb_fraction"]
                recovery_glycogen = min(glycogen_capacity_kcal(params),
                                        max(0.0, previous_final_glycogen + carb_in - carb_out))

                # 脂肪の夜間の収支と、翌朝の体重（Phase 6-3、2026-09-23）。
                # 摂取のうち糖質以外は脂肪に入り、夜間の消費のうち糖以外は脂肪から出る。
                # 体重は「燃やした脂肪」＋「失ったグリコーゲン（随伴水込み。
                # グリコーゲン 1 g は水 3 g を伴うので 1 kcal ≒ 体重 1 g）」で減る。
                fat_in = params["overnight_food_kcal"] - carb_in
                fat_out = night_kcal - carb_out
                fat_end = state.fat_kcal_end if state.fat_kcal_end is not None else fat_kcal(params)
                state.fat_kcal_start = max(0.0, fat_end + fat_in - fat_out)
                # 体重は「初日の朝からの累積の減少」で出す（差分の積み上げにすると
                # 符号を間違えやすい）。グリコーゲン 1 g は水 3 g を伴うので
                # 1 kcal ≒ 体重 1 g。発汗は補給前提で体重に反映しない（作者の判断）。
                fat0 = fat_kcal(params)
                gly0 = glycogen_initial_kcal(params)
                state.current_weight_kg = max(
                    0.5 * params["weight_kg"],
                    params["weight_kg"]
                    - (fat0 - state.fat_kcal_start) / params["fat_kcal_per_kg"]
                    - (gly0 - recovery_glycogen) / 1000.0)
                logger.info(f"Day {i+1}: weight -> {state.current_weight_kg:.2f} kg "
                            f"(fat {fat_end:.0f} -> {state.fat_kcal_start:.0f} kcal)")

                state.glycogen_kcal_day_init = recovery_glycogen
                logger.info(f"Day {i+1}: Initial glycogen set to {recovery_glycogen:.1f} kcal "
                            f"(previous: {previous_final_glycogen:.1f} + 摂取糖質 {carb_in:.0f} "
                            f"- 夜間の糖 {carb_out:.0f}、{gap_h:.1f}h)")

                # 局所グリコーゲンを補給分を考慮してアップデート
                recovery_glycogen_J = recovery_glycogen * 4184.0
                _localglyco_update_from_total(params, state, recovery_glycogen_J)
                logger.info(f"Day {i+1}: Local glycogen pools updated to {recovery_glycogen:.1f} kcal total")

                if previous.high_intensity_time_data and len(previous.high_intensity_time_data) > 0:
                    previous_final_fatigue_hours = previous.high_intensity_time_data[-1]
                    recovery_rate_per_hour = 0.15
                    sleep_hours = 8.0
                    fatigue_carryover_hours = previous_final_fatigue_hours * math.exp(-recovery_rate_per_hour * sleep_hours)
                    state.initial_fatigue_hours = fatigue_carryover_hours
                    logger.info(f"Day {i+1}: Initial fatigue set to {fatigue_carryover_hours:.2f} h")

                # 翌朝の肝は朝の状態（容量 × liver_fill_ratio_init）に置き直す（Phase 4b-2）
                if state.local_gly is not None:
                    st = state.local_gly
                    liver_cap_J = float(params.get("liver_glycogen_g", 100.0)) * 4.0 * 4184.0
                    st["Liver_J"] = liver_cap_J * params["liver_fill_ratio_init"]
                    state.glycogen_kcal_day_init = (st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]) / 4184.0
                state.hypoglycemic = False
                state.absorbed_W_last = 0.0

                # 遠心性損傷の回復（前日の終わりから翌日の開始まで。Phase 4b-1）。
                # 経過時間は「翌日の開始時刻 − 前日の開始時刻 − 前日の所要時間」。
                # 時刻が無ければ 12 時間とする。
                if state.local_gly is not None:
                    st = state.local_gly
                    decay = math.exp(-gap_h / params["ecc_recovery_time_constant_h"])
                    st["ecc_A"] = st.get("ecc_A", 0.0) * decay
                    st["ecc_B"] = st.get("ecc_B", 0.0) * decay
                    logger.info(f"Day {i+1}: eccentric damage recovered over {gap_h:.1f} h (x{decay:.3f})")

                # 局所疲労の回復（宿泊による回復）
                if state.local_gly is not None:
                    st = state.local_gly
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    recovery_rate_per_hour = 0.15
                    sleep_hours = 8.0

                    if fatigue_model_type == "exponential":
                        # 指数関数的回復（時定数18時間を使用）
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        sleep_time_seconds = sleep_hours * 3600.0
                        st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                        st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                        st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                    else:
                        # 線形回復
                        recovery_seconds = recovery_rate_per_hour * sleep_hours
                        st["fatigue_A"] = max(0.0, st.get("fatigue_A", 0.0) - recovery_seconds)
                        st["fatigue_B"] = max(0.0, st.get("fatigue_B", 0.0) - recovery_seconds)
                        st["fatigue_C"] = max(0.0, st.get("fatigue_C", 0.0) - recovery_seconds)

                    # 回復後の局所疲労を次の日の初期値として保存
                    state.initial_local_fatigue = {
                        "fatigue_A": st["fatigue_A"],
                        "fatigue_B": st["fatigue_B"],
                        "fatigue_C": st["fatigue_C"]
                    }
                    logger.info(f"Day {i+1}: Local fatigue after sleep recovery - A: {st['fatigue_A']/3600.0:.2f}h, B: {st['fatigue_B']/3600.0:.2f}h, C: {st['fatigue_C']/3600.0:.2f}h")

        days.append(simulate_day(route_day, params, state))

    return SimResult(days=days)
