"""Multi-day simulation."""

import logging
import math

from tozan.day import simulate_day
from tozan.constants import E_O2_J_per_L
from tozan.state import fat_kcal, glycogen_initial_kcal, glycogen_capacity_kcal, liver_capacity_g
from tozan.local_glycogen import _localglyco_update_from_total
from tozan.result import SimResult
from tozan.route import has_day_tracks, split_by_date, split_by_distance, split_by_track
from tozan.state import SimState

logger = logging.getLogger(__name__)


def _hm_to_hours(hm):
    """"HH:MM" を時間[h]にする（Phase 6-12）。"""
    try:
        h, m = str(hm).split(":")
        return int(h) + int(m) / 60.0
    except (ValueError, AttributeError):
        return 0.0


def split_route_into_days(route, params):
    """ルートを日に分ける。地点ごとの表（tozan/derived.py）も同じ分け方を使う。"""
    # 1日ごとの距離が指定されていればそれで切る（計画モード。Phase 6-12）。
    # 空なら従来どおり GPX の日付で切る。
    day_km = params.get("day_distance_km") or []
    if day_km:
        return split_by_distance(route, day_km)
    if has_day_tracks(route):
        # Yamareco の計画 GPX は <trk> が "Day1".."DayN" に分かれている（Phase 6-13）
        return split_by_track(route)
    return split_by_date(route)


def params_for_day(params, day_index):
    """その日に使う params。日ごとの気温・湿度（day_T_air / day_RH / day_T_air_elevation）が
    あれば T_air / RH / T_air_elevation を差し替えた写しを返す。無ければ params そのもの
    （既存の検証とゴールデンは1ビットも変わらない）。要素が足りない日と null の日は元の値
    （計画モードの天気、作者の判断 2026-10-03）。"""
    override = {}
    for key, base in (("day_T_air", "T_air"), ("day_RH", "RH"), ("day_T_air_elevation", "T_air_elevation")):
        values = params.get(key) or []
        if day_index < len(values) and values[day_index] is not None:
            override[base] = float(values[day_index])
    if not override:
        return params
    day_params = dict(params)
    day_params.update(override)
    return day_params


def simulate_multi_day(route, params):
    state = SimState()

    days = []
    day_km = params.get("day_distance_km") or []
    split_days = split_route_into_days(route, params)
    for i, route_day in enumerate(split_days):
        if i > 0 and len(days) > 0:
            previous = days[-1]
            # 夜間の経過時間（前日の終わり → 翌日の出発）。Phase 4b-1 の遠心性損傷の
            # 回復でも使う。時刻が無ければ 12 時間とする。
            if day_km:
                # 距離で切った日は GPX の時刻が合成値なので使えない。出発時刻の設定から
                # 出す（Phase 6-12、2026-09-25）。
                #   夜の長さ ＝ 翌朝の出発 − 前日の到着
                #             ＝ (前日の出発 + 24h + 出発時刻の差) − (前日の出発 + 行動時間)
                #             ＝ 24h + 出発時刻の差 − 前日の行動時間
                # 初日→2日目だけ出発時刻が変わる（初日はバスや車の到着に縛られる）。
                prev_start_h = _hm_to_hours(params["start_time_hm"] if i == 1
                                            else params["start_time_hm_rest"])
                this_start_h = _hm_to_hours(params["start_time_hm_rest"])
                gap_h = max(0.0, 24.0 + (this_start_h - prev_start_h) - previous.duration_h)
            else:
                t_prev = split_days[i - 1].points[0].timestamp
                t_this = route_day.points[0].timestamp
                if t_prev is not None and t_this is not None:
                    gap_h = max(0.0, (t_this - t_prev).total_seconds() / 3600.0 - previous.duration_h)
                else:
                    gap_h = 12.0

            if previous.glycogen_data and len(previous.glycogen_data) > 0:
                previous_final_glycogen = previous.glycogen_data[-1]
                # 翌朝のグリコーゲン = 前日終値 + (摂取した糖質 − 夜間に使った糖)。
                # Phase 6-3a（2026-09-23）。以前は食事の全量がそのままグリコーゲンに
                # なっており（overnight_glycogen_kcal = 1000 をそのまま加算）、
                # (1) 脂質・タンパク質もグリコーゲンにしていた、(2) 夜間に消費する分を
                # 引いていなかった、の2つで雲ノ平5日ではグリコーゲンが増えて容量に
                # 張り付いていた（作者は同じ山行で約3kg痩せている）。
                rest_W = (params["rest_vo2_ml_per_kg_min"] * params["weight_kg"]
                          * E_O2_J_per_L / 1000.0 / 60.0)
                night_kcal = rest_W * gap_h * 3600.0 / 4184.0
                carb_in = params["overnight_food_kcal"] * params["overnight_carb_fraction"]
                carb_out = night_kcal * params["rest_carb_fraction"]
                recovery_glycogen = min(glycogen_capacity_kcal(params),
                                        max(0.0, previous_final_glycogen + carb_in - carb_out))

                # 脂肪の夜間の収支と、翌朝の体重（Phase 6-3、2026-09-23）。
                # 摂取のうち糖質以外は脂肪に入り、夜間の消費のうち糖以外は脂肪から出る。
                # 体重は「燃やした脂肪」＋「失ったグリコーゲン（随伴水込み。
                # グリコーゲン 1 g は水 3 g を伴うので 1 kcal ≒ 体重 1 g）」で減る。
                fat_in = params["overnight_food_kcal"] - carb_in
                fat_out = night_kcal - carb_out
                fat_end = state.fat_kcal_end if state.fat_kcal_end is not None else fat_kcal(params)
                state.fat_kcal_start = max(0.0, fat_end + fat_in - fat_out)
                # 体重は「初日の朝からの累積の減少」で出す（差分の積み上げにすると
                # 符号を間違えやすい）。グリコーゲン 1 g は水 3 g を伴うので
                # 1 kcal ≒ 体重 1 g。発汗は補給前提で体重に反映しない（作者の判断）。
                fat0 = fat_kcal(params)
                gly0 = glycogen_initial_kcal(params)
                state.current_weight_kg = max(
                    0.5 * params["weight_kg"],
                    params["weight_kg"]
                    - (fat0 - state.fat_kcal_start) / params["fat_kcal_per_kg"]
                    - (gly0 - recovery_glycogen) / 1000.0)
                logger.info(f"Day {i+1}: weight -> {state.current_weight_kg:.2f} kg "
                            f"(fat {fat_end:.0f} -> {state.fat_kcal_start:.0f} kcal)")

                state.glycogen_kcal_day_init = recovery_glycogen
                logger.info(f"Day {i+1}: Initial glycogen set to {recovery_glycogen:.1f} kcal "
                            f"(previous: {previous_final_glycogen:.1f} + 摂取糖質 {carb_in:.0f} "
                            f"- 夜間の糖 {carb_out:.0f}、{gap_h:.1f}h)")

                # 局所グリコーゲンを補給分を考慮してアップデート
                recovery_glycogen_J = recovery_glycogen * 4184.0
                _localglyco_update_from_total(params, state, recovery_glycogen_J)
                logger.info(f"Day {i+1}: Local glycogen pools updated to {recovery_glycogen:.1f} kcal total")

                # 高強度疲労の持ち越しは部位の疲労（下の initial_local_fatigue）だけで持つ。
                # 以前ここで high_intensity_time_data の終値を exp(-0.15 × 8) で減らして
                # 翌日に渡していたが、最初の区間の代謝計算で部位の疲労の最大値に上書きされ、
                # どの出力にも効いていなかった（123 h に置き換えても全出力が同一。2026-10-02 に削除）。

                # 翌朝の肝は朝の状態（容量 × liver_fill_ratio_init）に置き直す（Phase 4b-2）
                if state.local_gly is not None:
                    st = state.local_gly
                    liver_cap_J = liver_capacity_g(params) * 4.0 * 4184.0
                    st["Liver_J"] = liver_cap_J * params["liver_fill_ratio_init"]
                    state.glycogen_kcal_day_init = (st["A_J"] + st["B_J"] + st["C_J"] + st["Liver_J"]) / 4184.0
                state.hypoglycemic = False
                state.absorbed_W_last = 0.0

                # 遠心性損傷の回復（前日の終わりから翌日の開始まで。Phase 4b-1）。
                # 経過時間は「翌日の開始時刻 − 前日の開始時刻 − 前日の所要時間」。
                # 時刻が無ければ 12 時間とする。
                if state.local_gly is not None:
                    st = state.local_gly
                    decay = math.exp(-gap_h / params["ecc_recovery_time_constant_h"])
                    st["ecc_A"] = st.get("ecc_A", 0.0) * decay
                    st["ecc_B"] = st.get("ecc_B", 0.0) * decay
                    logger.info(f"Day {i+1}: eccentric damage recovered over {gap_h:.1f} h (x{decay:.3f})")

                # 局所疲労の回復（宿泊による回復）
                if state.local_gly is not None:
                    st = state.local_gly
                    fatigue_model_type = params.get("fatigue_model_type", "exponential")
                    recovery_rate_per_hour = 0.15
                    sleep_hours = 8.0

                    if fatigue_model_type == "exponential":
                        # 指数関数的回復。夜の長さは遠心性損傷と同じ gap_h（前日の終わり →
                        # 翌日の出発。前日の終わりはモデルの所要時間から逆算）。以前は睡眠 8 時間の
                        # 固定だった（docs/06_ §10-3 ⑫、2026-10-02）。ハーネスの縦走 16 夜で
                        # gap_h は 10.3〜19.1 h（中央値 16.0 h）。夜全体を就寝と同じ速さで回復させる
                        # のは暫定で、Step 7 で作り直す（記録の終了〜18:00 と出発の 1.5 h 前〜出発は
                        # 軽い活動、18:00〜出発の 1.5 h 前が就寝と同等。作者の判断。docs/06_ §7）。
                        tau_recovery_seconds = params.get("fatigue_recovery_time_constant_hours", 15.0) * 3600.0
                        sleep_time_seconds = gap_h * 3600.0
                        st["fatigue_A"] = st.get("fatigue_A", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                        st["fatigue_B"] = st.get("fatigue_B", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                        st["fatigue_C"] = st.get("fatigue_C", 0.0) * math.exp(-sleep_time_seconds / tau_recovery_seconds)
                    else:
                        # 線形回復
                        recovery_seconds = recovery_rate_per_hour * sleep_hours
                        st["fatigue_A"] = max(0.0, st.get("fatigue_A", 0.0) - recovery_seconds)
                        st["fatigue_B"] = max(0.0, st.get("fatigue_B", 0.0) - recovery_seconds)
                        st["fatigue_C"] = max(0.0, st.get("fatigue_C", 0.0) - recovery_seconds)

                    # 回復後の局所疲労を次の日の初期値として保存
                    state.initial_local_fatigue = {
                        "fatigue_A": st["fatigue_A"],
                        "fatigue_B": st["fatigue_B"],
                        "fatigue_C": st["fatigue_C"]
                    }
                    logger.info(f"Day {i+1}: Local fatigue after sleep recovery - A: {st['fatigue_A']/3600.0:.2f}h, B: {st['fatigue_B']/3600.0:.2f}h, C: {st['fatigue_C']/3600.0:.2f}h")

        days.append(simulate_day(route_day, params_for_day(params, i), state))

    return SimResult(days=days)
