"""
ゴールデン比較ロジック（標準ライブラリのみに依存）。

test_regression.py（PC）と web/index.html（Pyodide/ブラウザ）の両方がこれを使う。
Pyodide でも読み込めるよう、pandas / numpy 等には一切依存しない。
"""


def summarize_value(v):
    """summaries の各セルを、JSONに落とせる形へ圧縮する。

    時系列のリストは全要素を保存すると巨大になるので、
    要素数と代表値（先頭・末尾・最小・最大・合計）だけを記録する。
    これでも要素が1つでも変われば合計や最大が動くため検知できる。
    """
    if isinstance(v, (list, tuple)):
        nums = [x for x in v if isinstance(x, (int, float))]
        out = {"__len": len(v)}
        if nums:
            out.update({
                "first": nums[0], "last": nums[-1],
                "min": min(nums), "max": max(nums), "sum": sum(nums),
            })
        return out
    if isinstance(v, (int, float, str, bool)) or v is None:
        return v
    return str(v)  # date など


def build_summary(result, day_result_keys):
    """SimResult から比較用のサマリ dict を作る。"""
    return {
        "n_days": int(len(result.days)),
        "days": [
            {col: summarize_value(getattr(day, col)) for col in day_result_keys}
            for day in result.days
        ],
    }


def _ulps(a, b):
    """float 同士の ULP 距離。符号が同じ float であることを前提にする。"""
    import struct
    ia = struct.unpack("<q", struct.pack("<d", a))[0]
    ib = struct.unpack("<q", struct.pack("<d", b))[0]
    return abs(ia - ib)


def _is_close(gv, av, max_ulp):
    """gv と av が max_ulp 以内かを判定する。

    max_ulp=0 は完全一致（`==`）と同じ。float 以外・NaN・符号違いは
    ULP 比較の対象外にして、常に完全一致を要求する。
    """
    if gv == av:
        return True
    if max_ulp <= 0:
        return False
    if not (isinstance(gv, float) and isinstance(av, float)):
        return False
    if gv != gv or av != av:  # NaN
        return False
    if (gv > 0) != (av > 0):
        return False
    return _ulps(gv, av) <= max_ulp


def compare_summary(golden, actual, max_ulp=0):
    """サマリ dict 同士を比較し、差分の説明リストを返す（空なら一致）。

    どの日のどの列が動いたかを個別に報告する。`max_ulp` は Pyodide(WASM) と
    PC の CPython の間で生じうる libm 実装差を吸収するための許容誤差
    （構想書 §6「Step 4-5 の実機検証結果」）。PC の回帰テストは既定値の 0
    （完全一致）のまま使う。ブラウザ側の検証ページだけ緩める。
    """
    diffs = []
    if golden.get("n_days") != actual.get("n_days"):
        diffs.append(f"日数が違う: 正解={golden.get('n_days')} 実際={actual.get('n_days')}")
        return diffs

    g_days = golden.get("days", [])
    a_days = actual.get("days", [])
    for i in range(min(len(g_days), len(a_days))):
        g_day, a_day = g_days[i], a_days[i]
        for col in sorted(set(g_day) | set(a_day)):
            gv, av = g_day.get(col), a_day.get(col)
            if isinstance(gv, dict) and isinstance(av, dict):
                if all(_is_close(gv.get(k), av.get(k), max_ulp) for k in set(gv) | set(av)):
                    continue
                diffs.append(f"day{i}.{col}: 正解={gv!r} 実際={av!r}")
            elif not _is_close(gv, av, max_ulp):
                diffs.append(f"day{i}.{col}: 正解={gv!r} 実際={av!r}")
    return diffs
